#pragma once

#include <Arduino.h>
#include <ArduinoJson.h>
#include <Preferences.h>
#include <lvgl.h>
#include "MiraPanelServer.h"
#include "SC01PlusDisplay.h"

class MiraMqtt;

class MiraPanelUI {
public:
  MiraPanelUI(MiraPanelServer& server, SC01PlusDisplay& display);

  void begin();
  void buildFromMiraJson();
  void loop();
  void handleMiraEvent(int eventId);
  void handleParamEvent(int paramEvent);
  void setMqtt(MiraMqtt* mqtt);
  void handleMqttState(const String& topic, const String& payload);

private:
  static constexpr uint8_t MAX_BINDINGS = 40;
  static constexpr uint8_t MAX_LIST_ITEMS = 12;
  static constexpr uint8_t MAX_EVENT_CONTEXTS = 96;
  static constexpr uint8_t PAGE_COUNT = 4;

  enum WidgetType : uint8_t {
    W_INFO,
    W_BUTTON,
    W_TOGGLE,
    W_RANGE,
    W_ROUNDRANGE,
    W_LIST,
    W_LISTBUTTON,
    W_COLOR,
    W_DATETIME,
    W_UNSUPPORTED
  };

  struct Binding {
    WidgetType type = W_UNSUPPORTED;
    String name;
    String unit;
    String location;

    int id = -1;
    int idOff = -1;
    int idOn = -1;

    int minValue = 0;
    int maxValue = 100;
    int currentValue = 0;

    uint8_t listCount = 0;
    int listIds[MAX_LIST_ITEMS] = {0};
    String listLabels[MAX_LIST_ITEMS];
    lv_obj_t* listButtons[MAX_LIST_ITEMS] = {nullptr};
    int8_t selectedIndex = 0;

    lv_obj_t* card = nullptr;
    lv_obj_t* control = nullptr;
    lv_obj_t* valueLabel = nullptr;
    lv_obj_t* stateLabel = nullptr;
  };

  struct EventContext {
    MiraPanelUI* ui = nullptr;
    uint8_t bindingIndex = 0;
    int8_t itemIndex = -1;
  };

  MiraPanelServer& _server;
  SC01PlusDisplay& _display;
  Preferences _prefs;
  MiraMqtt* _mqtt = nullptr;

  Binding _bindings[MAX_BINDINGS];
  uint8_t _bindingCount = 0;
  EventContext _eventCtx[MAX_EVENT_CONTEXTS];
  uint8_t _eventCtxCount = 0;

  lv_obj_t* _screen = nullptr;
  lv_obj_t* _nav = nullptr;
  lv_obj_t* _pages[PAGE_COUNT] = {nullptr, nullptr, nullptr, nullptr};
  lv_obj_t* _navButtons[PAGE_COUNT] = {nullptr, nullptr, nullptr, nullptr};
  lv_obj_t* _dateTimeLabel = nullptr;
  lv_obj_t* _dateSubLabel = nullptr;

  lv_obj_t* _settingsCards[4] = {nullptr, nullptr, nullptr, nullptr};
  lv_obj_t* _brightnessSlider = nullptr;
  lv_obj_t* _brightnessValue = nullptr;
  lv_obj_t* _darkSwitch = nullptr;
  lv_obj_t* _returnHomeSwitch = nullptr;
  lv_obj_t* _sleepSwitch = nullptr;
  lv_obj_t* _clockSleepSwitch = nullptr;

  lv_obj_t* _sleepOverlay = nullptr;
  lv_obj_t* _sleepClock = nullptr;

  bool _suppressEvents = false;
  bool _ntpStarted = false;
  bool _reloadPending = false;
  bool _darkMode = true;
  bool _returnHomeEnabled = true;
  bool _sleepEnabled = true;
  bool _clockInSleep = true;
  bool _sleeping = false;
  uint8_t _brightness = 220;
  uint8_t _currentPage = 0;
  uint32_t _lastClockUpdate = 0;
  uint32_t _lastSleepClockUpdate = 0;
  uint32_t _lastSleepClockMove = 0;
  uint8_t _sleepClockPosition = 4;
  uint32_t _lastActivity = 0;
  uint32_t _reloadAt = 0;

  static lv_disp_draw_buf_t _drawBuffer;
  static lv_color_t _buf1[320 * 20];
  static lv_color_t _buf2[320 * 20];
  static SC01PlusDisplay* _displayForLvgl;
  static MiraPanelUI* _uiForLvgl;

  static void displayFlush(lv_disp_drv_t* disp, const lv_area_t* area, lv_color_t* color_p);
  static void touchRead(lv_indev_drv_t* indev, lv_indev_data_t* data);

  static void onNav(lv_event_t* e);
  static void onButton(lv_event_t* e);
  static void onToggle(lv_event_t* e);
  static void onRange(lv_event_t* e);
  static void onRoundRange(lv_event_t* e);
  static void onList(lv_event_t* e);
  static void onListButton(lv_event_t* e);
  static void onColor(lv_event_t* e);

  static void onBrightness(lv_event_t* e);
  static void onDarkMode(lv_event_t* e);
  static void onReturnHome(lv_event_t* e);
  static void onSleepMode(lv_event_t* e);
  static void onClockSleep(lv_event_t* e);

  EventContext* makeContext(uint8_t bindingIndex, int8_t itemIndex = -1);
  uint8_t addBinding();
  uint8_t pageIndex(const String& location) const;
  lv_obj_t* makeCard(uint8_t page, lv_coord_t height = LV_SIZE_CONTENT);
  lv_obj_t* makeSettingsCard(lv_coord_t height);
  lv_obj_t* makeTransparentRow(lv_obj_t* parent, lv_coord_t height);
  void makeNameLabel(lv_obj_t* parent, const String& text);
  void showPage(uint8_t index);
  void setNavActive(uint8_t index);
  void applyTheme();
  void buildSettingsPage();
  void clearDynamicPages();
  void reloadFromMiraJson();

  void registerAndCreate(JsonObject obj);
  void createInfo(uint8_t idx);
  void createButton(uint8_t idx);
  void createToggle(uint8_t idx);
  void createRange(uint8_t idx);
  void createRoundRange(uint8_t idx);
  void createList(uint8_t idx, bool asButtons);
  void createColor(uint8_t idx);
  void createDateTime(uint8_t idx);
  void createUnsupported(uint8_t idx, const String& originalType);

  void updateBindingFromServer(uint8_t idx, int eventId);
  void publishMqttAction(const Binding& b, const String& payload);
  int findBindingByMqttTopic(const String& topic) const;
  static String normalizeMqttTopicName(const String& value);
  static String mqttPayloadValue(const String& payload);
  void updateListVisual(Binding& b);
  void updateClock();
  void startNtpIfPossible();
  void noteActivity();
  void enterSleep();
  void wakeFromSleep();
  void updateSleepClock();

  lv_color_t colorBg() const;
  lv_color_t colorPanel() const;
  lv_color_t colorPanel2() const;
  lv_color_t colorBorder() const;

  static int clampInt(int value, int minValue, int maxValue);
};
