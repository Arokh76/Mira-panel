#pragma once
#include <lvgl.h>

extern const lv_font_t mira_font_fr_12;
extern const lv_font_t mira_font_fr_14;
extern const lv_font_t mira_font_fr_16;
