const char Page_Message[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>%APP% - Système</title>
<style>
:root{--bg:%LIGHTCOLOR%;--panel:%DARKCOLOR%;--active:%ACTIVECOLOR%;--txt:%TEXTCOLOR%;--ink:#263238;--muted:#607d8b;--line:#d9e2e6;}
*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Arial,sans-serif;color:var(--ink)}
header{background:var(--panel);color:var(--txt);position:sticky;top:0;z-index:5;box-shadow:0 2px 12px rgba(0,0,0,.12)}.bar{max-width:1040px;margin:auto;min-height:66px;padding:0 18px;display:flex;align-items:center;justify-content:space-between;gap:20px}.brand{font-size:22px;font-weight:800;white-space:nowrap}.nav{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}.nav a{color:var(--txt);text-decoration:none;font-weight:700;padding:10px 12px;border-radius:12px}.nav a:hover,.nav a.active{background:rgba(255,255,255,.14)}
main{max-width:840px;margin:32px auto;padding:0 18px 42px}.card{background:#fff;border-radius:20px;padding:30px;box-shadow:0 5px 20px rgba(0,0,0,.10);text-align:center}.eyebrow{display:inline-block;font-size:13px;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:#607d8b;margin-bottom:8px}h1{font-size:32px;margin:0 0 18px}.message{font-size:19px;line-height:1.55;color:#37474f}.message form{margin-top:18px}.Bouton,.btn{border:0;border-radius:14px;padding:12px 22px;background:var(--active);color:#fff;font-weight:800;font-size:17px;cursor:pointer;text-decoration:none;width:auto;margin:8px}.Bouton:active,.btn:active{transform:scale(.98)}input[type=file]{max-width:100%%;padding:10px;background:#f5f8f9;border:1px solid var(--line);border-radius:12px}.back{margin-top:22px}.back a{color:#546e7a;text-decoration:none;font-weight:700}
@media(max-width:700px){.bar{align-items:flex-start;flex-direction:column;padding-top:14px;padding-bottom:12px}.nav{justify-content:flex-start}h1{font-size:27px}.card{padding:22px}}
</style>
</head>
<body>
<header><div class="bar"><div class="brand">%APP%</div><nav class="nav"><a href="/">Accueil</a><a href="/load?nav=wifi">Réseau</a><a href="/load?nav=mqtt">MQTT</a><a href="/load?nav=params">Paramètres</a><a class="active" href="/load?nav=system">Système</a></nav></div></header>
<main><section class="card"><span class="eyebrow">Mira Panel</span><h1>%TITRE%</h1><div class="message">%MESSAGE%</div><div class="back"><a href="/load?nav=system">← Retour au système</a></div></section></main>
<script>function MAJ(element){var xhr=new XMLHttpRequest();xhr.open("GET","/updatemodule",true);xhr.send();}</script>
</body>
</html>
)rawliteral";
