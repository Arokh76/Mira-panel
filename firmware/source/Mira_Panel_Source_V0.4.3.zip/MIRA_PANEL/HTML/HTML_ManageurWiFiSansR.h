const char Page_ManageurWiFiSansR[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="fr">
  <head>  
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>Mira</title>
    <style>
        @font-face {
            font-family: 'Roboto';
            src: url(‘/fonts/Roboto-Regular.woff2’) format(‘woff2’), url(‘/fonts/Robot-Regular.ttf’) format(‘truetype’)
        }

        :root {
			--light-color: %LIGHTCOLOR%;
			--dark-color: %DARKCOLOR%;
			--active-color: %ACTIVECOLOR%;
			--text-color: %TEXTCOLOR%;
			--dark-transparent: rgba(0, 0, 0, 0.5);

		}

        .FondCouleur {
            position: relative;
            font-family: 'Roboto', sans-serif;
            background-color: var(--dark-color);
            text-align: center;
            color: white;
            margin-left: -8px;
            margin-right: -8px;
            margin-top: -10px;
        }

        .Titre {
            font-family: 'Roboto', sans-serif;
            text-align: center;
            color: white;
            font-weight: bold;
            word-wrap: break-word;
            font-size: 80px;
        }

        .SousTitre {
            font-family: 'Roboto', sans-serif;
            text-align: center;
            color: white;
            font-weight: bold;
            word-wrap: break-word;
            font-size: 40px;
        }


        .FondBlanc {
            position: relative;
            font-family: 'Roboto', sans-serif;
            background-color: rgba(255,255,255,1);
            text-align: center;
            color: var(--dark-color);
            font-size: 40px;
            padding-left: 15px;
            padding-right: 15px;
        }

        .box {
            width: 70%%;
			height: 70px;
			border: 4px solid var(--dark-color);
			font-size: 45px;
			color: var(--dark-color);
			background-color: var(--text-color);
			border-radius: 30px;
			text-align: center;
        }

            

        .box:focus {
            transform: scale(1.2);
            box-shadow: 0px 0px 5px 5px var(--dark-color);
        }

             

        .hide{display: none;}
        
      	

		.reseau {
			visibility: visible;
			position: relative;
			top: 0px;
			left: 0px;
			background: var(--dark-color);
			border-radius: 0px;
			height: 86px;
			width: 804px;
			font-size: 45px;
			border: 3px solid var(--dark-color);
			transition: transform .4s cubic-bezier(0.65, 0.05, 0.18, 1.6);
			color: white;
			text-shadow: #00B6FF 0px 0px 4px;
		}

		.reseau:active {
			transform: scale(1.1);                
			font-size: 55px;
			text-shadow: yellow 0px 0px 4px;
		}

/*BOUTON COULEUR*/     
        .Bouton {
            visibility: visible;
            background: var(--light-color);
            border-radius: 43px;
            font-size: 40px;
            border: 3px solid var(--text-color);
            color: var(--text-color);
            padding:10px 50px 10px 50px;
          	margin-top: 10px;
          	-webkit-transition: .2s;
  			transition: .2s;
            width: 80%%;
        }        

        .Bouton:active {
            background: var(--active-color);
            transform: scale(1.1);
        }

        .box1 {
            padding: 5px;
            background: white;
            -webkit-border-radius: 40px;
            border-radius: 40px;
            height: 90px;
            font-size: 40px;
            border: 3px solid var(--dark-color);
            transition: transform .4s cubic-bezier(0.65, 0.05, 0.18, 1.6);
            width: 70%%;
        }

		.box1:focus {
			transform: scale(1.2);
			box-shadow: 0px 0px 5px 5px var(--dark-color);
		}

		.box1:focus {
			transform: scale(1.2);
			box-shadow: 0px 0px 5px 5px var(--dark-color);
		}     
    </style>
  </head>
  <body>
	
    <div class="FondCouleur"> 
		<br>
		<br>
		<button class="Bouton" onclick="window.location.href = '/load?nav=key';" style="text-decoration:none"> Retour </button>
		
		<h1 class="Titre">%APP%</h1>
		<h2 class="SousTitre">Connexion à un réseau local</h2>
		<br>
    </div>
    
    <div class="FondBlanc"> <br>
        %SCANRESEAUX% 
		<br>
    </div>
    
    <form name="reg" action="/save?config=wifi" onsubmit="return Verif();" method="POST">	
		<div class="FondBlanc">
		  <p> 
			<b><label>Nom du réseau:</label></b> 
			<br>
			<input class="box1" id="ssid" name="ssid" style="width: 800px; text-align: center;"value="%SSID%" type="text"> 
			<br>
			<br>
			<b><label>Mot de passe:</label></b> 
			<br>
			<input class="box1" id="pass" name="pass" style="width: 800px; text-align: center;" type="password"> 
			<br>
			<br>
			<b><label>Adresse IP fixe ("Auto" possible):</label></b> <br>
			<input class="box1" id="ip" name="ip" style="width: 800px; text-align: center;" value="%IP%" type="text"> <br>
			<br> 
          </p>
		</div>	
		<br>   
        <div class="FondBlanc"> 			
			<input class="Bouton" value="Valider" style="text-align: center;" type="submit"><br>      
        </div>      
    </form>
    
    <div class="FondBlanc"> 
		<button class="Bouton" onclick="window.location.href = '/load?nav=reboot';" style="text-decoration:none">Ignorer</button> 
    </div>    
    <br>
    
    <script>

		document.getElementById("ssid").value = document.getElementById("RS").value;
		
		function Click(value) {        
			document.getElementById("ssid").value = "" + value + ""; 
		}

		function Verif(){	  
			var iip = document.forms["reg"]["ip"];			
			if ((iip.value).length < 7){ 
				if (iip.value == "Auto"){ 				
					return true;					
				}else{
					alert("Veuillez saisir une adresse IP valide"); 
					iip.focus(); 					
					return false;					
				}          
			}
			
			var boitevalidation = confirm("Voulez-vous valider ces informations?");
			if (boitevalidation == true) {			
				return true; 
			}else{
				return false;
			}
		}
    </script>
  </body>
</html>
)rawliteral";