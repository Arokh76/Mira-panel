const char Page_MQTT[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>%APP% - MQTT</title>
<style>
:root{--bg:%LIGHTCOLOR%;--panel:%DARKCOLOR%;--active:%ACTIVECOLOR%;--txt:%TEXTCOLOR%;--ink:#263238;--muted:#607d8b;--line:#d9e2e6;}
*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Arial,sans-serif;color:var(--ink)}
header{background:var(--panel);color:var(--txt);position:sticky;top:0;z-index:5;box-shadow:0 2px 12px rgba(0,0,0,.12)}
.bar{max-width:1040px;margin:auto;min-height:66px;padding:0 18px;display:flex;align-items:center;justify-content:space-between;gap:20px}
.brand{font-size:22px;font-weight:800;white-space:nowrap}.nav{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}
.nav a{color:var(--txt);text-decoration:none;font-weight:700;padding:10px 12px;border-radius:12px}.nav a:hover,.nav a.active{background:rgba(255,255,255,.14)}
main{max-width:940px;margin:28px auto;padding:0 18px 42px}.hero{text-align:left;margin:0 0 16px}.hero h1{font-size:36px;margin:0 0 7px}.hero p{margin:0;color:#455a64}
.card{background:#fff;border-radius:20px;padding:24px;margin:16px 0;box-shadow:0 5px 20px rgba(0,0,0,.10)}
.card h2{margin:0 0 4px;font-size:23px}.hint{font-size:14px;color:var(--muted);margin:0 0 18px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}.full{grid-column:1/-1}
label{display:block;font-weight:700;margin:15px 0 7px}input[type=text],input[type=password],input[type=number]{width:100%%;padding:12px 14px;border:1.8px solid #78909c;border-radius:12px;font-size:17px;background:#fff;color:var(--ink)}
input:focus{outline:none;border-color:var(--active);box-shadow:0 0 0 3px rgba(0,0,0,.05)}
.switchline{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:14px 16px;background:#f5f8f9;border-radius:14px;margin-bottom:6px}.switchline strong{font-size:18px}.switchline input{width:26px;height:26px}
.actions{display:flex;justify-content:flex-end;margin-top:22px}.btn,.Bouton{border:0;border-radius:14px;padding:12px 24px;background:var(--active);color:#fff;font-weight:800;font-size:17px;cursor:pointer;text-decoration:none}.btn:active,.Bouton:active{transform:scale(.98)}
.topic{padding:13px 15px;background:#f5f8f9;border:1px solid var(--line);border-radius:14px;margin:10px 0}.topic b{display:block;margin-bottom:5px}.topic code{display:block;overflow-wrap:anywhere;font-size:15px;color:#37474f}.note{font-size:14px;color:#546e7a;line-height:1.45;margin-top:14px}
table{width:100%%;border-collapse:collapse;margin-top:12px}th,td{padding:11px 10px;border-bottom:1px solid var(--line);text-align:left}th{font-size:13px;text-transform:uppercase;letter-spacing:.04em;color:#546e7a}tr:last-child td{border-bottom:0}
@media(max-width:700px){.bar{align-items:flex-start;flex-direction:column;padding-top:14px;padding-bottom:12px}.nav{justify-content:flex-start}.grid{grid-template-columns:1fr}.hero h1{font-size:30px}}
</style>
</head>
<body>
<header><div class="bar"><div class="brand">%APP%</div><nav class="nav"><a href="/">Accueil</a><a href="/load?nav=wifi">Réseau</a><a class="active" href="/load?nav=mqtt">MQTT</a><a href="/load?nav=params">Paramètres</a><a href="/load?nav=system">Système</a></nav></div></header>
<main>
  <div class="hero"><h1>MQTT</h1><p>Connexion du panneau au broker et configuration des topics Mira.</p></div>
  <form action="/save?config=params" method="POST">
    <div class="card">
      <div class="switchline"><div><strong>Connexion MQTT</strong><div class="hint" style="margin:3px 0 0">Active ou désactive le client MQTT du panneau.</div></div><input id="mqttActiveBox" type="checkbox" %MQTTCHECKED% onchange="document.getElementById('MQTT_Actif').value=this.checked?'1':'0'"></div>
      <input id="MQTT_Actif" name="MQTT_Actif" type="hidden" value="%MQTTACTIF%">
      <div class="grid">
        <div><label>Nom MQTT de l'écran</label><input name="MQTT_Nom" type="text" value="%MQTTNOM%" placeholder="panel"></div>
        <div><label>Adresse du broker</label><input name="MQTT_Serveur" type="text" value="%MQTTSERVEUR%" placeholder="192.168.1.x"></div>
        <div><label>Port</label><input name="MQTT_Port" type="number" min="1" max="65535" value="%MQTTPORT%"></div>
        <div><label>Utilisateur</label><input name="MQTT_Utilisateur" type="text" value="%MQTTUSER%" autocomplete="username"></div>
        <div class="full"><label>Mot de passe</label><input name="MQTT_Mot_de_passe" type="password" value="%MQTTPASS%" autocomplete="current-password"></div>
      </div>
      <div class="actions"><button class="btn" type="submit">Enregistrer</button></div>
    </div>
  </form>

  <div class="card">
    <h2>Topics Mira</h2><p class="hint">Le nom de l'écran est intégré automatiquement dans les deux chemins.</p>
    <div class="topic"><b>Commandes émises · Actions</b><code>mira/%MQTTNOM%/Actions/&lt;topic&gt;</code></div>
    <div class="topic"><b>États reçus · States</b><code>mira/%MQTTNOM%/States/&lt;topic&gt;</code></div>
    <p class="note">Une interaction tactile publie dans <b>Actions</b>. Un message reçu dans <b>States</b> met uniquement à jour l'affichage : il ne déclenche jamais une action Jeedom.</p>
  </div>

  <div class="card"><h2>Widgets déclarés</h2><p class="hint">Liste des noms utilisables comme topics MQTT.</p><table><thead><tr><th>Nom / topic</th><th>Type</th></tr></thead><tbody>%MQTTTABLE%</tbody></table></div>
</main>
</body>
</html>
)rawliteral";
