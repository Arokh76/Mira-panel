const char Page_Sys[] PROGMEM = R"rawliteral(

<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>%APP%</title>

    <style type="text/css">
      @font-face {
        font-family: 'Roboto';
        src: url(‘/fonts/Roboto-Regular.woff2’) format(‘woff2’), url(‘/fonts/Robot-Regular.ttf’) format(‘truetype’)
      }
	
     
/*MENU*/
      :root {
        --light-color: %LIGHTCOLOR%;
        --dark-color: %DARKCOLOR%;
        --active-color: %ACTIVECOLOR%;
        --text-color: %TEXTCOLOR%;
        --dark-transparent: rgba(0, 0, 0, 0.5);

      }

      #ham-menu {
        display: none;
      }
      label[for="ham-menu"] {
        display: block;
        position: fixed;
        top: 20px;
        left: 20px;
        z-index: 999;
        width: 60px;
        height: 60px;
        background-color: var(--light-color);
        border-radius: 15px;
        border: 2px solid var(--text-color);
      }
      .ham-menu {
        width: 99%%;
        height: 100%%;
        position: fixed;
        top: 0;
        visibility: hidden;
        transform: translate(-110%%);
        z-index: 998;
        background-color: var(--dark-color);
        transition: 1s;
        display: flex;
        justify-content: center;
        align-items: center;
      }
      .ham-menu > ul {
        display: flex;
        flex-flow: column nowrap;
        justify-content: space-around;
        padding: 20px;
        height: 50%%;
      }
      .ham-menu > ul > li {
        font-size: 40px;
        white-space: nowrap;
        cursor: pointer;
        color: var(--text-color);
      }
      ham-menu:checked + label {
        background-color: transparent;
        border-color: var(--dark-color);
        
      }
      #ham-menu:checked ~ div.ham-menu {
        transform: translate(0px);
        visibility: visible;
      }
      .full-page-blue {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%%;
        height: 100%%;
        background-color: var(--dark-transparent);
        opacity: 0;
        z-index: 997;
        visibility: hidden;
        display: none;
        transition: 300ms;
        position: fixed;
        top: 0;
        left: 0;
      }
      #ham-menu:checked ~ div.full-page-blue {
        display: block;
        opacity: 1;
        visibility: visible;
      }
      [for="ham-menu"] > div {
        width: 100%%;
        height: 100%%;
        display: flex;
        flex-flow: column wrap;
        align-content: center;
        align-items: center;
      }
      .menu-line {
        display: block;
        width: 17px;
        height: 2px;
        margin: 10px 0 5px;
        border-top-left-radius: 2px;
        border-bottom-left-radius: 2px;
        background-color: var(--text-color);
        transition: 300ms;
        transform-origin: right center;
      }
      [for="ham-menu"] > div > span:nth-child(4),
      [for="ham-menu"] > div > span:nth-child(5),
      [for="ham-menu"] > div > span:nth-child(6) {
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
        border-top-right-radius: 2px;
        border-bottom-right-radius: 2px;
        transform-origin: left center;
      }
      #ham-menu:checked + label span {
        background-color: var(--active-color);      
      }
      #ham-menu:checked + label span:nth-child(2),
      #ham-menu:checked + label span:nth-child(5) {
        transform: scale(0);
      }
      #ham-menu:checked + label span:nth-child(1) {
        transform: translateY(17px) rotate(45deg);
      }
      #ham-menu:checked + label span:nth-child(4) {
        transform: translateY(17px) rotate(-45deg);
      }
      #ham-menu:checked + label span:nth-child(3) {
        transform: translateY(-17px) rotate(-45deg);
      }
      #ham-menu:checked + label span:nth-child(6) {
        transform: translateY(-17px) rotate(45deg);
      }
      
      .text {
        font-size: 20px;
        line-height: 1.5em;
        font-family: 'Roboto', sans-serif;
        list-style: none;
      }
      
      .centre-text {
        text-align: center;
      }
      .bold-text {
        font-weight: bold;
      }


        .FondCouleur {
            position: relative;
            font-family: 'Roboto', sans-serif;
            background-color: var(--dark-color);
            text-align: center;
            color: white;
            margin-left: -8px;
            margin-right: -8px;
            margin-top: -10px;
        }

        .Titre {
            font-family: 'Roboto', sans-serif;
            text-align: center;
            color: white;
            font-weight: bold;
            word-wrap: break-word;
            font-size: 80px;
        }

        .SousTitre {
            font-family: 'Roboto', sans-serif;
            text-align: center;
            color: white;
            font-weight: bold;
            word-wrap: break-word;
            font-size: 40px;
        }


        .FondBlanc {
            position: relative;
            font-family: 'Roboto', sans-serif;
            background-color: white;
            text-align: center;
            color: var(--dark-color);
            font-size: 40px;
            padding-left: 15px;
            padding-right: 15px;
        }

         
        .hide{display: none;}
        
      	



        

       /*BOUTON COULEUR*/     
        .Bouton {
            visibility: visible;
            background: var(--light-color);
            border-radius: 43px;
            font-size: 40px;
            border: 3px solid var(--text-color);
            color: var(--text-color);
            padding:10px 50px 10px 50px;
          	margin-top: 10px;
          	-webkit-transition: .2s;
  					transition: .2s;
            width: 80%%;
        }

        

        .Bouton:active {
            background: var(--active-color);
            transform: scale(1.1);
        }

        .fond_bas {
            font-family: 'Roboto', sans-serif;
            background-color: var(--dark-color);
            text-align: center;
            color: var(--text-color);
            width: 100%%;      
            font-size: 16px;
        		margin:-82px -8px 0 -8px;
   					height:82px;
   					position:fixed;
   					top: 100%%;
        		z-index:996;
            }       

            

    </style>
  </head>
  <body>
  <input id="ham-menu" type="checkbox"> 
    <label for="ham-menu">
      <div class="hide-des"> 
        <span class="menu-line"></span> 
        <span class="menu-line"></span>
        <span class="menu-line"></span> 
        <span class="menu-line"></span> 
        <span class="menu-line"></span> 
        <span class="menu-line"></span> 
      </div>
    </label>
    <div class="full-page-blue"></div>
    <div class="ham-menu">
      <ul class="centre-text bold-text">
        <li class="text" onclick="window.location.href = '/';">Home</li>
        <li class="text" onclick="window.location.href = '/load?nav=mqtt';">MQTT</li>
        <li class="text" onclick="window.location.href = '/load?nav=params';">Paramètres de configuration</li>
        <li class="text" onclick="window.location.href = '/load?nav=id';">Requêtes HTTP</li>
        <li class="text" onclick="window.location.href = '/load?nav=wifi';">Paramétrer un réseau local</li>
        <li class="text" onclick="window.location.href = '/load?nav=listnetwork';">Réseaux enregistrés</li>
        <li class="text" onclick="window.location.href = '/load?nav=configAP';">Point d'accès (Wifi Direct) et clé</li>
        <li class="text" onclick="window.location.href = '/load?nav=system';">Système</li>
      </ul>
      <div class="fond_bas">
        <img style="margin-top: 5px; width:50px; height:50px;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAaMklEQVR4nJ2ce5xlVXXnv2ufc2/d7q6qflXT3fIKgUA0jkqMBgRBMviOJqjtmDgzfIwmxIHRREaMMDPYQePkg0QlhuADH5ME+Yg2EoKQIYkjxqASwsTXgBpBQZ79qGdX1T1n7zV/7Oe5t7rTzum+de89Z5999vqttX5r7dcV1j4Edhm40QI89WWXHb+4svLS4VBPd237M8aYY1QQ1JcEATGICCoViiBGwAGVATEjtVfhHkFRUPy9vjJEBBF/HVX/wpctHgqqqGqoVAFF1SGAqPPn1OGcQ4yIqcxiZar7ReTO9ZMTt35vz2X3+bsvN/AuBVFGDhnH5nIDux3AjrMufo4drvyuuvYlTmWzsxbUoWrDzVEQ44Uhf5YAikZh8QBIKld8DuLl5sR64wXN7+URARICiCVYBDAjiB5YqWpMVSPoUlVV/3vQrz/w4F+/528U4PLLDbu97IcAyIPzvFe+fepfHl+8sm2aC5y12GYJ1DpSc0SyhknWA4IKAZxQdSxXNDkDk4HSZBUU5b0SvJVpbm3CKQCXWhVA6wA2Bq6KCGIqI/V66v4EdcWfT05O/u53/2r3XnbtqrjRe84IQB6cE8/+TyfNLSzfaK17ll2ZV9XWAUaDSiUKnVokCYR8je714lEqJhQpABwrW96vHcPxbjai1+BmIppK4FwGiBLbBJgK4hCRerDR1HXvu+sn6l0P/N37vlGCJCU4Jz//ohNmF+b+YXV1dYdrllsVV3vtmDHBZVT4jqVQfBciXZUgiJhgRIW1ER3BZG4L1pE8qSwdLRjFE164qs7DpBlZkcISVUFtxBVB2mpisja9wRPrJvrnPnzn+78Z3S20+HI5bdf8xP3feuQfrGuf5ZrlFtE6QZ9IVpI+xBhGeRpM4SElL4V78JyEmMLaQjkJOi1Bho69qMZv2imRron/rurGOMvX4VLZhE5wRYG26k/VdW/wwHHbj3ruPX/Ffi/Frl0GdrvvfueRK526Z7nhYgO29g+xvgLnvG87B875COEchHf/QECd15rGRjhU/XVVh0vac0GREtqnqMvlPfmGtjtPsupcqtcHKM3PdcW7c8GYNAPhLOoKWYI8yfL8c+t2Zb6xtj3h4Scf/1PY7dj1HY/5SWe86bR9++bualYXrGKNRt0n4i0J1ATLHo1IpuMAGkk4WIrEsB4/G+OtJ+o3PiNaX9IuKZRL+qup3tSwAHy8nFOCNYm6G+FSeUGkauvBxnrj1PoXPXDn1XfUAszPzb/dtkNUrQaS91VEx3eBBxBEXYo4qoEYVVDRTuNFjPf5RM74LEMVNcZrUTQD50kKUUGxJJcseEQ7Asp4aE/CuoSJxNRG1Z9Pn7VobQZJnZW2WdHFRXepCHfIKWdf8FOPPfLYN227Mqnaepk7PCC5kiLaSOAWKcJ1aQ0pdGvgoE60ChZifHogSGh697mJ3MFbB5ICWz5cEi4BNcJRSYLgvgnYUs5OFKi0NzHZbNw6/dx6dt/sL6vTSXWNRahIWouRJGoAbwLpq9d+zDlES5AUpwWQEIASVA2IRcR4LtOcQHqLLSNaQaQBmegSMTyMZtKjao2WpVJGMOdpQ7MVSWijooizDqf9Zmnl1bVrm+era1SDhtCodEdHESmkktDXAEwM4aKBr4K7JP7SMvw7D2ZsZLSsCHAgaCnAFqIL5uijpeLS98xV0b0j14jTHOYlR0bf7sxRIRKKsw1t0zu9btrVE9XZIM0oSIWtRC0mjZl0zSs5EHAg8u4RdSSBr0ifUz6UiLngt3h3mXOpjtRLtgwhuGIUPutUoiURuLDrpxlw59WqrqVphyfUIrJd1RI5NGuspEQXAC7yFLXxsakBGSRX5D4F92gEKdxR8JbgsiIg3U+SWUf4J1tSusflqOXPFy5fBrwoZ4eDcl0KqHO0zXBQaxs6oIRIFdFNUVeKCNmNI/5/Nm4pHxSup554sBYtGiaFNfrqNYEm0YQ1ICSJp4vmBavo8FB8L1wKRtKIsvjovblecaq1qg3WUnZiM290z2eBIyQ+o1afewXAEuFFDZrocq6oN7bZ5RAf+EAj7FqYjBI4b7QZGaTcddPQ0/HKdWEIJPFi+OsN04RqXCov8Y8R6o4fp0pcJs/UuhJfxQRrW1paBlXWrRtgxOCcBg4KRI4gzkGRF6nGhsb6o2l0k9KOchKiWtBNEZnIwxqVMaysrtI0LRMTPfq9HjYBqMGSM6dlTtQi9/L1jrJpNMzQPYiveD4MSImyurrCyvIyz/zZn+LZzziZdrjK0sICVSU+rSc3XkM6n7WdB7PKl6auhgvWVpRBfZLq+x/4bo2j6CoADgMsHNjP0Udt4oxnn8KmyXUszM15J44EHrtEAfNoCpmDczfFKIbYAfSdwUB6RUOycA4j0C4vs2PrJr5wwwe554t/wdfv+BRfuvlanvW0E1nct486gCSFoBEkDb1uVVsI70KqGPt2LoMYGkwJXurPWd/PUuvvd5bF/fu49G3/kXv+9mP8/a1/yj/e8VFe9fIzWZqfx4iizoZ+XaijfF5KIQqjnTr+RQ9Z2xyjupo7y9HlQuTJ/Rqfug+Xlrhtz7W88JznYa1DBIwxPPb4k7z4vAv4xre+z+TmTbRWkdjnKnOe9JBiaDVFhdKoC92W4T1ZVlCqAbUty3NzvO+9b+PiC18PgG0tVV2xuHiQp5/56zzyxAH6EwO848Q8pkgfMo+rMT0R03vYJPN22e9iVNDIA8G0RZTlxUWe+cxTeOE5z6NtbSLDpmnYsX0bt+25lqeefByLs7PUFV5jyVoyX3QdmgyABmuK79jkYqou9Mq9xp06RBzaDlmen+eP33cJF1/4epqmxVmHqQxt0zI5uZ5Tn/7TNEuLGAmeUfBbjOCFBtInE/mm5ISs31JzwfWGQ47ZsS2mMilk13VN27Y8ZcdR3H7TRznx+J0sHpilMoDrulNy3+j1JScRhj5iuzS7pLioTAvOYXC4tmV5fp6PXH0ZF/3Wv6NpGuq68pMGkLowRlxqh7q2MIZIAXQMJIptomXEQjn9KrQ7wgHOth1HiUdVVbRty3HH7uT2z3+U44/dztLcHJUR1Nqis2izNUWh47iRK7kmcFIYy0nW7Lzl2GaV1YVZPvnh3fzm+eclcEYPEcFPOORxoQy+yxwXx7hi7kWMYp38qhiIiolUmYzFijpHNskI0kk/fRy37fkwR2/fysH5eapKwEaCpONuadymiHBagOYHuWwCS8TRDlewKwe5/uPv5fxfewVN01LX9ZjacjJdBokgBwXpaimnSy9TCidjfqidLkc2R+0WG2lUVVU0TctTTzmR2276CEdtmWY5pABl2M6gZGXEPCS9Yhnno5YRxQ5X0NUVbvjkH/K617z0kJZTtixP/USX7spZtic1yGnK8bsVJmvJ76nX1ekPjWGTjrquaJuWf/NzJ/OFz3+EzdMbWFla8u6WwmtQQgcsz3XxVYZ9I0qzugLNKjf++VW8+ldeyLBpguUc4sjaLYSn87zOoJxQnEuJYk7/U9GR/k0RBY/4qOqKpmn4+Wc+jVs/dy2T6yZYPbhElWZMvUV6CgzJYEeTkby95TQrK1S24XPXv59fefk5NE1D73DglEfsKKa6KT5n4JKMMVH0xUrSGjlGLOwnPeq6pmlafvE5z+Dmz3yIQW1YXVn23TOXB/QptKYhCVT13GMEmpUVam3Z8+kP8MsvObvgnCM9cliRlKiW0XT05XEZ62qMVdqZe/r/O+q6YmXYcPYZv8D1N3yICSO0ywc9SGVGHQNA7GM5hzGwunyQCWO5+TMf4qUvev5hOefQRxY+j0e7rgWt8UouVs5QdLLdMrFLpvmTN03qmieXG15wzmlc+cn3gbPYxqcLFFM6pesZA6tLi2zoCbd89hpe+EunB3B+AstJYhTuVXRh8r/xLg7EgeckeBjeksxKPhsfZZ8jQUnTm1UYOrBVzYPzDWe+7Gwuu+6D2OEqthmGZM6NEfLqwSUme8Itn7uGc876xZ8cnLKpMbUgxpn8WbqFCnEVo05zpB4Nrx1wSpCOnK4dHqBGYcUpjVQ8urfh1Feezeuuejd2dYizLX4q2AbOUZYX5pheP8GtN3+Ms854zhGAc+SmrSOeoLrG9WRBphA3hfCRu0dTgSPAx0YCBtpgQctOWFZhkYofPtLwc7tezll/8B6axTlwbcpo2+GQbZun+cKeazjjtFMPC461Ngj0rzQqTW93o6VvYelWrnB1MIU1BbIokcqEVuYT3dUVa2uurmpEDK1Tbz0Kyw4WLMxbWKTi0ccaZs57OcddegV2aQmc7303+/bytreez2nPPZWVldVDguOco65rjDlMrOkIWCSOId9Jw75lD6KQLdlPd0I/v0bzwrFDRzSnfsz561+/m9XAL6tWWXGwaJUFC7OtMNsKB2zNE080VK95NeYt/x13cBFnh8igz11f/Secc/R6dSeRS8I4R1VVfPnLX+HJJ/dmGQ7Zzsyz6TuZi1LGHg0i5l/EflU5DjQGSfldulc7xuTHf1Qdr3rtf+CNv/mfqSthiGPJKktOWGhhvoXZFmYt7HMVjz3R0Ox6He5Nv4ed3U9/epqbb/xLLrjwnVRVhXNlX1BprcNUFe//4DWcddaZfHbPTYgI1lrGDi3fAhypr5nJOQYn/y1OYghGUxTTjrAp3R7JqMsQWGqibJA6ZWbbU7j+f36U337rOxgMapadB2nBwYKDOQv7WniiEZZcje5tsK86H33Df8MdeILBzAwfu/ZTvPmid1DXFaqKtRYbrOo9/+OPeNvv/B4i01h7GP4pO6uxgZEzRvOeKI/LAJoxgdc8utc780lrpQACzilm8BQ+dvV1XPJffp/expqDzrHolAWnzDl4soUDDWABW8P+FvvKN+Becwl24QCDmRmu/ZOP89aLd1NVFXVdU9c1u999Ff/1ne9m/dajUa2RsYnKQ8shhQtp8Td6TqZgn27UHY5JVlSMvB7hozuAOcDUOGrWbdvJp666mmF/wMuuuITFH7fMO8Ochf3Oh38sSAvaVuhii/vVi9ClVbj9KtZtP4ar/+hPaNshb7nwN7jukzdw5XuvZrBlJ2oEqBmfyT0UPoFnnIJUxNUlSpowGZO6LgFQ6EzLxms5+ofzhyDDdFZATA1UOCdMzBzNp9/7AQ70Bzzjkrcw96OWA86wqBIjq5+obUGsQfe38IqL0cbR/u1VTMxs55oPX891f3YTqweX6c/swKqjovIAHVFelkk4j0drwRAFQqoePPHwZ+Fl1GK0ePQR5BoQwqYABkzlLUkd/Znt3H7Fleztb2D6t9/I/h+1rEoV7gmPd6CtgDOwZGlf/HbMwSW4+xMMNm7F2pbBpi1YpwgVxkiYlDwSgKQbklXTQrAAVWCHjICqUpdjwxHH+EE1L/QuQeseI8DFZSXGBDOukNDl623Zxj+96z1sm9jA3L9/HTzUIHUVXCXno+IEWmC1RV78LtzQwT9fh5k6mjgDCvgsrrMI9F8DqgRDw9qkrld4aUIvzQM0gq50q+u45fhC9M4N0ln94Xs5Rgw2XTdUGzfxxKWXwqCP7HoV+i8N9CqkFjTKqqBOECu4ZYuevhsZKvr9T8PEloBi8Zw123WYI3pLsJjCZspCCKE3n/A/XIJcZqSHas9ILgYhj0xrGA2YmnpyI9Ul74Rbb4MTekjfogOFCaCHB0oVnEEb8eCcfgX2uPNgdZbEBTGXWYNcD31005VoEzG6+S5pnHkJth+Xzab8qbz9MImjDwqjqEtONfBopeV6xvhH9ieQwXrkLb+D+cqX0J/pwYSF9SSQqIq11arYoeKecwW68RSwB0EkKWN06XBuTpmvrQ1gGa3XkjTFx5gPZDRHwOkA5d9ltHF5nCTFwbzS1NcspvJm1R9g6gG88SLknq/BKT1YZ2ESWK8wAPogfaBvwFiYGuC2PgNtVohM0eXPEaBGXSLJEHm3y31rIWTS4shUX1ykUD645JWuYjpHMQCeNVN4uOAXWJmw22ewHlGQ89+M3PcNOKWGDRamBDYA60HXgQ6AdcAGhV6dthmUS3hHn1Xikq51XFKRNAVUFu66rClLHMqVuyTW8Z/uIdmdcjq/1jXPSQLI5CRmuUF+/QLkwfvh5BomLWwCpoGp8JoE3ShorWlxuW/SERJ0HO8uRInjPnGPR+dVDrl2+HcUzVGoDoNPORpQ5k/aATZuQ8CnAQ6YmsLMLSC/9ibY+0P42Ro2WtiCB2qTwiaQzUA/Tlzm9pV8N3Z0ThU99TK8F8Ox3f6ni7MaXaoKbNEZeuzY0WG1Fh/s1jiLD8nFHg2RCnHA9DTmiX2Y1/4GsvRjD9JmC1uBLQJbQWeA3kgU7SS3h2uXrK1Z1bBFIoUYovuqG+msRh7SfC/JTYpwaqrKVzrWhsxWpqqI+UbyOGKaI+m88Wtn/MKEjRuRHz6E7HojMnwcTgogHQVsVdjikA29jHHMtUxY2bbWoaHjXJVbH8K9gb9y2zSJG/9mDor9lJSCjxJWOFdV7D8whwnbB2xr/TCEtbRtCwjOOWbnFpGqSsGiG2VDFmtMwU0VWEW2bEXu+z7y2t9CqgOYU2qYbmCbgaMMHHgUqtpXG7Q5OzuPMYK1LrUlvhQwRphfOAhVFZSTPaaMfOOkEi0oRoIwhpxdKHfqwGuiP7meu792L5/57C3UdUXdq9MwRK/XQwTe/6GP88D3fsDEuvVhaMVE/dANxnkHoojx0c0qMjOD3Ptt5LVvRg88iHlqHzmxorrtFsz/uQsmpxFVnFOqqUk+8Wd7+MEPfshgMJHakl8Vn7/lDu766r1MTE56S4ujoJ20pIzahcWv3/n8h5xdPca5YTHYQeFrIW8IBCai2KZBUM59wWls3TKNhtWoYmp+9NCjfPmue+kPNkDlO6tgwoJxIS3slEyXfoMMpCU2zqJG0Pl5dPMU5szTYN8s+tW7MRODkCZ4izf4ubPtR81w9pm/QK8uuz6wd98cf3fn3TiEut8PWyRI7RmPhoqgakxPjOk97AFyw2OcXR0HKLlYtC6XXdA5moUFaNsAeehI9SeYmJpGxYCEwaz4wpdLa6GTkefp5/Qc53wndtigiwtIVcPUFH49TyZTnEMMNMMGt7hAXj0SjrpHf2oKqSqvyM7q3YjJ2M4fNVUtlek9nKYLur6YNmiT19AoaZ4Rh5iKwebN+S4RLzzGL3iPblVs+O0Ey9BZjB3NtDEGEDWoCSv2e31kZpsv7BxQh/qCxsVbXa/fx8zMZHAKdfth9wKcdHuEJJ4YTQA1rJPWbo+2wxJx04oUWgvcbl0oH7cZlAsyS6vpxLCsEj+iF607mj7FTpywtjoIKFIV90IYugyu4rAlv2T5Ia3kLTZ0FiCNRv8yvanL7O7QIJUPk6QZKe5LezJKcArOodhhk7s0RWMhCZcjeFx5XwSNaH5BcA9ytHlHRry8J0ut3T8lUqENWogo1MaYyto4OZinoVUpOqKFb5TnOkBFCyo28wa2iEotddVlAukCVupUQIr8pWQv39AATwDUjze7IlKllpfyd59c7IMrC4uImLquZlMIjjJ2Smp3GCQhOApKdCkZSZ80kW9KIzumU4T/HCKKhnYdQKOUCT0h8l35XUvrjba+Zg9A8zh8sjyvrKpXrRqUfzaSFg+nB0khSLc3HwYZMjsH4dYSNvez0/L+xHl51ECKUvmQEWzyFHg36czA+fTBKyqGcSmuZWvPd3W3feULIkIlcr9R0TvEmJGRnO6rC090nNLVio0pkajXeGoUMG53kAhOIkstntEdmyocOUuhXYCzFdGtRSOlFVSRLIaRzxGgiqoyXzJbduz8Apj9mCr3MNY4MpWV4JHcJ343CdSot65z5zHgrknnKqNbF4sJtHxOBifnTfGzD/ldfotBZiSM6+iH7ESKGMGtbN+26WbzwNdueHxionezMX3Br4fLso+BpFmGUbDKjFQLdygaXpbtdoTLTSqaNJ6eoNFaIo9oNsfC0sbWG6pmXhu1nkQGJcgAao3pSb9X/a9vf3XPfQaQmc2brjSiQ6XyQUcK7ScTLp1/3My8MbtsOZrvj7+IUC79zS+X6x3ZkiDpswvPCO9KMcEZFRDBLpf2RsW5/LmzTju3J2yiU8FQ10Y3Tw2uUAUDu8z37v38/+31qiuq3kSF0kbt5qBSrDpLwnRfXQse57EsjB2/r9BiB0DtcpImMOKejwzIuDWPgJ2ALlx77D5aU/eqfq+65gff+pt/hF2VgRsd7Kre+oZz/6Cqze1SD3pA47dUZrfp7kPPluOFKkzbuZzclSDGxo7wjpQaLYFzo43P93Ytm0592UqiFZPvK70hjUqm641UvV6/lrtP3rHz7UAFN6a9wALw3Je8fuq+bz/4xdXh8Oe1XWmAmhDQx+JImbMoOXql66PdjPBZMh+Uv+Si6Xs0Uk0ByffZgqJGpng0ncvWmEGBzqTiqOI8lymqrVT9Xl3Jd47dueXc++7560fxyZWLUiggX7/9L+Z3Hrv1Bb1edavpDXrqOzlt9K3Ov+jrCYMRk9URwuxYQtzhY4vzSncXYrYISS5CtqS0datbZ4pmgQ/zL8eMuJffVtmiiKkmer3a3HHClqlf8uBcbkg9wO5hACciTB972juGTXuZc0ypHYJrg2NLnvSVNayjY2F5M1HX+ooZDgpXLuxUY/2aZz/jJGJhEsXf+NjMZ/lHlUgWSfzdDRExpsYIy/1+/YcH3vDiK2T3blf+httaAJXn9GmnvuKkR2cPXLi6snKeU46Pv/HTLRr9WGI2Rk4px6pMQHZ+4K1M2MpsN92myS3TvtG0P3y0Od5CVIsgU2TLEn7epzLySK9nbto4ve6PH/zmF+8fF+jQAIVjVxV/JvDZ5+7a+OOH9/7blYMrZyo8vW2bdWptCkCpskPxTnhTSD9dIeWKDvCkrIVVjv6yYCwDYNKyp3yus4Vc803RgkSkP9FfFqm+NTFRfeWkE0648+9v/8STvuDZNXwp+nvn+H/BrWo8niTf/AAAAABJRU5ErkJggg=="> 
			  <div>
          %POWERED%
        </div>
      </div>
      
    </div>

    <div class="FondCouleur">
      <br>            
      <h1 class="Titre">%APP%</h1>
      <h2 class="SousTitre">Système</h2>
      <br>      
    </div>

    <div class="FondBlanc"> 
        <br>
        <button class="Bouton" onclick="window.location.href = '/load?nav=reboot';"style="text-decoration:none"> Redémarrer le système</button>        
        <button class="Bouton" onclick="window.location.href = '/load?nav=rst';"style="text-decoration:none"> Gestion des données</button>
		%MAJ%
        <br>
      </div>

    
    
  </body>
</html>



)rawliteral";