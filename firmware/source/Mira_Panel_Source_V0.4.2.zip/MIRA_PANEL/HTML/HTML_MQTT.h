const char Page_MQTT[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>%APP% - MQTT</title>
<style>
:root{--bg:%LIGHTCOLOR%;--panel:%DARKCOLOR%;--active:%ACTIVECOLOR%;--txt:%TEXTCOLOR%;}
*{box-sizing:border-box} body{margin:0;background:var(--bg);font-family:Arial,sans-serif;color:#263238;text-align:center}
header{background:var(--panel);color:var(--txt);padding:22px 10px;position:sticky;top:0;z-index:3}
header a{color:var(--txt);text-decoration:none;margin:0 12px;font-weight:bold}
main{max-width:920px;margin:24px auto;padding:0 18px 40px}
.card{background:#fff;border-radius:18px;padding:22px;margin:18px 0;box-shadow:0 4px 18px rgba(0,0,0,.12)}
h1{margin:0 0 6px}.sub{opacity:.72;font-size:14px}
label{display:block;font-weight:bold;margin:18px 0 7px}
input[type=text],input[type=password],input[type=number]{width:100%%;max-width:620px;padding:12px 16px;border:2px solid #607d8b;border-radius:14px;font-size:20px;text-align:center}
.switchline{display:flex;justify-content:center;align-items:center;gap:14px;margin:14px 0 4px;font-size:20px;font-weight:bold}
.switchline input{width:26px;height:26px}
button{border:0;border-radius:18px;padding:13px 32px;background:var(--active);color:white;font-weight:bold;font-size:20px;cursor:pointer}
code{display:block;overflow-wrap:anywhere;font-size:16px;margin:6px 0;color:#37474f}
table{width:100%%;border-collapse:collapse;margin-top:12px}th,td{padding:10px;border-bottom:1px solid #cfd8dc;text-align:left}th{background:#263238;color:white}
.note{font-size:14px;opacity:.75;line-height:1.4}.status{font-weight:bold;color:#1565c0}
</style>
</head>
<body>
<header>
  <a href="/">Home</a>
  <a href="/load?nav=wifi">Réseau</a>
  <a href="/load?nav=mqtt">MQTT</a>
  <a href="/load?nav=params">Paramètres</a>
  <a href="/load?nav=system">Système</a>
</header>
<main>
  <div class="card">
    <h1>MQTT</h1>
    <div class="sub">Connexion MQTT de Mira Panel</div>
    <form action="/save?config=params" method="POST">
      <div class="switchline">
        <span>Activer MQTT</span>
        <input id="mqttActiveBox" type="checkbox" %MQTTCHECKED% onchange="document.getElementById('MQTT_Actif').value=this.checked?'1':'0'">
      </div>
      <input id="MQTT_Actif" name="MQTT_Actif" type="hidden" value="%MQTTACTIF%">

      <label>Nom de l'écran</label>
      <input name="MQTT_Nom" type="text" value="%MQTTNOM%">

      <label>Serveur / broker MQTT</label>
      <input name="MQTT_Serveur" type="text" value="%MQTTSERVEUR%" placeholder="192.168.1.x">

      <label>Port MQTT</label>
      <input name="MQTT_Port" type="number" min="1" max="65535" value="%MQTTPORT%">

      <label>Utilisateur MQTT</label>
      <input name="MQTT_Utilisateur" type="text" value="%MQTTUSER%">

      <label>Mot de passe MQTT</label>
      <input name="MQTT_Mot_de_passe" type="password" value="%MQTTPASS%">

      <p><button type="submit">Sauvegarder</button></p>
    </form>
  </div>

  <div class="card">
    <b>Actions MQTT</b>
    <code>mira/%MQTTNOM%/Actions/#topic#</code>
    <b>États MQTT</b>
    <code>mira/%MQTTNOM%/States/#topic#</code>
    <p class="note">Une action tactile est publiée dans <b>Actions</b>. Un message reçu dans <b>States</b> met à jour l'affichage uniquement et ne relance jamais une action Jeedom.</p>
  </div>

  <div class="card">
    <h2>Widgets / topics</h2>
    <table><thead><tr><th>Nom / topic</th><th>Type</th></tr></thead><tbody>%MQTTTABLE%</tbody></table>
  </div>
</main>
</body>
</html>
)rawliteral";
