#include "MiraPanelUI.h"
#include "MiraMqtt.h"
#include "MiraFrenchFont.h"
#include <WiFi.h>
#include <time.h>

lv_disp_draw_buf_t MiraPanelUI::_drawBuffer;
lv_color_t MiraPanelUI::_buf1[320 * 20];
lv_color_t MiraPanelUI::_buf2[320 * 20];
SC01PlusDisplay* MiraPanelUI::_displayForLvgl = nullptr;
MiraPanelUI* MiraPanelUI::_uiForLvgl = nullptr;

static const lv_color_t COL_TEXT    = lv_color_hex(0xF3F6F7);
static const lv_color_t COL_MUTED   = lv_color_hex(0xA8B2B8);
static const lv_color_t COL_ACCENT  = lv_color_hex(0x22BEEA);
static const lv_color_t COL_ACCENT2 = lv_color_hex(0x18637A);
static const lv_color_t COL_GREEN   = lv_color_hex(0x62D6A7);
static const lv_color_t COL_RED     = lv_color_hex(0xE36A6A);

static String roundRangeDisplayValue(int value, const String& unit) {
  String out = String(value);
  if (unit.startsWith("°")) {
    out += "°";
  } else if (unit.length()) {
    out += " ";
    out += unit;
  }
  return out;
}

static void makeBulbIcon(lv_obj_t* parent) {
  lv_obj_t* icon = lv_obj_create(parent);
  lv_obj_set_size(icon, 24, 28);
  lv_obj_clear_flag(icon, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_clear_flag(icon, LV_OBJ_FLAG_CLICKABLE);
  lv_obj_set_style_bg_opa(icon, LV_OPA_TRANSP, 0);
  lv_obj_set_style_border_width(icon, 0, 0);
  lv_obj_set_style_pad_all(icon, 0, 0);
  lv_obj_center(icon);

  lv_obj_t* head = lv_obj_create(icon);
  lv_obj_set_size(head, 15, 15);
  lv_obj_set_pos(head, 4, 1);
  lv_obj_clear_flag(head, LV_OBJ_FLAG_CLICKABLE);
  lv_obj_set_style_radius(head, LV_RADIUS_CIRCLE, 0);
  lv_obj_set_style_bg_color(head, lv_color_hex(0xDCEAF0), 0);
  lv_obj_set_style_bg_opa(head, LV_OPA_COVER, 0);
  lv_obj_set_style_border_width(head, 0, 0);

  lv_obj_t* neck = lv_obj_create(icon);
  lv_obj_set_size(neck, 9, 4);
  lv_obj_set_pos(neck, 7, 15);
  lv_obj_clear_flag(neck, LV_OBJ_FLAG_CLICKABLE);
  lv_obj_set_style_radius(neck, 2, 0);
  lv_obj_set_style_bg_color(neck, lv_color_hex(0xDCEAF0), 0);
  lv_obj_set_style_bg_opa(neck, LV_OPA_COVER, 0);
  lv_obj_set_style_border_width(neck, 0, 0);

  lv_obj_t* base = lv_obj_create(icon);
  lv_obj_set_size(base, 7, 4);
  lv_obj_set_pos(base, 8, 20);
  lv_obj_clear_flag(base, LV_OBJ_FLAG_CLICKABLE);
  lv_obj_set_style_radius(base, 2, 0);
  lv_obj_set_style_bg_color(base, lv_color_hex(0xDCEAF0), 0);
  lv_obj_set_style_bg_opa(base, LV_OPA_COVER, 0);
  lv_obj_set_style_border_width(base, 0, 0);
}

static void makeThermometerIcon(lv_obj_t* parent) {
  lv_obj_t* icon = lv_obj_create(parent);
  lv_obj_set_size(icon, 22, 30);
  lv_obj_clear_flag(icon, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_clear_flag(icon, LV_OBJ_FLAG_CLICKABLE);
  lv_obj_set_style_bg_opa(icon, LV_OPA_TRANSP, 0);
  lv_obj_set_style_border_width(icon, 0, 0);
  lv_obj_set_style_pad_all(icon, 0, 0);
  lv_obj_center(icon);

  lv_obj_t* stem = lv_obj_create(icon);
  lv_obj_set_size(stem, 7, 20);
  lv_obj_set_pos(stem, 7, 1);
  lv_obj_clear_flag(stem, LV_OBJ_FLAG_CLICKABLE);
  lv_obj_set_style_radius(stem, 4, 0);
  lv_obj_set_style_bg_opa(stem, LV_OPA_TRANSP, 0);
  lv_obj_set_style_border_color(stem, lv_color_hex(0xDCEAF0), 0);
  lv_obj_set_style_border_width(stem, 2, 0);

  lv_obj_t* bulb = lv_obj_create(icon);
  lv_obj_set_size(bulb, 12, 12);
  lv_obj_set_pos(bulb, 4, 17);
  lv_obj_clear_flag(bulb, LV_OBJ_FLAG_CLICKABLE);
  lv_obj_set_style_radius(bulb, LV_RADIUS_CIRCLE, 0);
  lv_obj_set_style_bg_color(bulb, lv_color_hex(0xDCEAF0), 0);
  lv_obj_set_style_bg_opa(bulb, LV_OPA_COVER, 0);
  lv_obj_set_style_border_width(bulb, 0, 0);
}

MiraPanelUI::MiraPanelUI(MiraPanelServer& server, SC01PlusDisplay& display)
  : _server(server), _display(display) {}

int MiraPanelUI::clampInt(int value, int minValue, int maxValue) {
  if (value < minValue) return minValue;
  if (value > maxValue) return maxValue;
  return value;
}

lv_color_t MiraPanelUI::colorBg() const {
  return _darkMode ? lv_color_hex(0x101417) : lv_color_hex(0x263238);
}

lv_color_t MiraPanelUI::colorPanel() const {
  return _darkMode ? lv_color_hex(0x1B2024) : lv_color_hex(0x34444B);
}

lv_color_t MiraPanelUI::colorPanel2() const {
  return _darkMode ? lv_color_hex(0x252C31) : lv_color_hex(0x41545C);
}

lv_color_t MiraPanelUI::colorBorder() const {
  return _darkMode ? lv_color_hex(0x30383D) : lv_color_hex(0x60727B);
}

void MiraPanelUI::displayFlush(lv_disp_drv_t* disp, const lv_area_t* area, lv_color_t* color_p) {
  if (!_displayForLvgl) {
    lv_disp_flush_ready(disp);
    return;
  }

  if (_displayForLvgl->getStartCount() == 0) _displayForLvgl->startWrite();

  _displayForLvgl->pushImageDMA(
    area->x1,
    area->y1,
    area->x2 - area->x1 + 1,
    area->y2 - area->y1 + 1,
    (lgfx::swap565_t*)&color_p->full
  );

  lv_disp_flush_ready(disp);
}

void MiraPanelUI::touchRead(lv_indev_drv_t* indev, lv_indev_data_t* data) {
  (void)indev;
  uint16_t x = 0, y = 0;
  data->state = LV_INDEV_STATE_REL;

  if (_displayForLvgl && _displayForLvgl->getTouch(&x, &y)) {
    bool wasSleeping = false;
    if (_uiForLvgl) {
      wasSleeping = _uiForLvgl->_sleeping;
      _uiForLvgl->noteActivity();
    }

    // Le premier toucher sert uniquement a reveiller l'ecran.
    if (wasSleeping) return;

    data->state = LV_INDEV_STATE_PR;
    data->point.x = x;
    data->point.y = y;
  }
}


void MiraPanelUI::setMqtt(MiraMqtt* mqtt) {
  _mqtt = mqtt;
}

String MiraPanelUI::normalizeMqttTopicName(const String& value) {
  String out = value;
  out.trim();
  out.replace(" ", "_");
  out.replace("/", "_");
  out.replace("#", "_");
  out.replace("+", "_");
  out.toLowerCase();
  return out;
}

String MiraPanelUI::mqttPayloadValue(const String& payload) {
  String value = payload;
  value.trim();

  // Le firmware accepte egalement un petit JSON {"value":...} afin de
  // faciliter les tests avec jMQTT/Node-RED, tout en gardant la valeur brute
  // comme format principal compatible avec l'esprit du firmware original.
  if (value.startsWith("{")) {
    DynamicJsonDocument doc(512);
    if (deserializeJson(doc, value) == DeserializationError::Ok) {
      if (doc.containsKey("value")) {
        if (doc["value"].is<const char*>()) return String(doc["value"].as<const char*>());
        String out;
        serializeJson(doc["value"], out);
        if (out.startsWith("\"") && out.endsWith("\"") && out.length() >= 2) {
          out = out.substring(1, out.length() - 1);
        }
        return out;
      }
    }
  }
  return value;
}

int MiraPanelUI::findBindingByMqttTopic(const String& topic) const {
  String wanted = topic;
  wanted.trim();
  String wantedNorm = normalizeMqttTopicName(wanted);

  for (uint8_t i = 0; i < _bindingCount; ++i) {
    const Binding& b = _bindings[i];
    if (b.name == wanted) return i;
    if (normalizeMqttTopicName(b.name) == wantedNorm) return i;
  }
  return -1;
}

void MiraPanelUI::publishMqttAction(const Binding& b, const String& payload) {
  if (!_mqtt || !_mqtt->enabled()) return;
  _mqtt->publishAction(b.name, payload);
}

void MiraPanelUI::handleMqttState(const String& topic, const String& rawPayload) {
  int idx = findBindingByMqttTopic(topic);
  if (idx < 0 || idx >= _bindingCount) {
    Serial.println("[MQTT] Etat ignore, widget inconnu: " + topic);
    return;
  }

  Binding& b = _bindings[(uint8_t)idx];
  String payload = mqttPayloadValue(rawPayload);
  payload.trim();

  // IMPORTANT : un State MQTT ne declenche jamais IndexSetEvent().
  // On met seulement a jour l'etat interne + l'affichage, afin d'eviter
  // toute boucle ou action domotique au redemarrage de l'ecran.
  _suppressEvents = true;

  if (b.type == W_INFO) {
    _server.IndexSetInfo(b.id, payload);
    String txt = payload + (b.unit.length() ? " " + b.unit : "");
    if (b.valueLabel) lv_label_set_text(b.valueLabel, txt.c_str());
  }
  else if (b.type == W_TOGGLE) {
    String lower = payload;
    lower.toLowerCase();
    bool on = (lower == "1" || lower == "on" || lower == "true" || lower == "oui" || lower == "actif");
    int stateId = on ? b.idOn : b.idOff;
    _server.IndexSetToggle(stateId);
    if (b.control) {
      if (on) lv_obj_add_state(b.control, LV_STATE_CHECKED);
      else lv_obj_clear_state(b.control, LV_STATE_CHECKED);
    }
    if (b.stateLabel) {
      lv_label_set_text(b.stateLabel, on ? "ON" : "OFF");
      lv_obj_set_style_text_color(b.stateLabel, on ? COL_GREEN : COL_MUTED, 0);
    }
  }
  else if (b.type == W_RANGE || b.type == W_ROUNDRANGE) {
    int value = clampInt(payload.toInt(), b.minValue, b.maxValue);
    b.currentValue = value;
    _server.IndexSetRange(b.id, value);
    if (b.type == W_RANGE && b.control) lv_slider_set_value(b.control, value, LV_ANIM_OFF);
    if (b.type == W_ROUNDRANGE && b.control) lv_arc_set_value(b.control, value);
    if (b.valueLabel) {
      if (b.type == W_ROUNDRANGE) {
        String txt = roundRangeDisplayValue(value, b.unit);
        lv_label_set_text(b.valueLabel, txt.c_str());
      } else {
        lv_label_set_text_fmt(b.valueLabel, "%d%s%s", value, b.unit.length() ? " " : "", b.unit.c_str());
      }
    }
  }
  else if (b.type == W_LIST || b.type == W_LISTBUTTON) {
    int selected = -1;
    bool numeric = payload.length() > 0;
    for (size_t i = 0; i < payload.length(); ++i) {
      if (!isDigit(payload[i]) && !(i == 0 && payload[i] == '-')) { numeric = false; break; }
    }
    if (numeric) {
      int n = payload.toInt();
      if (n >= 0 && n < b.listCount) selected = n;
    }
    if (selected < 0) {
      for (uint8_t i = 0; i < b.listCount; ++i) {
        if (b.listLabels[i].equalsIgnoreCase(payload)) { selected = i; break; }
      }
    }
    if (selected >= 0) {
      b.selectedIndex = (int8_t)selected;
      _server.IndexSetList(b.listIds[selected]);
      updateListVisual(b);
    }
  }
  else if (b.type == W_COLOR) {
    int r = 0, g = 0, bl = 0;
    bool ok = false;
    String c = payload;
    c.trim();
    if (c.startsWith("#") && c.length() == 7) {
      long rgb = strtol(c.substring(1).c_str(), nullptr, 16);
      r = (rgb >> 16) & 0xFF;
      g = (rgb >> 8) & 0xFF;
      bl = rgb & 0xFF;
      ok = true;
    } else {
      int p1 = c.indexOf(',');
      int p2 = c.indexOf(',', p1 + 1);
      if (p1 > 0 && p2 > p1) {
        r = clampInt(c.substring(0, p1).toInt(), 0, 255);
        g = clampInt(c.substring(p1 + 1, p2).toInt(), 0, 255);
        bl = clampInt(c.substring(p2 + 1).toInt(), 0, 255);
        ok = true;
      }
    }
    if (ok) {
      _server.IndexSetColor(b.id, r, g, bl);
      if (b.control) lv_colorwheel_set_rgb(b.control, lv_color_make(r, g, bl));
    }
  }

  _suppressEvents = false;
  noteActivity();
}

void MiraPanelUI::begin() {
  _displayForLvgl = &_display;
  _uiForLvgl = this;

  _prefs.begin("miraui", false);
  _brightness = _prefs.getUChar("bright", 220);
  _darkMode = _prefs.getBool("dark", true);
  _returnHomeEnabled = _prefs.getBool("home", true);
  _sleepEnabled = _prefs.getBool("sleep", true);
  _clockInSleep = _prefs.getBool("clock", true);

  if (_brightness < 30) _brightness = 30;

  _display.begin();
  _display.setBrightness(_brightness);
  _display.setRotation(0);

  lv_init();
  lv_disp_draw_buf_init(&_drawBuffer, _buf1, _buf2, 320 * 20);

  static lv_disp_drv_t dispDrv;
  lv_disp_drv_init(&dispDrv);
  dispDrv.hor_res = 320;
  dispDrv.ver_res = 480;
  dispDrv.flush_cb = displayFlush;
  dispDrv.draw_buf = &_drawBuffer;
  lv_disp_drv_register(&dispDrv);

  static lv_indev_drv_t indevDrv;
  lv_indev_drv_init(&indevDrv);
  indevDrv.type = LV_INDEV_TYPE_POINTER;
  indevDrv.read_cb = touchRead;
  lv_indev_drv_register(&indevDrv);

  _screen = lv_obj_create(nullptr);
  lv_obj_clear_flag(_screen, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_set_style_border_width(_screen, 0, 0);
  lv_obj_set_style_pad_all(_screen, 0, 0);
  lv_scr_load(_screen);

  for (uint8_t i = 0; i < PAGE_COUNT; ++i) {
    _pages[i] = lv_obj_create(_screen);
    lv_obj_set_pos(_pages[i], 0, 0);
    lv_obj_set_size(_pages[i], 320, 434);
    lv_obj_set_style_bg_opa(_pages[i], LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(_pages[i], 0, 0);
    lv_obj_set_style_pad_all(_pages[i], 7, 0);
    lv_obj_set_style_pad_row(_pages[i], 5, 0);
    lv_obj_set_flex_flow(_pages[i], LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(_pages[i], LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_scroll_dir(_pages[i], LV_DIR_VER);
    lv_obj_set_scrollbar_mode(_pages[i], LV_SCROLLBAR_MODE_AUTO);
    if (i != 0) lv_obj_add_flag(_pages[i], LV_OBJ_FLAG_HIDDEN);
  }

  // Navigation inspirée du firmware visible dans la vidéo Mira :
  // bandeau noir, trois icônes seulement, la page courante n'est pas affichée.
  _nav = lv_obj_create(_screen);
  lv_obj_set_pos(_nav, 0, 434);
  lv_obj_set_size(_nav, 320, 46);
  lv_obj_clear_flag(_nav, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_set_style_border_width(_nav, 0, 0);
  lv_obj_set_style_radius(_nav, 0, 0);
  lv_obj_set_style_pad_all(_nav, 0, 0);

  // L'original utilise 3 destinations par page, avec un ordre qui change
  // selon l'ecran courant. Les boutons sont donc places manuellement.
  const char* icons[PAGE_COUNT] = {LV_SYMBOL_HOME, "", "", LV_SYMBOL_SETTINGS};
  for (uint8_t i = 0; i < PAGE_COUNT; ++i) {
    _navButtons[i] = lv_btn_create(_nav);
    lv_obj_set_size(_navButtons[i], 106, 44);
    lv_obj_set_style_bg_opa(_navButtons[i], LV_OPA_TRANSP, 0);
    lv_obj_set_style_bg_opa(_navButtons[i], LV_OPA_20, LV_STATE_PRESSED);
    lv_obj_set_style_bg_color(_navButtons[i], COL_ACCENT, LV_STATE_PRESSED);
    lv_obj_set_style_radius(_navButtons[i], 0, 0);
    lv_obj_set_style_border_width(_navButtons[i], 0, 0);
    lv_obj_set_style_shadow_width(_navButtons[i], 0, 0);
    lv_obj_add_event_cb(_navButtons[i], onNav, LV_EVENT_CLICKED, (void*)(uintptr_t)i);

    if (i == 1) {
      makeBulbIcon(_navButtons[i]);
    } else if (i == 2) {
      makeThermometerIcon(_navButtons[i]);
    } else {
      lv_obj_t* lbl = lv_label_create(_navButtons[i]);
      lv_label_set_text(lbl, icons[i]);
      lv_obj_set_style_text_font(lbl, &lv_font_montserrat_20, 0);
      lv_obj_set_style_text_color(lbl, lv_color_hex(0xDCEAF0), 0);
      lv_obj_center(lbl);
    }
  }

  buildSettingsPage();

  _sleepOverlay = lv_obj_create(_screen);
  lv_obj_set_pos(_sleepOverlay, 0, 0);
  lv_obj_set_size(_sleepOverlay, 320, 480);
  lv_obj_clear_flag(_sleepOverlay, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_set_style_bg_color(_sleepOverlay, lv_color_hex(0x000000), 0);
  lv_obj_set_style_bg_opa(_sleepOverlay, LV_OPA_COVER, 0);
  lv_obj_set_style_border_width(_sleepOverlay, 0, 0);
  lv_obj_set_style_radius(_sleepOverlay, 0, 0);

  _sleepClock = lv_label_create(_sleepOverlay);
  // Veille inspiree du firmware officiel : heure seule, tres lisible.
  lv_label_set_text(_sleepClock, "--:--");
  lv_obj_set_style_text_color(_sleepClock, COL_MUTED, 0);
  lv_obj_set_style_text_font(_sleepClock, &lv_font_montserrat_48, 0);
  lv_obj_set_style_text_align(_sleepClock, LV_TEXT_ALIGN_CENTER, 0);
  lv_obj_align(_sleepClock, LV_ALIGN_CENTER, 0, -48);
  lv_obj_add_flag(_sleepOverlay, LV_OBJ_FLAG_HIDDEN);

  _lastActivity = millis();
  applyTheme();
  setNavActive(0);
}

MiraPanelUI::EventContext* MiraPanelUI::makeContext(uint8_t bindingIndex, int8_t itemIndex) {
  if (_eventCtxCount >= MAX_EVENT_CONTEXTS) return nullptr;
  EventContext& c = _eventCtx[_eventCtxCount++];
  c.ui = this;
  c.bindingIndex = bindingIndex;
  c.itemIndex = itemIndex;
  return &c;
}

uint8_t MiraPanelUI::addBinding() {
  if (_bindingCount >= MAX_BINDINGS) return 0xFF;
  uint8_t idx = _bindingCount++;
  _bindings[idx] = Binding();
  return idx;
}

uint8_t MiraPanelUI::pageIndex(const String& location) const {
  if (location == "lumieres") return 1;
  if (location == "temperatures") return 2;
  return 0;
}

lv_obj_t* MiraPanelUI::makeCard(uint8_t page, lv_coord_t height) {
  // Dans le firmware original, les pages principales sont très plates :
  // pas de cartes visibles, juste les contrôles sur le fond de page.
  lv_obj_t* card = lv_obj_create(_pages[page]);
  lv_obj_set_width(card, 304);
  lv_obj_set_height(card, height == LV_SIZE_CONTENT ? LV_SIZE_CONTENT : height);
  lv_obj_set_style_bg_opa(card, LV_OPA_TRANSP, 0);
  lv_obj_set_style_border_width(card, 0, 0);
  lv_obj_set_style_radius(card, 0, 0);
  lv_obj_set_style_shadow_width(card, 0, 0);
  lv_obj_set_style_pad_all(card, 9, 0);
  lv_obj_set_style_pad_row(card, 7, 0);
  return card;
}

lv_obj_t* MiraPanelUI::makeSettingsCard(lv_coord_t height) {
  lv_obj_t* card = lv_obj_create(_pages[3]);
  lv_obj_set_width(card, 304);
  lv_obj_set_height(card, height);
  lv_obj_clear_flag(card, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_set_style_bg_color(card, colorPanel(), 0);
  lv_obj_set_style_border_color(card, colorBorder(), 0);
  lv_obj_set_style_border_width(card, 1, 0);
  lv_obj_set_style_radius(card, 11, 0);
  lv_obj_set_style_pad_all(card, 8, 0);
  lv_obj_set_style_pad_row(card, 4, 0);
  lv_obj_set_flex_flow(card, LV_FLEX_FLOW_COLUMN);
  lv_obj_set_flex_align(card, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER);
  return card;
}

lv_obj_t* MiraPanelUI::makeTransparentRow(lv_obj_t* parent, lv_coord_t height) {
  lv_obj_t* row = lv_obj_create(parent);
  lv_obj_set_width(row, 284);
  lv_obj_set_height(row, height);
  lv_obj_clear_flag(row, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_set_style_bg_opa(row, LV_OPA_TRANSP, 0);
  lv_obj_set_style_border_width(row, 0, 0);
  lv_obj_set_style_pad_all(row, 0, 0);
  lv_obj_set_flex_flow(row, LV_FLEX_FLOW_ROW);
  lv_obj_set_flex_align(row, LV_FLEX_ALIGN_SPACE_BETWEEN, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
  return row;
}

void MiraPanelUI::makeNameLabel(lv_obj_t* parent, const String& text) {
  lv_obj_t* name = lv_label_create(parent);
  lv_label_set_text(name, text.c_str());
  lv_obj_set_style_text_color(name, COL_TEXT, 0);
  lv_obj_set_style_text_font(name, &mira_font_fr_14, 0);
}

void MiraPanelUI::clearDynamicPages() {
  for (uint8_t i = 0; i < 3; ++i) lv_obj_clean(_pages[i]);
  _bindingCount = 0;
  _eventCtxCount = 0;
  _dateTimeLabel = nullptr;
  _dateSubLabel = nullptr;
}

void MiraPanelUI::reloadFromMiraJson() {
  Serial.println("[Mira Panel] Reprogrammation Mira recue -> reconstruction a chaud");
  _server.ResetActionsForLvgl();
  clearDynamicPages();
  buildFromMiraJson();
  applyTheme();
  showPage(0);
  Serial.println("[Mira Panel] Interface et table d'actions reconstruites sans RST");
}

void MiraPanelUI::buildFromMiraJson() {
  String json = _server.GetJsonLvgl();
  DynamicJsonDocument doc(8192);
  DeserializationError err = deserializeJson(doc, json);

  if (err || !doc["lvgl"].is<JsonArray>()) {
    lv_obj_t* msg = lv_label_create(_pages[0]);
    lv_label_set_text(msg, "Configuration Mira illisible");
    lv_obj_set_style_text_color(msg, COL_RED, 0);
    return;
  }

  JsonArray arr = doc["lvgl"].as<JsonArray>();
  if (arr.size() == 0) {
    lv_obj_t* card = makeCard(0, 120);
    lv_obj_t* msg = lv_label_create(card);
    if (_server.IsSetupMode()) {
      lv_label_set_text(msg, "Configuration initiale\n\nConnectez-vous au Wi-Fi\nMira Panel");
    } else {
      lv_label_set_text(msg, "Aucune interface programmée.\n\nDans Jeedom > Mira Panel :\nProgrammer un écran ESP32.");
    }
    lv_obj_set_style_text_color(msg, COL_TEXT, 0);
    lv_obj_set_style_text_align(msg, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_set_style_text_font(msg, &mira_font_fr_14, 0);
    lv_obj_center(msg);
    return;
  }

  for (JsonObject obj : arr) registerAndCreate(obj);
}

void MiraPanelUI::registerAndCreate(JsonObject obj) {
  if (_bindingCount >= MAX_BINDINGS) return;

  String type = obj["type"] | "";
  String name = obj["name"] | "";
  String location = obj["emplacement"] | "accueil";
  String unit = obj["unit"] | "";
  String sMin = obj["min"] | "";
  String sMax = obj["max"] | "";
  String sValue = obj["value"] | "";

  uint8_t idx = addBinding();
  if (idx == 0xFF) return;
  Binding& b = _bindings[idx];
  b.name = name;
  b.location = location;
  b.unit = unit;

  if (type == "info") {
    b.type = W_INFO;
    b.id = _server.IndexAddInfo(name, unit);
    createInfo(idx);
  }
  else if (type == "button") {
    b.type = W_BUTTON;
    b.id = _server.IndexAddButton(name);
    createButton(idx);
  }
  else if (type == "toggle") {
    b.type = W_TOGGLE;
    int* ids = _server.IndexAddToggle(name, "Off", "On", "Off");
    b.idOff = ids[0];
    b.idOn = ids[1];
    createToggle(idx);
  }
  else if (type == "range" || type == "roundrange") {
    b.type = (type == "range") ? W_RANGE : W_ROUNDRANGE;
    b.minValue = sMin.length() ? sMin.toInt() : 0;
    b.maxValue = sMax.length() ? sMax.toInt() : 100;
    if (b.maxValue <= b.minValue) b.maxValue = b.minValue + 100;
    b.currentValue = sValue.length() ? sValue.toInt() : b.minValue;
    b.currentValue = clampInt(b.currentValue, b.minValue, b.maxValue);
    b.id = _server.IndexAddRange(name, b.minValue, b.maxValue, b.currentValue);
    if (b.type == W_RANGE) createRange(idx);
    else createRoundRange(idx);
  }
  else if (type == "color") {
    b.type = W_COLOR;
    b.id = _server.IndexAddColor(name, 50, 120, 180);
    createColor(idx);
  }
  else if (type == "list" || type == "listbutton") {
    b.type = (type == "list") ? W_LIST : W_LISTBUTTON;

    String options = sValue;
    int start = 0;
    while (start <= options.length() && b.listCount < MAX_LIST_ITEMS) {
      int sep = options.indexOf('|', start);
      String item = (sep < 0) ? options.substring(start) : options.substring(start, sep);
      item.trim();
      if (item.length()) {
        int id = _server.IndexAddList(name, item, item);
        b.listIds[b.listCount] = id;
        b.listLabels[b.listCount] = item;
        b.listCount++;
      }
      if (sep < 0) break;
      start = sep + 1;
    }
    createList(idx, b.type == W_LISTBUTTON);
  }
  else if (type == "datetime") {
    b.type = W_DATETIME;
    createDateTime(idx);
  }
  else {
    b.type = W_UNSUPPORTED;
    createUnsupported(idx, type);
  }
}

void MiraPanelUI::createInfo(uint8_t idx) {
  Binding& b = _bindings[idx];

  // V0.3.6 : retour a une ligne flex centree, comme l'original.
  // La V0.3.5 avait tente de contourner le bug des accents par des zones
  // fixes/clipees. La vraie cause etait l'advance width de la police FR
  // (1/16 px interprete comme px). Une fois la police corrigee, on laisse
  // LVGL calculer naturellement les largeurs : "Luminosite: 8 Lux",
  // "Temperature: 22.3 C", etc. restent d'un seul bloc visuel.
  b.card = makeCard(pageIndex(b.location), 36);
  lv_obj_clear_flag(b.card, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_set_style_pad_left(b.card, 4, 0);
  lv_obj_set_style_pad_right(b.card, 4, 0);
  lv_obj_set_style_pad_top(b.card, 0, 0);
  lv_obj_set_style_pad_bottom(b.card, 0, 0);
  lv_obj_set_style_pad_column(b.card, 6, 0);
  lv_obj_set_flex_flow(b.card, LV_FLEX_FLOW_ROW);
  lv_obj_set_flex_align(b.card, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);

  String displayName = b.name;
  if (displayName.length() && !displayName.endsWith(":")) displayName += ":";

  lv_obj_t* name = lv_label_create(b.card);
  lv_label_set_text(name, displayName.c_str());
  lv_label_set_long_mode(name, LV_LABEL_LONG_CLIP);
  lv_obj_set_style_text_color(name, COL_TEXT, 0);
  lv_obj_set_style_text_font(name, &mira_font_fr_14, 0);

  b.valueLabel = lv_label_create(b.card);
  String txt = String("--") + (b.unit.length() ? " " + b.unit : "");
  lv_label_set_text(b.valueLabel, txt.c_str());
  lv_label_set_long_mode(b.valueLabel, LV_LABEL_LONG_CLIP);
  lv_obj_set_style_text_color(b.valueLabel, COL_ACCENT, 0);
  lv_obj_set_style_text_font(b.valueLabel, &lv_font_montserrat_16, 0);
}

void MiraPanelUI::createButton(uint8_t idx) {
  Binding& b = _bindings[idx];
  b.card = makeCard(pageIndex(b.location), 62);
  b.control = lv_btn_create(b.card);
  lv_obj_set_size(b.control, 280, 42);
  lv_obj_center(b.control);
  lv_obj_set_style_bg_color(b.control, COL_ACCENT2, 0);
  lv_obj_set_style_bg_color(b.control, COL_ACCENT, LV_STATE_PRESSED);
  lv_obj_set_style_radius(b.control, 9, 0);
  EventContext* ctx = makeContext(idx);
  lv_obj_add_event_cb(b.control, onButton, LV_EVENT_CLICKED, ctx);
  lv_obj_t* lbl = lv_label_create(b.control);
  lv_label_set_text(lbl, b.name.c_str());
  lv_obj_set_style_text_color(lbl, COL_TEXT, 0);
  lv_obj_set_style_text_font(lbl, &mira_font_fr_14, 0);
  lv_obj_center(lbl);
}

void MiraPanelUI::createToggle(uint8_t idx) {
  Binding& b = _bindings[idx];
  b.card = makeCard(pageIndex(b.location), 64);
  lv_obj_set_flex_flow(b.card, LV_FLEX_FLOW_ROW);
  lv_obj_set_flex_align(b.card, LV_FLEX_ALIGN_SPACE_BETWEEN, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
  makeNameLabel(b.card, b.name);

  // Comme dans la vidéo : libellé à gauche, switch seul à droite.
  b.stateLabel = nullptr;
  b.control = lv_switch_create(b.card);
  lv_obj_set_size(b.control, 58, 30);
  lv_obj_set_style_bg_color(b.control, lv_color_hex(0x55616A), LV_PART_MAIN);
  lv_obj_set_style_bg_color(b.control, COL_ACCENT, LV_PART_INDICATOR | LV_STATE_CHECKED);
  lv_obj_set_style_bg_color(b.control, lv_color_hex(0xE6ECEF), LV_PART_KNOB);
  EventContext* ctx = makeContext(idx);
  lv_obj_add_event_cb(b.control, onToggle, LV_EVENT_VALUE_CHANGED, ctx);
}

void MiraPanelUI::createRange(uint8_t idx) {
  Binding& b = _bindings[idx];
  b.card = makeCard(pageIndex(b.location), 90);

  lv_obj_t* top = makeTransparentRow(b.card, 28);
  makeNameLabel(top, b.name);

  b.valueLabel = lv_label_create(top);
  lv_label_set_text_fmt(b.valueLabel, "%d%s%s", b.currentValue, b.unit.length() ? " " : "", b.unit.c_str());
  lv_obj_set_style_text_color(b.valueLabel, COL_ACCENT, 0);
  lv_obj_set_style_text_font(b.valueLabel, &lv_font_montserrat_16, 0);

  b.control = lv_slider_create(b.card);
  lv_obj_set_size(b.control, 280, 18);
  lv_slider_set_range(b.control, b.minValue, b.maxValue);
  lv_slider_set_value(b.control, b.currentValue, LV_ANIM_OFF);
  lv_obj_set_style_bg_color(b.control, COL_ACCENT2, LV_PART_INDICATOR);
  lv_obj_set_style_bg_color(b.control, COL_ACCENT, LV_PART_KNOB);
  EventContext* ctx = makeContext(idx);
  lv_obj_add_event_cb(b.control, onRange, LV_EVENT_ALL, ctx);
}

void MiraPanelUI::createRoundRange(uint8_t idx) {
  Binding& b = _bindings[idx];
  // Gros cadran central inspiré de la séquence 4:35 de la vidéo.
  b.card = makeCard(pageIndex(b.location), 260);

  lv_obj_t* name = lv_label_create(b.card);
  lv_label_set_text(name, b.name.c_str());
  lv_obj_set_style_text_color(name, COL_MUTED, 0);
  lv_obj_set_style_text_font(name, &mira_font_fr_14, 0);
  lv_obj_align(name, LV_ALIGN_TOP_MID, 0, 0);

  // Fond circulaire sombre visible aussi en theme clair, comme sur l'ecran officiel.
  lv_obj_t* dialPlate = lv_obj_create(b.card);
  lv_obj_set_size(dialPlate, 216, 216);
  lv_obj_set_style_radius(dialPlate, LV_RADIUS_CIRCLE, 0);
  lv_obj_set_style_bg_color(dialPlate, lv_color_hex(0x171D24), 0);
  lv_obj_set_style_bg_opa(dialPlate, LV_OPA_COVER, 0);
  lv_obj_set_style_border_color(dialPlate, lv_color_hex(0x49545E), 0);
  lv_obj_set_style_border_width(dialPlate, 1, 0);
  lv_obj_set_style_pad_all(dialPlate, 0, 0);
  lv_obj_clear_flag(dialPlate, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_clear_flag(dialPlate, LV_OBJ_FLAG_CLICKABLE);
  lv_obj_align(dialPlate, LV_ALIGN_TOP_MID, 0, 19);

  b.control = lv_arc_create(b.card);
  lv_obj_set_size(b.control, 200, 200);
  lv_arc_set_range(b.control, b.minValue, b.maxValue);
  lv_arc_set_value(b.control, b.currentValue);
  lv_arc_set_bg_angles(b.control, 135, 45);
  lv_obj_align(b.control, LV_ALIGN_TOP_MID, 0, 27);
  lv_obj_set_style_arc_width(b.control, 15, LV_PART_MAIN);
  lv_obj_set_style_arc_width(b.control, 15, LV_PART_INDICATOR);
  lv_obj_set_style_arc_color(b.control, lv_color_hex(0x1B2229), LV_PART_MAIN);
  lv_obj_set_style_arc_color(b.control, lv_color_hex(0x1478FF), LV_PART_INDICATOR);
  // L'original ne montre pas de grosse pastille blanche au bout de l'arc.
  // On garde le knob interactif mais visuellement transparent.
  lv_obj_set_style_bg_opa(b.control, LV_OPA_TRANSP, LV_PART_KNOB);
  lv_obj_set_style_border_width(b.control, 0, LV_PART_KNOB);
  lv_obj_set_style_pad_all(b.control, 0, LV_PART_KNOB);

  // Disque intérieur pour retrouver le rendu 'thermostat' du firmware original.
  lv_obj_t* inner = lv_obj_create(b.card);
  lv_obj_set_size(inner, 112, 112);
  lv_obj_set_style_radius(inner, LV_RADIUS_CIRCLE, 0);
  lv_obj_set_style_bg_color(inner, lv_color_hex(0x19212A), 0);
  lv_obj_set_style_bg_opa(inner, LV_OPA_COVER, 0);
  lv_obj_set_style_border_color(inner, lv_color_hex(0x53606A), 0);
  lv_obj_set_style_border_width(inner, 2, 0);
  lv_obj_clear_flag(inner, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_align(inner, LV_ALIGN_TOP_MID, 0, 71);

  b.valueLabel = lv_label_create(inner);
  String roundValue = roundRangeDisplayValue(b.currentValue, b.unit);
  lv_label_set_text(b.valueLabel, roundValue.c_str());
  lv_obj_set_style_text_color(b.valueLabel, COL_TEXT, 0);
  lv_obj_set_style_text_font(b.valueLabel, &lv_font_montserrat_28, 0);
  lv_obj_center(b.valueLabel);

  EventContext* ctx = makeContext(idx);
  lv_obj_add_event_cb(b.control, onRoundRange, LV_EVENT_ALL, ctx);
}

void MiraPanelUI::createList(uint8_t idx, bool asButtons) {
  Binding& b = _bindings[idx];

  if (b.listCount == 0) {
    createUnsupported(idx, "liste vide");
    return;
  }

  b.card = makeCard(pageIndex(b.location), asButtons ? LV_SIZE_CONTENT : 82);
  lv_obj_set_flex_flow(b.card, LV_FLEX_FLOW_COLUMN);
  lv_obj_set_flex_align(b.card, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
  lv_obj_set_style_pad_row(b.card, 5, 0);

  // Le firmware officiel centre le nom de la liste (ex. "Mode") au-dessus
  // du choix courant. Largeur fixe pour empecher toute coupure autour d'un accent.
  lv_obj_t* listName = lv_label_create(b.card);
  lv_label_set_text(listName, b.name.c_str());
  lv_obj_set_width(listName, 280);
  lv_label_set_long_mode(listName, LV_LABEL_LONG_CLIP);
  lv_obj_set_style_text_align(listName, LV_TEXT_ALIGN_CENTER, 0);
  lv_obj_set_style_text_color(listName, COL_TEXT, 0);
  lv_obj_set_style_text_font(listName, &mira_font_fr_14, 0);

  if (!asButtons) {
    b.control = lv_dropdown_create(b.card);
    lv_obj_set_width(b.control, 260);
    lv_obj_set_style_text_font(b.control, &mira_font_fr_14, 0);
    lv_obj_set_style_text_color(b.control, COL_TEXT, 0);
    lv_obj_set_style_bg_opa(b.control, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(b.control, 0, 0);
    lv_obj_set_style_radius(b.control, 0, 0);

    String opts;
    for (uint8_t i = 0; i < b.listCount; ++i) {
      if (i) opts += "\n";
      opts += b.listLabels[i];
    }
    lv_dropdown_set_options(b.control, opts.c_str());
    lv_dropdown_set_selected(b.control, 0);
    EventContext* ctx = makeContext(idx);
    lv_obj_add_event_cb(b.control, onList, LV_EVENT_VALUE_CHANGED, ctx);
  } else {
    lv_obj_t* wrap = lv_obj_create(b.card);
    lv_obj_set_width(wrap, 280);
    lv_obj_set_height(wrap, LV_SIZE_CONTENT);
    lv_obj_clear_flag(wrap, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_style_bg_opa(wrap, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(wrap, 0, 0);
    lv_obj_set_style_pad_all(wrap, 0, 0);
    lv_obj_set_style_pad_row(wrap, 5, 0);
    lv_obj_set_style_pad_column(wrap, 5, 0);
    lv_obj_set_flex_flow(wrap, LV_FLEX_FLOW_ROW_WRAP);

    for (uint8_t i = 0; i < b.listCount; ++i) {
      lv_obj_t* btn = lv_btn_create(wrap);
      b.listButtons[i] = btn;
      lv_obj_set_size(btn, 132, 38);
      EventContext* ctx = makeContext(idx, i);
      lv_obj_add_event_cb(btn, onListButton, LV_EVENT_CLICKED, ctx);
      lv_obj_t* lbl = lv_label_create(btn);
      lv_label_set_text(lbl, b.listLabels[i].c_str());
      lv_obj_set_style_text_color(lbl, COL_TEXT, 0);
      lv_obj_set_style_text_font(lbl, &mira_font_fr_14, 0);
      lv_obj_center(lbl);
    }
    updateListVisual(b);
  }
}

void MiraPanelUI::createColor(uint8_t idx) {
  Binding& b = _bindings[idx];
  b.card = makeCard(pageIndex(b.location), 210);
  makeNameLabel(b.card, b.name);
  b.control = lv_colorwheel_create(b.card, true);
  lv_obj_set_size(b.control, 160, 160);
  lv_obj_align(b.control, LV_ALIGN_CENTER, 0, 12);
  lv_colorwheel_set_rgb(b.control, lv_color_make(50, 120, 180));
  EventContext* ctx = makeContext(idx);
  lv_obj_add_event_cb(b.control, onColor, LV_EVENT_RELEASED, ctx);
}

void MiraPanelUI::createDateTime(uint8_t idx) {
  Binding& b = _bindings[idx];
  b.card = makeCard(pageIndex(b.location), 112);
  lv_obj_clear_flag(b.card, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_set_style_bg_color(b.card, colorPanel(), 0);
  lv_obj_set_style_bg_opa(b.card, LV_OPA_COVER, 0);
  lv_obj_set_style_border_color(b.card, colorBorder(), 0);
  lv_obj_set_style_border_width(b.card, 1, 0);
  lv_obj_set_style_radius(b.card, 8, 0);
  lv_obj_set_style_pad_all(b.card, 0, 0);

  b.valueLabel = lv_label_create(b.card);
  lv_label_set_text(b.valueLabel, "--:--");
  lv_obj_set_style_text_color(b.valueLabel, COL_TEXT, 0);
  lv_obj_set_style_text_font(b.valueLabel, &lv_font_montserrat_40, 0);
  lv_obj_set_style_text_align(b.valueLabel, LV_TEXT_ALIGN_CENTER, 0);
  lv_obj_align(b.valueLabel, LV_ALIGN_TOP_MID, 0, 6);

  _dateSubLabel = lv_label_create(b.card);
  lv_label_set_text(_dateSubLabel, "-- -- ----");
  lv_obj_set_width(_dateSubLabel, 286);
  lv_obj_set_style_text_color(_dateSubLabel, COL_MUTED, 0);
  lv_obj_set_style_text_font(_dateSubLabel, &mira_font_fr_14, 0);
  lv_obj_set_style_text_align(_dateSubLabel, LV_TEXT_ALIGN_CENTER, 0);
  lv_obj_align(_dateSubLabel, LV_ALIGN_TOP_MID, 0, 60);

  if (!_dateTimeLabel) _dateTimeLabel = b.valueLabel;
}

void MiraPanelUI::createUnsupported(uint8_t idx, const String& originalType) {
  Binding& b = _bindings[idx];
  b.card = makeCard(pageIndex(b.location), 62);
  lv_obj_t* lbl = lv_label_create(b.card);
  String txt = b.name.length() ? b.name : "Élément";
  txt += "\n[" + originalType + " : pas encore géré]";
  lv_label_set_text(lbl, txt.c_str());
  lv_obj_set_style_text_color(lbl, COL_MUTED, 0);
  lv_obj_set_style_text_font(lbl, &mira_font_fr_14, 0);
  lv_obj_set_style_text_align(lbl, LV_TEXT_ALIGN_CENTER, 0);
  lv_obj_center(lbl);
}

void MiraPanelUI::buildSettingsPage() {
  lv_obj_clean(_pages[3]);

  // V0.3.1 : la page Params utilise toute la hauteur gagnée en supprimant
  // le bandeau. Les cartes sont en colonne pour éviter les chevauchements.
  _settingsCards[0] = makeSettingsCard(40);
  lv_obj_t* title = lv_label_create(_settingsCards[0]);
  lv_label_set_text(title, "Paramètres");
  lv_obj_set_width(title, 286);
  lv_label_set_long_mode(title, LV_LABEL_LONG_CLIP);
  lv_obj_set_style_text_align(title, LV_TEXT_ALIGN_CENTER, 0);
  lv_obj_set_style_text_color(title, COL_TEXT, 0);
  lv_obj_set_style_text_font(title, &mira_font_fr_16, 0);
  lv_obj_align(title, LV_ALIGN_CENTER, 0, 0);

  _settingsCards[1] = makeSettingsCard(122);
  lv_obj_t* h1 = lv_label_create(_settingsCards[1]);
  lv_label_set_text(h1, "Affichage");
  lv_obj_set_style_text_color(h1, COL_ACCENT, 0);
  lv_obj_set_style_text_font(h1, &mira_font_fr_14, 0);

  lv_obj_t* brightRow = makeTransparentRow(_settingsCards[1], 28);
  lv_obj_t* brightLbl = lv_label_create(brightRow);
  lv_label_set_text(brightLbl, "Luminosité écran");
  lv_obj_set_style_text_color(brightLbl, COL_TEXT, 0);
  lv_obj_set_style_text_font(brightLbl, &mira_font_fr_12, 0);
  _brightnessValue = lv_label_create(brightRow);
  lv_label_set_text_fmt(_brightnessValue, "%u", _brightness);
  lv_obj_set_style_text_color(_brightnessValue, COL_ACCENT, 0);
  lv_obj_set_style_text_font(_brightnessValue, &mira_font_fr_12, 0);

  _brightnessSlider = lv_slider_create(_settingsCards[1]);
  lv_obj_set_size(_brightnessSlider, 280, 14);
  lv_slider_set_range(_brightnessSlider, 30, 255);
  lv_slider_set_value(_brightnessSlider, _brightness, LV_ANIM_OFF);
  lv_obj_set_style_bg_color(_brightnessSlider, COL_ACCENT2, LV_PART_INDICATOR);
  lv_obj_set_style_bg_color(_brightnessSlider, COL_ACCENT, LV_PART_KNOB);
  lv_obj_add_event_cb(_brightnessSlider, onBrightness, LV_EVENT_ALL, this);

  lv_obj_t* darkRow = makeTransparentRow(_settingsCards[1], 28);
  lv_obj_t* darkLbl = lv_label_create(darkRow);
  lv_label_set_text(darkLbl, "Mode sombre");
  lv_obj_set_style_text_color(darkLbl, COL_TEXT, 0);
  lv_obj_set_style_text_font(darkLbl, &mira_font_fr_12, 0);
  _darkSwitch = lv_switch_create(darkRow);
  lv_obj_set_size(_darkSwitch, 48, 25);
  if (_darkMode) lv_obj_add_state(_darkSwitch, LV_STATE_CHECKED);
  lv_obj_set_style_bg_color(_darkSwitch, COL_GREEN, LV_PART_INDICATOR | LV_STATE_CHECKED);
  lv_obj_add_event_cb(_darkSwitch, onDarkMode, LV_EVENT_VALUE_CHANGED, this);

  _settingsCards[2] = makeSettingsCard(72);
  lv_obj_t* h2 = lv_label_create(_settingsCards[2]);
  lv_label_set_text(h2, "Navigation");
  lv_obj_set_style_text_color(h2, COL_ACCENT, 0);
  lv_obj_set_style_text_font(h2, &mira_font_fr_14, 0);

  lv_obj_t* homeRow = makeTransparentRow(_settingsCards[2], 30);
  lv_obj_t* homeLbl = lv_label_create(homeRow);
  lv_label_set_text(homeLbl, "Retour accueil : 60 s");
  lv_obj_set_style_text_color(homeLbl, COL_TEXT, 0);
  lv_obj_set_style_text_font(homeLbl, &mira_font_fr_12, 0);
  _returnHomeSwitch = lv_switch_create(homeRow);
  lv_obj_set_size(_returnHomeSwitch, 48, 25);
  if (_returnHomeEnabled) lv_obj_add_state(_returnHomeSwitch, LV_STATE_CHECKED);
  lv_obj_set_style_bg_color(_returnHomeSwitch, COL_GREEN, LV_PART_INDICATOR | LV_STATE_CHECKED);
  lv_obj_add_event_cb(_returnHomeSwitch, onReturnHome, LV_EVENT_VALUE_CHANGED, this);

  _settingsCards[3] = makeSettingsCard(104);
  lv_obj_t* h3 = lv_label_create(_settingsCards[3]);
  lv_label_set_text(h3, "Veille");
  lv_obj_set_style_text_color(h3, COL_ACCENT, 0);
  lv_obj_set_style_text_font(h3, &mira_font_fr_14, 0);

  lv_obj_t* sleepRow = makeTransparentRow(_settingsCards[3], 30);
  lv_obj_t* sleepLbl = lv_label_create(sleepRow);
  lv_label_set_text(sleepLbl, "Mise en veille : 120 s");
  lv_obj_set_style_text_color(sleepLbl, COL_TEXT, 0);
  lv_obj_set_style_text_font(sleepLbl, &mira_font_fr_12, 0);
  _sleepSwitch = lv_switch_create(sleepRow);
  lv_obj_set_size(_sleepSwitch, 48, 25);
  if (_sleepEnabled) lv_obj_add_state(_sleepSwitch, LV_STATE_CHECKED);
  lv_obj_set_style_bg_color(_sleepSwitch, COL_GREEN, LV_PART_INDICATOR | LV_STATE_CHECKED);
  lv_obj_add_event_cb(_sleepSwitch, onSleepMode, LV_EVENT_VALUE_CHANGED, this);

  lv_obj_t* clockRow = makeTransparentRow(_settingsCards[3], 30);
  lv_obj_t* clockLbl = lv_label_create(clockRow);
  lv_label_set_text(clockLbl, "Horloge en veille");
  lv_obj_set_style_text_color(clockLbl, COL_TEXT, 0);
  lv_obj_set_style_text_font(clockLbl, &mira_font_fr_12, 0);
  _clockSleepSwitch = lv_switch_create(clockRow);
  lv_obj_set_size(_clockSleepSwitch, 48, 25);
  if (_clockInSleep) lv_obj_add_state(_clockSleepSwitch, LV_STATE_CHECKED);
  lv_obj_set_style_bg_color(_clockSleepSwitch, COL_GREEN, LV_PART_INDICATOR | LV_STATE_CHECKED);
  lv_obj_add_event_cb(_clockSleepSwitch, onClockSleep, LV_EVENT_VALUE_CHANGED, this);
}

void MiraPanelUI::applyTheme() {
  if (!_screen) return;

  lv_obj_set_style_bg_color(_screen, colorBg(), 0);
  lv_obj_set_style_bg_opa(_screen, LV_OPA_COVER, 0);
  if (_nav) {
    lv_obj_set_style_bg_color(_nav, lv_color_hex(0x101419), 0);
    lv_obj_set_style_bg_opa(_nav, LV_OPA_COVER, 0);
  }

  for (uint8_t i = 0; i < PAGE_COUNT; ++i) {
    if (_pages[i]) lv_obj_set_style_bg_color(_pages[i], colorBg(), 0);
  }

  for (uint8_t i = 0; i < _bindingCount; ++i) {
    if (_bindings[i].card) {
      if (_bindings[i].type == W_DATETIME) {
        lv_obj_set_style_bg_color(_bindings[i].card, colorPanel(), 0);
        lv_obj_set_style_bg_opa(_bindings[i].card, LV_OPA_COVER, 0);
        lv_obj_set_style_border_color(_bindings[i].card, colorBorder(), 0);
        lv_obj_set_style_border_width(_bindings[i].card, 1, 0);
        lv_obj_set_style_radius(_bindings[i].card, 8, 0);
      } else {
        lv_obj_set_style_bg_opa(_bindings[i].card, LV_OPA_TRANSP, 0);
        lv_obj_set_style_border_width(_bindings[i].card, 0, 0);
      }
    }
    if (_bindings[i].type == W_ROUNDRANGE && _bindings[i].control) {
      lv_obj_set_style_arc_color(_bindings[i].control, colorPanel2(), LV_PART_MAIN);
    }
  }

  for (uint8_t i = 0; i < 4; ++i) {
    if (_settingsCards[i]) {
      lv_obj_set_style_bg_color(_settingsCards[i], colorPanel(), 0);
      lv_obj_set_style_border_color(_settingsCards[i], colorBorder(), 0);
    }
  }

  setNavActive(_currentPage);
}

void MiraPanelUI::setNavActive(uint8_t index) {
  // Ordres releves sur les captures officielles :
  // Accueil      -> Lumiere | Parametres | Temperature
  // Lumieres     -> Temperature | Accueil | Parametres
  // Temperatures -> Lumiere | Accueil | Parametres
  // Parametres   -> Lumiere | Accueil | Temperature
  static const uint8_t order[PAGE_COUNT][3] = {
    {1, 3, 2},
    {2, 0, 3},
    {1, 0, 3},
    {1, 0, 2}
  };

  if (index >= PAGE_COUNT) index = 0;

  for (uint8_t i = 0; i < PAGE_COUNT; ++i) {
    if (_navButtons[i]) lv_obj_add_flag(_navButtons[i], LV_OBJ_FLAG_HIDDEN);
  }

  for (uint8_t slot = 0; slot < 3; ++slot) {
    uint8_t page = order[index][slot];
    lv_obj_t* btn = _navButtons[page];
    if (!btn) continue;
    lv_obj_set_pos(btn, 1 + slot * 106, 1);
    lv_obj_clear_flag(btn, LV_OBJ_FLAG_HIDDEN);
  }
}

void MiraPanelUI::showPage(uint8_t index) {
  if (index >= PAGE_COUNT) return;
  for (uint8_t i = 0; i < PAGE_COUNT; ++i) {
    if (i == index) lv_obj_clear_flag(_pages[i], LV_OBJ_FLAG_HIDDEN);
    else lv_obj_add_flag(_pages[i], LV_OBJ_FLAG_HIDDEN);
  }
  _currentPage = index;
  setNavActive(index);
  noteActivity();
}

void MiraPanelUI::onNav(lv_event_t* e) {
  if (!_uiForLvgl) return;
  uint8_t index = (uint8_t)(uintptr_t)lv_event_get_user_data(e);
  _uiForLvgl->showPage(index);
}

void MiraPanelUI::onButton(lv_event_t* e) {
  EventContext* ctx = static_cast<EventContext*>(lv_event_get_user_data(e));
  if (!ctx || !ctx->ui) return;
  MiraPanelUI& ui = *ctx->ui;
  if (ui._suppressEvents || ctx->bindingIndex >= ui._bindingCount) return;
  ui.noteActivity();
  Binding& b = ui._bindings[ctx->bindingIndex];
  ui._server.IndexSetEvent(b.id);
  ui.publishMqttAction(b, "1");
}

void MiraPanelUI::onToggle(lv_event_t* e) {
  EventContext* ctx = static_cast<EventContext*>(lv_event_get_user_data(e));
  if (!ctx || !ctx->ui) return;
  MiraPanelUI& ui = *ctx->ui;
  if (ui._suppressEvents || ctx->bindingIndex >= ui._bindingCount) return;
  Binding& b = ui._bindings[ctx->bindingIndex];
  bool on = lv_obj_has_state(lv_event_get_target(e), LV_STATE_CHECKED);
  int id = on ? b.idOn : b.idOff;
  if (b.stateLabel) {
    lv_label_set_text(b.stateLabel, on ? "ON" : "OFF");
    lv_obj_set_style_text_color(b.stateLabel, on ? COL_GREEN : COL_MUTED, 0);
  }
  ui.noteActivity();
  ui._server.IndexSetToggle(id);
  ui._server.IndexSetEvent(id);
  ui.publishMqttAction(b, on ? "1" : "0");
}

void MiraPanelUI::onRange(lv_event_t* e) {
  EventContext* ctx = static_cast<EventContext*>(lv_event_get_user_data(e));
  if (!ctx || !ctx->ui) return;
  MiraPanelUI& ui = *ctx->ui;
  if (ctx->bindingIndex >= ui._bindingCount) return;
  Binding& b = ui._bindings[ctx->bindingIndex];
  lv_event_code_t code = lv_event_get_code(e);
  int value = lv_slider_get_value(lv_event_get_target(e));
  b.currentValue = value;
  if (b.valueLabel) lv_label_set_text_fmt(b.valueLabel, "%d%s%s", value, b.unit.length() ? " " : "", b.unit.c_str());
  ui.noteActivity();
  if (code == LV_EVENT_RELEASED && !ui._suppressEvents) {
    ui._server.IndexSetRange(b.id, value);
    ui._server.IndexSetEvent(b.id);
    ui.publishMqttAction(b, String(value));
  }
}

void MiraPanelUI::onRoundRange(lv_event_t* e) {
  EventContext* ctx = static_cast<EventContext*>(lv_event_get_user_data(e));
  if (!ctx || !ctx->ui) return;
  MiraPanelUI& ui = *ctx->ui;
  if (ctx->bindingIndex >= ui._bindingCount) return;
  Binding& b = ui._bindings[ctx->bindingIndex];
  lv_event_code_t code = lv_event_get_code(e);
  int value = lv_arc_get_value(lv_event_get_target(e));
  b.currentValue = value;
  if (b.valueLabel) {
    String txt = roundRangeDisplayValue(value, b.unit);
    lv_label_set_text(b.valueLabel, txt.c_str());
  }
  ui.noteActivity();
  if (code == LV_EVENT_RELEASED && !ui._suppressEvents) {
    ui._server.IndexSetRange(b.id, value);
    ui._server.IndexSetEvent(b.id);
    ui.publishMqttAction(b, String(value));
  }
}

void MiraPanelUI::onList(lv_event_t* e) {
  EventContext* ctx = static_cast<EventContext*>(lv_event_get_user_data(e));
  if (!ctx || !ctx->ui) return;
  MiraPanelUI& ui = *ctx->ui;
  if (ui._suppressEvents || ctx->bindingIndex >= ui._bindingCount) return;
  Binding& b = ui._bindings[ctx->bindingIndex];
  uint16_t sel = lv_dropdown_get_selected(lv_event_get_target(e));
  if (sel >= b.listCount) return;
  b.selectedIndex = (int8_t)sel;
  int id = b.listIds[sel];
  ui.noteActivity();
  ui._server.IndexSetList(id);
  ui._server.IndexSetEvent(id);
  ui.publishMqttAction(b, b.listLabels[sel]);
}

void MiraPanelUI::onListButton(lv_event_t* e) {
  EventContext* ctx = static_cast<EventContext*>(lv_event_get_user_data(e));
  if (!ctx || !ctx->ui) return;
  MiraPanelUI& ui = *ctx->ui;
  if (ui._suppressEvents || ctx->bindingIndex >= ui._bindingCount) return;
  Binding& b = ui._bindings[ctx->bindingIndex];
  if (ctx->itemIndex < 0 || ctx->itemIndex >= b.listCount) return;
  b.selectedIndex = ctx->itemIndex;
  int id = b.listIds[(uint8_t)ctx->itemIndex];
  ui.noteActivity();
  ui._server.IndexSetList(id);
  ui._server.IndexSetEvent(id);
  ui.publishMqttAction(b, b.listLabels[(uint8_t)ctx->itemIndex]);
  ui.updateListVisual(b);
}

void MiraPanelUI::onColor(lv_event_t* e) {
  EventContext* ctx = static_cast<EventContext*>(lv_event_get_user_data(e));
  if (!ctx || !ctx->ui) return;
  MiraPanelUI& ui = *ctx->ui;
  if (ui._suppressEvents || ctx->bindingIndex >= ui._bindingCount) return;
  Binding& b = ui._bindings[ctx->bindingIndex];
  lv_color_t c = lv_colorwheel_get_rgb(lv_event_get_target(e));
  uint32_t rgb = lv_color_to32(c);
  int r  = (rgb >> 16) & 0xFF;
  int g  = (rgb >> 8)  & 0xFF;
  int bl = rgb & 0xFF;
  ui.noteActivity();
  ui._server.IndexSetColor(b.id, r, g, bl);
  ui._server.IndexSetEvent(b.id);
  char hex[8];
  snprintf(hex, sizeof(hex), "#%02X%02X%02X", r, g, bl);
  ui.publishMqttAction(b, String(hex));
}

void MiraPanelUI::onBrightness(lv_event_t* e) {
  MiraPanelUI* ui = static_cast<MiraPanelUI*>(lv_event_get_user_data(e));
  if (!ui) return;
  int value = lv_slider_get_value(lv_event_get_target(e));
  value = clampInt(value, 30, 255);
  ui->_brightness = (uint8_t)value;
  ui->_display.setBrightness(ui->_brightness);
  if (ui->_brightnessValue) lv_label_set_text_fmt(ui->_brightnessValue, "%u", ui->_brightness);
  ui->noteActivity();
  if (lv_event_get_code(e) == LV_EVENT_RELEASED) ui->_prefs.putUChar("bright", ui->_brightness);
}

void MiraPanelUI::onDarkMode(lv_event_t* e) {
  MiraPanelUI* ui = static_cast<MiraPanelUI*>(lv_event_get_user_data(e));
  if (!ui || ui->_suppressEvents) return;
  ui->_darkMode = lv_obj_has_state(lv_event_get_target(e), LV_STATE_CHECKED);
  ui->_prefs.putBool("dark", ui->_darkMode);
  ui->applyTheme();
  ui->noteActivity();
}

void MiraPanelUI::onReturnHome(lv_event_t* e) {
  MiraPanelUI* ui = static_cast<MiraPanelUI*>(lv_event_get_user_data(e));
  if (!ui) return;
  ui->_returnHomeEnabled = lv_obj_has_state(lv_event_get_target(e), LV_STATE_CHECKED);
  ui->_prefs.putBool("home", ui->_returnHomeEnabled);
  ui->noteActivity();
}

void MiraPanelUI::onSleepMode(lv_event_t* e) {
  MiraPanelUI* ui = static_cast<MiraPanelUI*>(lv_event_get_user_data(e));
  if (!ui) return;
  ui->_sleepEnabled = lv_obj_has_state(lv_event_get_target(e), LV_STATE_CHECKED);
  ui->_prefs.putBool("sleep", ui->_sleepEnabled);
  if (!ui->_sleepEnabled) ui->wakeFromSleep();
  ui->noteActivity();
}

void MiraPanelUI::onClockSleep(lv_event_t* e) {
  MiraPanelUI* ui = static_cast<MiraPanelUI*>(lv_event_get_user_data(e));
  if (!ui) return;
  ui->_clockInSleep = lv_obj_has_state(lv_event_get_target(e), LV_STATE_CHECKED);
  ui->_prefs.putBool("clock", ui->_clockInSleep);
  ui->noteActivity();
}

void MiraPanelUI::updateListVisual(Binding& b) {
  if (b.type == W_LIST && b.control) {
    _suppressEvents = true;
    lv_dropdown_set_selected(b.control, b.selectedIndex < 0 ? 0 : b.selectedIndex);
    _suppressEvents = false;
  }
  else if (b.type == W_LISTBUTTON) {
    for (uint8_t i = 0; i < b.listCount; ++i) {
      if (!b.listButtons[i]) continue;
      lv_obj_set_style_bg_color(b.listButtons[i], i == (uint8_t)b.selectedIndex ? COL_ACCENT2 : colorPanel2(), 0);
    }
  }
}

void MiraPanelUI::handleMiraEvent(int eventId) {
  if (eventId < 0) return;
  for (uint8_t i = 0; i < _bindingCount; ++i) updateBindingFromServer(i, eventId);
}

void MiraPanelUI::handleParamEvent(int paramEvent) {
  if (paramEvent == MIRA_SAVE_LIST_LVGL) {
    // Le POST /savelistlvgl vient de terminer. On laisse quelques millisecondes
    // a la reponse HTTP pour partir avant de reconstruire toute l'interface.
    _reloadPending = true;
    _reloadAt = millis() + 120;
    Serial.println("[Mira Panel] Sauvegarde LVGL detectee, reconstruction programmee");
  }
}

void MiraPanelUI::updateBindingFromServer(uint8_t idx, int eventId) {
  Binding& b = _bindings[idx];

  if (b.type == W_INFO && eventId == b.id) {
    String value = _server.IndexGetInfo(b.id);
    String txt = value + (b.unit.length() ? " " + b.unit : "");
    if (b.valueLabel) lv_label_set_text(b.valueLabel, txt.c_str());
  }
  else if (b.type == W_TOGGLE && (eventId == b.idOff || eventId == b.idOn)) {
    bool on = (eventId == b.idOn);
    _suppressEvents = true;
    _server.IndexSetToggle(eventId);
    if (b.control) {
      if (on) lv_obj_add_state(b.control, LV_STATE_CHECKED);
      else lv_obj_clear_state(b.control, LV_STATE_CHECKED);
    }
    if (b.stateLabel) {
      lv_label_set_text(b.stateLabel, on ? "ON" : "OFF");
      lv_obj_set_style_text_color(b.stateLabel, on ? COL_GREEN : COL_MUTED, 0);
    }
    _suppressEvents = false;
  }
  else if ((b.type == W_RANGE || b.type == W_ROUNDRANGE) && eventId == b.id) {
    int value = _server.IndexGetRange(b.id);
    value = clampInt(value, b.minValue, b.maxValue);
    b.currentValue = value;
    _suppressEvents = true;
    if (b.type == W_RANGE && b.control) lv_slider_set_value(b.control, value, LV_ANIM_OFF);
    if (b.type == W_ROUNDRANGE && b.control) lv_arc_set_value(b.control, value);
    if (b.valueLabel) {
      if (b.type == W_ROUNDRANGE) {
        String txt = roundRangeDisplayValue(value, b.unit);
        lv_label_set_text(b.valueLabel, txt.c_str());
      } else {
        lv_label_set_text_fmt(b.valueLabel, "%d%s%s", value, b.unit.length() ? " " : "", b.unit.c_str());
      }
    }
    _suppressEvents = false;
  }
  else if ((b.type == W_LIST || b.type == W_LISTBUTTON)) {
    for (uint8_t n = 0; n < b.listCount; ++n) {
      if (eventId == b.listIds[n]) {
        b.selectedIndex = n;
        updateListVisual(b);
        break;
      }
    }
  }
  else if (b.type == W_COLOR && eventId == b.id) {
    int r = _server.IndexGetColor_R(b.id);
    int g = _server.IndexGetColor_G(b.id);
    int bl = _server.IndexGetColor_B(b.id);
    _suppressEvents = true;
    if (b.control) lv_colorwheel_set_rgb(b.control, lv_color_make(r, g, bl));
    _suppressEvents = false;
  }
}

void MiraPanelUI::startNtpIfPossible() {
  if (_ntpStarted || WiFi.status() != WL_CONNECTED) return;
  configTzTime("CET-1CEST,M3.5.0,M10.5.0/3", "pool.ntp.org", "time.nist.gov");
  _ntpStarted = true;
}

void MiraPanelUI::updateClock() {
  if (!_dateTimeLabel) return;
  if (millis() - _lastClockUpdate < 1000) return;
  _lastClockUpdate = millis();

  struct tm t;
  if (!getLocalTime(&t, 10)) return;

  char timeBuf[8];
  strftime(timeBuf, sizeof(timeBuf), "%H:%M", &t);
  lv_label_set_text(_dateTimeLabel, timeBuf);

  if (_dateSubLabel) {
    static const char* jours[] = {"Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"};
    static const char* mois[] = {"Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"};
    char dateBuf[64];
    snprintf(dateBuf, sizeof(dateBuf), "%s, %02d %s %04d", jours[t.tm_wday], t.tm_mday, mois[t.tm_mon], t.tm_year + 1900);
    lv_label_set_text(_dateSubLabel, dateBuf);
  }
}

void MiraPanelUI::noteActivity() {
  _lastActivity = millis();
  if (_sleeping) wakeFromSleep();
}

void MiraPanelUI::enterSleep() {
  if (_sleeping) return;
  _sleeping = true;

  if (_sleepOverlay) {
    lv_obj_clear_flag(_sleepOverlay, LV_OBJ_FLAG_HIDDEN);
    lv_obj_move_foreground(_sleepOverlay);
  }

  if (_sleepClock) {
    if (_clockInSleep) lv_obj_clear_flag(_sleepClock, LV_OBJ_FLAG_HIDDEN);
    else lv_obj_add_flag(_sleepClock, LV_OBJ_FLAG_HIDDEN);
  }

  if (_clockInSleep) {
    _display.setBrightness(_brightness > 45 ? 45 : _brightness);

    // Repart du centre a chaque entree en veille. Le deplacement anti-burn
    // reste volontairement faible pour conserver le rendu du firmware officiel.
    _sleepClockPosition = 4;
    _lastSleepClockMove = millis();
    _lastSleepClockUpdate = 0;
    lv_obj_align(_sleepClock, LV_ALIGN_CENTER, 0, -48);
    updateSleepClock();
  } else {
    _display.setBrightness(0);
  }
}

void MiraPanelUI::wakeFromSleep() {
  if (!_sleeping) return;
  _sleeping = false;
  _display.setBrightness(_brightness);
  if (_sleepOverlay) lv_obj_add_flag(_sleepOverlay, LV_OBJ_FLAG_HIDDEN);
  _lastActivity = millis();
}

void MiraPanelUI::updateSleepClock() {
  if (!_sleeping || !_clockInSleep || !_sleepClock) return;

  const uint32_t now = millis();

  // Mise a jour de l'heure chaque seconde. La date n'est volontairement
  // plus affichee : la veille officielle montre l'heure comme element dominant.
  if (now - _lastSleepClockUpdate >= 1000 || _lastSleepClockUpdate == 0) {
    _lastSleepClockUpdate = now;
    struct tm t;
    if (getLocalTime(&t, 10)) {
      char buf[8];
      strftime(buf, sizeof(buf), "%H:%M", &t);
      lv_label_set_text(_sleepClock, buf);
    }
  }

  // Anti-burn : toutes les 60 s, l'heure se decale de quelques pixels
  // autour du centre. Les neuf positions evitent de marquer toujours la meme zone.
  if (now - _lastSleepClockMove >= 60000UL) {
    static const int8_t offsetX[9] = {-12, 0, 12, -12, 0, 12, -12, 0, 12};
    static const int8_t offsetY[9] = { -8,-8, -8,   0, 0,  0,   8, 8,  8};

    _lastSleepClockMove = now;
    _sleepClockPosition = (_sleepClockPosition + 1) % 9;
    lv_obj_align(_sleepClock, LV_ALIGN_CENTER,
                 offsetX[_sleepClockPosition], -48 + offsetY[_sleepClockPosition]);
  }
}

void MiraPanelUI::loop() {
  startNtpIfPossible();
  updateClock();

  if (_reloadPending && (int32_t)(millis() - _reloadAt) >= 0) {
    _reloadPending = false;
    reloadFromMiraJson();
  }

  uint32_t idle = millis() - _lastActivity;
  if (!_sleeping && _returnHomeEnabled && _currentPage != 0 && idle >= 60000UL) {
    showPage(0);
    // showPage() remet l'activite a zero, donc la veille repart ensuite proprement.
  }

  idle = millis() - _lastActivity;
  if (!_sleeping && _sleepEnabled && idle >= 120000UL) enterSleep();
  if (_sleeping && _clockInSleep) updateSleepClock();

  lv_timer_handler();
}
