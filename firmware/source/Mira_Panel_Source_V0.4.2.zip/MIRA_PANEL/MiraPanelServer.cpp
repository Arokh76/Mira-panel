/*#include <WiFi.h>
#include <ESPAsyncWebServer.h>
#include <AsyncTCP.h>
#include <SPIFFS.h>
#include <ArduinoJson.h>
#include <HTTPClient.h>
#include <DNSServer.h>
#include <ESPmDNS.h>
#include <WiFiUdp.h>
#include <ArduinoOTA.h>
#include <Cipher.h>*/

#include <Update.h>
#include <WiFiClientSecure.h>


#include "MiraPanelServer.h"
#include "SPIFFS_Process.h"
#include "Async_HTTP.h"
#include "doUpdate.h"

#include "HTML/HTML_ManageurWiFi.h"
#include "HTML/HTML_ManageurWiFiSansR.h"
#include "HTML/HTML_Parametres.h"
#include "HTML/HTML_MQTT.h"
#include "HTML/HTML_Index.h"
#include "HTML/HTML_Sys.h"
#include "HTML/HTML_ReseauxEnreg.h"
#include "HTML/HTML_Message.h"
#include "HTML/HTML_ConfigAP.h"
#include "HTML/HTML_Donnees.h"
#include "HTML/HTML_ModificationReseau.h"
#include "HTML/HTML_Key.h"
#include "HTML/HTML_Enregistrement.h"

char* NomProg = "Hello!";
char* Ident_ID = "admin";

String StringAdresseIP;
int TentativesReco = 0;
bool ConnexionPerdue = false;

//Async
AsyncWebSocketClient* globalClient = NULL;
IPAddress localIP;
IPAddress gateway(192, 168, 1, 1);
IPAddress subnet(255, 255, 0, 0);
IPAddress param_dns(8, 8, 8, 8);
AsyncWebServer server(80);
AsyncEventSource events("/events");
String ScanReseaux[10];

long MomentPrecedent_Surv = 0;
String TITRE = "";
String MESSAGE = "";
String IDNetwork = "";
int IDAction = 1;
bool DNS = false;
DNSServer dnsServer;

//Json Action
int Action = -1;

bool SetupModuleDone = false;
String UpdateURL = "";

static const char* MIRA_GITHUB_VERSION_URL = "https://raw.githubusercontent.com/Arokh76/Mira-panel/main/firmware/version.json";
static const char* MIRA_GITHUB_BIN_URL = "https://raw.githubusercontent.com/Arokh76/Mira-panel/main/firmware/Mira_Panel.bin";

static int miraCompareVersion(const String& a, const String& b) {
  int ai = 0, bi = 0;
  for (int part = 0; part < 4; ++part) {
    long av = 0, bv = 0;
    while (ai < (int)a.length() && !isDigit(a[ai])) ai++;
    while (bi < (int)b.length() && !isDigit(b[bi])) bi++;
    while (ai < (int)a.length() && isDigit(a[ai])) { av = av * 10 + (a[ai++] - '0'); }
    while (bi < (int)b.length() && isDigit(b[bi])) { bv = bv * 10 + (b[bi++] - '0'); }
    if (av < bv) return -1;
    if (av > bv) return 1;
  }
  return 0;
}

String ScriptConstruct = "";
bool ModeAP = false;
unsigned long previousMillis = 0;
const long timeout = 10000;

//Pour affichage des listes
String Memoire_Liste[99];
int ID_Memoire_Liste = 0;

//Mise en mémoire du statut de la liste
String Listes[99];
String Listes_Value[99];
int NB_Listes = 0;


String DarkColor = "#1E5064";
String LightColor = "#7193A0";
String ActiveColor = "#D39E55";
String TextColor = "#FFFFFF";

String Powered = "";

String Logo_URL = "";
int Logo_Width = 0;
int Logo_Height = 0;

String Little_Logo_URL = "";
int Little_Logo_Width = 0;
int Little_Logo_Height = 0;
bool BesoinCo = false;

bool JEEDOM_mira = false;
bool AUTO_REFRESH = true;
bool ActionGet = false;

bool RST_Button = false;
int Bouton_RST = 0;
int Led_RST = 0;
bool DoOneRST = false;
unsigned long RST_Moment_Present = 0;
unsigned long RST_Moment_Memorise = 0;



//unsigned long JEEDOM_Moment_Present = 0;
//unsigned long JEEDOM_Moment_Memorise = 0;

unsigned long Queued_Moment_Memorise = 0;

class GestionnairePortailCaptif : public AsyncWebHandler {
public:
  GestionnairePortailCaptif() {}
  virtual ~GestionnairePortailCaptif() {}
  bool canHandle(AsyncWebServerRequest* request) {
    request->addInterestingHeader("ANY");
    return true;
  }
  void handleRequest(AsyncWebServerRequest* request) {
    request->send_P(200, "text/html", Page_Key, RetourVariable);
  }
  static String RetourVariable(String var) {
    String RETOUR = "Null";
    if (var == "SCANRESEAUX") {
      RETOUR = "<b><label for=\"ReseauxScannes\">Réseaux scannés</label></b><br><select id=\"RS\" name=\"RS\" class=\"box\" onchange=\"Click(this.value)\" >";
      for (int j = 0; j < 10; j++) {
        if (ScanReseaux[j] != "") {
          RETOUR += " <option id=\"" + ScanReseaux[j] + "\" value=\"" + ScanReseaux[j] + "\">" + ScanReseaux[j] + "</option>";
          //RETOUR += "<button onclick=\"Click('" + ScanReseaux[j] + "')\"class=\"reseau\">" + ScanReseaux[j] + "</button><br>";
        }
      }
      RETOUR += "</select><br><br>";
    }


    if (var == "APP") RETOUR = NomProg;
    if (var == "KEY") RETOUR = Uncrypt_Pass;
    if (var == "SSID") {
      if (SPIFFS_SSID == "null") {
        RETOUR = "";
      } else {
        RETOUR = SPIFFS_SSID;
      }
    }

    if (var == "IP") {
      if (SPIFFS_IP == "null") {
        RETOUR = "Auto";
      } else {
        RETOUR = SPIFFS_IP;
      }
    }

    if (var == "DARKCOLOR") {
      RETOUR = DarkColor;
    }

    if (var == "LIGHTCOLOR") {
      RETOUR = LightColor;
    }

    if (var == "ACTIVECOLOR") {
      RETOUR = ActiveColor;
    }

    if (var == "TEXTCOLOR") {
      RETOUR = TextColor;
    }

    if (var == "POWERED") {
      RETOUR = Powered;
    }

    return RETOUR;
  }
};
void MiraPanelServer::Debug(bool Value) {
  _Debug = Value;
}

void MiraPanelServer::miraLvgl(bool Value) {
  _LVGL = Value;
}

void MiraPanelServer::Jeedom(bool Value) {
  JEEDOM_mira = Value;
}

void MiraPanelServer::JeedomAutoRefresh(bool Value) {
  AUTO_REFRESH = Value;
}

void MiraPanelServer::GenericAutoRefresh(bool Value) {
  AUTO_REFRESH = Value;
}



void MiraPanelServer::IndexAddLittleLogo(String URL, int Width, int Height) {
  Little_Logo_URL = URL;

  if (Width > 110) {
    Width = 110;
  }

  if (Height > 110) {
    Height = 110;
  }
  Little_Logo_Width = Width;
  Little_Logo_Height = Height;
}

void MiraPanelServer::IndexAddLogo(String URL, int Width, int Height) {
  Logo_URL = URL;
  Logo_Width = Width;
  Logo_Height = Height;
}



void MiraPanelServer::IndexBottomText(String Text) {
  Powered = Text;
}


void MiraPanelServer::IndexDarkColor(String HTML_Color) {
  if (HTML_Color == "" || HTML_Color == "Defaut") {
    DarkColor = "#1E5064";
  } else {
    DarkColor = HTML_Color;
  }
}

void MiraPanelServer::IndexLightColor(String HTML_Color) {
  if (HTML_Color == "" || HTML_Color == "Defaut") {
    LightColor = "#7193A0";
  } else {
    LightColor = HTML_Color;
  }
}


void MiraPanelServer::IndexActiveColor(String HTML_Color) {
  if (HTML_Color == "" || HTML_Color == "Defaut") {
    ActiveColor = "#D39E55";
  } else {
    ActiveColor = HTML_Color;
  }
}

void MiraPanelServer::IndexTextColor(String HTML_Color) {
  if (HTML_Color == "" || HTML_Color == "Defaut") {
    TextColor = "#FFFFFF";
  } else {
    TextColor = HTML_Color;
  }
}

void MiraPanelServer::Scan_Network(bool Value) {
  _Scan = Value;
}

void MiraPanelServer::SetUser(char* ID_USER) {
  Ident_ID = ID_USER;
}


void MiraPanelServer::ServeurDNS() {

  if (_Debug == true) Serial.println(F("Mira:  Démarrage du mode configuration Wi-Fi"));

  // Premier démarrage / flash effacé : repartir d'un état Wi-Fi propre.
  // Sur ESP32-S3, cela évite qu'un ancien état STA empêche parfois le softAP
  // d'apparaître immédiatement après un erase flash complet.
  WiFi.persistent(false);
  WiFi.disconnect(true, true);
  delay(250);
  WiFi.mode(WIFI_OFF);
  delay(150);
  WiFi.mode(WIFI_AP);
  delay(150);

  const char* setupSsid = "Mira Panel";
  bool apOk = WiFi.softAP(setupSsid);
  if (!apOk) {
    if (_Debug) Serial.println(F("[Mira Panel] Echec softAP, nouvelle tentative..."));
    delay(300);
    WiFi.mode(WIFI_AP);
    apOk = WiFi.softAP(setupSsid);
  }

  if (_Debug) {
    Serial.print(F("[Mira Panel] Point d'acces Wi-Fi : "));
    Serial.println(apOk ? F("ACTIF") : F("ECHEC"));
    Serial.print(F("[Mira Panel] SSID : "));
    Serial.println(setupSsid);
    Serial.print(F("[Mira Panel] IP : "));
    Serial.println(WiFi.softAPIP());
  }
  server.on("/", HTTP_GET, [](AsyncWebServerRequest* request) {
    request->send_P(200, "text/html", Page_Key, RetourVariable);
  });

  server.on("/save", HTTP_POST, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->value().c_str()) == "wifi") {
      int params = request->params();
      for (int i = 0; i < params; i++) {
        AsyncWebParameter* p = request->getParam(i);
        if (p->isPost()) {
          if (p->name() == "ssid") SPIFFS_SSID = p->value().c_str();
          if (p->name() == "pass") SPIFFS_Pass = p->value().c_str();
          if (p->name() == "ip") SPIFFS_IP = p->value().c_str();
        }
      }
      if (SPIFFS_EnregistrementReseau()) {
        if (ModeAP == false) {
          request->send_P(200, "text/html", Page_Index, RetourVariable);

        } else {
          request->send_P(200, "text/html", Page_Enregistrement, RetourVariable);
          delay(1000);
          ESP.restart();
        }

      } else {
        request->send(200, "text/plain", "Erreur d'écriture de la configuration...");
      }
    } else if (String(p->value().c_str()) == "key") {
      int params = request->params();
      for (int i = 0; i < params; i++) {
        AsyncWebParameter* p = request->getParam(i);
        if (p->isPost()) {
          if (p->name() == "key") Uncrypt_Pass = p->value().c_str();
        }
      }
      if (SPIFFS_EnregistrementAP()) {
        request->send_P(200, "text/html", Page_ManageurWiFiSansR, RetourVariable);
      } else {
        request->send(200, "text/plain", "Erreur d'écriture de la configuration...");
      }
    }
  });

  server.on("/load", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);

    if (String(p->name().c_str()) == "nav") {
      if (String(p->value().c_str()) == "wifisr") {
        request->send_P(200, "text/html", Page_ManageurWiFiSansR, RetourVariable);
      } else if (String(p->value().c_str()) == "key") {
        request->send_P(200, "text/html", Page_Key, RetourVariable);
      } else if (String(p->value().c_str()) == "reboot") {
        SPIFFS_Config_Reseau["ap"][0]["actif"].as<String>() = "1";
        if (SPIFFS_EnregistrementAP()) {
          TITRE = "Enregistrement terminé";
          MESSAGE = "Redémarrage de l'appareil en point d'accès...";
          request->send_P(200, "text/html", Page_Message, RetourVariable);
          delay(1000);
          ESP.restart();
        }
      }
    }
  });

  dnsServer.start(53, "*", WiFi.softAPIP());
  server.addHandler(new GestionnairePortailCaptif()).setFilter(ON_AP_FILTER);
  DNS = true;
  server.begin();
}

String ReturnJSONModule() {
  String Retour_Json = "";
  serializeJsonPretty(SPIFFS_Config_Module, Retour_Json);
  return Retour_Json;
}



String ReturnJSONIndex() {
  String Retour_Json = "";
  serializeJsonPretty(SPIFFS_Config_Actions, Retour_Json);
  return Retour_Json;
}

String ReturnJSONlvgl() {
  String Retour_Json = "";
  serializeJsonPretty(mira_Json_LVGL, Retour_Json);
  return Retour_Json;
}


#define U_PART U_SPIFFS

size_t content_len;
void handleDoUpdate(AsyncWebServerRequest* request, const String& filename, size_t index, uint8_t* data, size_t len, bool final) {
  if (!index) {
    Serial.println("Update");
    content_len = request->contentLength();
    // if filename includes spiffs, update the spiffs partition
    int cmd = (filename.indexOf("spiffs") > -1) ? U_PART : U_FLASH;

    if (!Update.begin(UPDATE_SIZE_UNKNOWN, cmd)) {
      Update.printError(Serial);
      Serial.println("Begin");
    }
  }

  if (Update.write(data, len) != len) {
    Update.printError(Serial);
    Serial.println("Write");
    Serial.println(Update.progress());
    Serial.printf("Progress: %d%%\n", (Update.progress() * 100) / Update.size());
  } else {
    String update_status = "Progress: " + String((Update.progress() * 100) / Update.size()) + "%";
    Serial.println(update_status);
  }

  if (final) {
    AsyncWebServerResponse* response = request->beginResponse(302, "text/plain", "Please wait while the device reboots");
    response->addHeader("Refresh", "20");
    response->addHeader("Location", "/");
    request->send(response);
    if (!Update.end(true)) {
      Update.printError(Serial);
    } else {
      Serial.println("Update complete");
      Serial.flush();
      ESP.restart();
    }
  }
}



void MiraPanelServer::ServeurStation() {
  server.on("/", HTTP_GET, [](AsyncWebServerRequest* request) {
    char CPass[50];
    Uncrypt_Pass.toCharArray(CPass, 50);
    if (!request->authenticate(Ident_ID, CPass))
      return request->requestAuthentication();
    request->send_P(200, "text/html", Page_Index, RetourVariable);
  });
  //server.serveStatic("/", SPIFFS, "/");

  server.on("/update", HTTP_POST, [](AsyncWebServerRequest* request) {
    Resend = true;
    ActionGet = false;
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "send") {
      Action = String(p->value().c_str()).toInt();

    } else if (String(p->name().c_str()) == "send_color") {
      Action = String(p->value().c_str()).toInt();

      String SNom = String(p->value().c_str());
      String ID = String(p->value().c_str());
      JsonArray Actions = SPIFFS_Config_Actions["actions"];
      for (int i = 0; i < Actions.size(); i++) {
        if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == ID) {
          p = request->getParam(1);
          int R = (String(p->value().c_str())).toInt();
          SPIFFS_Config_Actions["actions"][i]["r"] = String(p->value().c_str());
          p = request->getParam(2);
          int G = (String(p->value().c_str())).toInt();
          SPIFFS_Config_Actions["actions"][i]["g"] = String(p->value().c_str());
          p = request->getParam(3);
          int B = (String(p->value().c_str())).toInt();
          SPIFFS_Config_Actions["actions"][i]["b"] = String(p->value().c_str());

          char CNom[50];
          SNom.toCharArray(CNom, 50);
          long r = 0;
          r = (long)R;
          long g = 0;
          g = (long)G;
          long b = 0;
          b = (long)B;

          String SValue = "#000000";
          char CValue[7];
          sprintf(CValue, "#%02x%02x%02x", r, g, b);

          events.send(CValue, CNom, millis());

          break;
        }
      }

    } else if (String(p->name().c_str()) == "send_range") {
      Action = String(p->value().c_str()).toInt();
      String ID = String(p->value().c_str());
      JsonArray Actions = SPIFFS_Config_Actions["actions"];
      for (int i = 0; i < Actions.size(); i++) {
        if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == ID) {
          String SNom = String(p->value().c_str());
          p = request->getParam(1);
          SPIFFS_Config_Actions["actions"][i]["value"] = String(p->value().c_str());

          char CNom[50];
          SNom.toCharArray(CNom, 50);
          char CValue[50];
          String SValue = String(p->value().c_str());
          SValue.toCharArray(CValue, 50);
          events.send(CValue, CNom, millis());

          break;
        }
      }
    } else if (String(p->name().c_str()) == "send_list") {
      Action = String(p->value().c_str()).toInt();
      String ID = String(p->value().c_str());
      p = request->getParam(1);
      String SNom = String(p->value().c_str());
      char CNom[50];
      SNom.toCharArray(CNom, 50);
      char CValue[50];
      String SValue = ID;
      SValue.toCharArray(CValue, 50);
      events.send(CNom, CValue, millis());
      for (int k = 0; k < NB_Listes; k++) {
        if (Listes[k] == SNom) {
          Listes_Value[k] = SValue;
          break;
        }
      }

      JsonArray Actions = SPIFFS_Config_Actions["actions"];
      for (int j = 0; j < Actions.size(); j++) {
        if (SValue == SPIFFS_Config_Actions["actions"][j]["id"].as<String>()) {
          String Value = SPIFFS_Config_Actions["actions"][j]["id"].as<String>();
          for (int i = 0; i < Actions.size(); i++) {
            if (SNom == SPIFFS_Config_Actions["actions"][i]["nomliste"].as<String>()) {
              SPIFFS_Config_Actions["actions"][i]["value"] = Value;
            }
          }
          break;
        }
      }


    } else if (String(p->name().c_str()) == "send_textbox") {
      Action = String(p->value().c_str()).toInt();
      String ID = String(p->value().c_str());
      JsonArray Actions = SPIFFS_Config_Actions["actions"];
      for (int i = 0; i < Actions.size(); i++) {
        if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == ID) {
          p = request->getParam(1);
          SPIFFS_Config_Actions["actions"][i]["value"] = String(p->value().c_str());
          String SNom = String(p->value().c_str());

          char CNom[50];
          SNom.toCharArray(CNom, 50);

          char CValue[50];
          String SValue = ID;
          SValue.toCharArray(CValue, 50);
          events.send(CNom, CValue, millis());
          break;
        }
      }

    } else if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {

      AsyncWebParameter* p = request->getParam(1);

      if (String(p->name().c_str()) == "button") {
        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {
          if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "button") {
            if (String(p->value().c_str()) == SPIFFS_Config_Actions["actions"][i]["id"].as<String>()) {
              Action = String(p->value().c_str()).toInt();
              request->send(200, "text/plain", String(Action));
              break;
            }
          }
        }
      } else if (String(p->name().c_str()) == "httpaction") {
        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {
          if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "httpaction") {
            if (String(p->value().c_str()) == SPIFFS_Config_Actions["actions"][i]["id"].as<String>()) {
              Action = String(p->value().c_str()).toInt();

              request->send(200, "text/plain", String(Action));
              break;
            }
          }
        }
      } else if (String(p->name().c_str()) == "toogle" || String(p->name().c_str()) == "toggle") {
        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {
          if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "toggle") {
            if (String(p->value().c_str()) == SPIFFS_Config_Actions["actions"][i]["id0"].as<String>() || String(p->value().c_str()) == SPIFFS_Config_Actions["actions"][i]["id1"].as<String>()) {
              Action = String(p->value().c_str()).toInt();
              request->send(200, "text/plain", String(Action));
              break;
            }
          }
        }
      } else if (String(p->name().c_str()) == "info") {
        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {
          Action = String(p->value().c_str()).toInt();

          if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(p->value().c_str())) {
            String SNom = String(p->value().c_str());
            char CNom[50];
            SNom.toCharArray(CNom, 50);
            p = request->getParam(2);
            SPIFFS_Config_Actions["actions"][i]["value"] = String(p->value().c_str());
            String SValue = String(p->value().c_str());
            char CValue[50];
            SValue.toCharArray(CValue, 50);
            events.send(CValue, CNom, millis());
            request->send(200, "text/plain", "OK");
            break;
          }
        }
      } else if (String(p->name().c_str()) == "inputbox") {
        Action = String(p->value().c_str()).toInt();

        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {

          if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(p->value().c_str())) {
            String SNom = String(p->value().c_str());
            char CNom[50];
            SNom.toCharArray(CNom, 50);
            p = request->getParam(2);
            SPIFFS_Config_Actions["actions"][i]["value"] = String(p->value().c_str());
            String SValue = String(p->value().c_str());
            char CValue[50];
            SValue.toCharArray(CValue, 50);
            events.send(CValue, CNom, millis());
            request->send(200, "text/plain", "OK");
            break;
          }
        }
      } else if (String(p->name().c_str()) == "infofa") {
        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {
          Action = String(p->value().c_str()).toInt();

          if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(p->value().c_str())) {
            String SNom = String(p->value().c_str());
            char CNom[50];
            SNom.toCharArray(CNom, 50);
            p = request->getParam(2);
            SPIFFS_Config_Actions["actions"][i]["value"] = String(p->value().c_str());
            String SValue = String(p->value().c_str());
            char CValue[50];
            SValue.toCharArray(CValue, 50);
            events.send(CValue, CNom, millis());
            request->send(200, "text/plain", "OK");
            break;
          }
        }
      } else if (String(p->name().c_str()) == "color") {
        Action = String(p->value().c_str()).toInt();
        String ID = String(p->value().c_str());
        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {
          if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == ID) {
            String SNom = String(p->value().c_str());
            p = request->getParam(2);
            SPIFFS_Config_Actions["actions"][i]["r"] = String(p->value().c_str());
            int R = (String(p->value().c_str())).toInt();
            p = request->getParam(3);
            SPIFFS_Config_Actions["actions"][i]["g"] = String(p->value().c_str());
            int G = (String(p->value().c_str())).toInt();
            p = request->getParam(4);
            SPIFFS_Config_Actions["actions"][i]["b"] = String(p->value().c_str());
            int B = (String(p->value().c_str())).toInt();

            char CNom[50];
            SNom.toCharArray(CNom, 50);
            long r = 0;
            r = (long)R;
            long g = 0;
            g = (long)G;
            long b = 0;
            b = (long)B;

            String SValue = "#000000";
            char CValue[7];
            sprintf(CValue, "#%02x%02x%02x", r, g, b);

            events.send(CValue, CNom, millis());
            request->send(200, "text/plain", "OK");
            break;
          }
        }
      } else if (String(p->name().c_str()) == "range") {
        Action = String(p->value().c_str()).toInt();
        String ID = String(p->value().c_str());
        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {
          if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == ID) {
            String SNom = String(p->value().c_str());
            p = request->getParam(2);
            SPIFFS_Config_Actions["actions"][i]["value"] = String(p->value().c_str());

            char CNom[50];
            SNom.toCharArray(CNom, 50);
            char CValue[50];
            String SValue = String(p->value().c_str());
            SValue.toCharArray(CValue, 50);
            events.send(CValue, CNom, millis());
            break;
          }
        }
      } else if (String(p->name().c_str()) == "list") {
        String Nom_Liste = String(p->value().c_str());

        for (int k = 0; k < NB_Listes; k++) {
          if (Listes[k] == Nom_Liste) {
            p = request->getParam(2);
            Listes_Value[k] = String(p->value().c_str());

            char CNom[50];
            Nom_Liste.toCharArray(CNom, 50);
            char CValue[50];
            String SValue = String(p->value().c_str());
            SValue.toCharArray(CValue, 50);
            events.send(CNom, CValue, millis());
            Action = String(p->value().c_str()).toInt();

            JsonArray Actions = SPIFFS_Config_Actions["actions"];
            for (int j = 0; j < Actions.size(); j++) {
              if (Nom_Liste == SPIFFS_Config_Actions["actions"][j]["nomliste"].as<String>()) {
                SPIFFS_Config_Actions["actions"][j]["value"] = SValue;
              }
            }


            request->send(200, "text/plain", SValue);
            break;
          }
        }
      } else if (String(p->name().c_str()) == "param") {
        SPIFFS_ADD_Param = String(p->value().c_str());
        p = request->getParam(2);
        SPIFFS_ADD_Value = String(p->value().c_str());
        SPIFFS_UpdateParam();
        request->send(200, "text/plain", "Paramètre mis à jour");
      }
    }
  });



  server.on("/update", HTTP_GET, [](AsyncWebServerRequest* request) {
    Resend = true;
    ActionGet = true;
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {

      AsyncWebParameter* p = request->getParam(1);

      if (String(p->name().c_str()) == "button") {
        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {
          if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "button") {
            if (String(p->value().c_str()) == SPIFFS_Config_Actions["actions"][i]["id"].as<String>()) {
              Action = String(p->value().c_str()).toInt();
              request->send(200, "text/plain", String(Action));
              break;
            }
          }
        }
      } else if (String(p->name().c_str()) == "httpaction") {
        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {
          if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "httpaction") {
            if (String(p->value().c_str()) == SPIFFS_Config_Actions["actions"][i]["id"].as<String>()) {
              Action = String(p->value().c_str()).toInt();

              request->send(200, "text/plain", String(Action));
              break;
            }
          }
        }
      } else if (String(p->name().c_str()) == "toogle" || String(p->name().c_str()) == "toggle") {
        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {
          if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "toggle") {
            if (String(p->value().c_str()) == SPIFFS_Config_Actions["actions"][i]["id0"].as<String>() || String(p->value().c_str()) == SPIFFS_Config_Actions["actions"][i]["id1"].as<String>()) {
              Action = String(p->value().c_str()).toInt();
              request->send(200, "text/plain", String(Action));
              break;
            }
          }
        }
      } else if (String(p->name().c_str()) == "info") {
        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {

          if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(p->value().c_str())) {
            Action = String(p->value().c_str()).toInt();

            String SNom = String(p->value().c_str());
            char CNom[50];
            SNom.toCharArray(CNom, 50);
            p = request->getParam(2);
            SPIFFS_Config_Actions["actions"][i]["value"] = String(p->value().c_str());
            String SValue = String(p->value().c_str());
            char CValue[50];
            SValue.toCharArray(CValue, 50);
            events.send(CValue, CNom, millis());
            request->send(200, "text/plain", "OK");
            break;
          }
        }
      } else if (String(p->name().c_str()) == "infofa") {
        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {

          if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(p->value().c_str())) {
            Action = String(p->value().c_str()).toInt();

            String SNom = String(p->value().c_str());
            char CNom[50];
            SNom.toCharArray(CNom, 50);
            p = request->getParam(2);
            SPIFFS_Config_Actions["actions"][i]["value"] = String(p->value().c_str());
            String SValue = String(p->value().c_str());
            char CValue[50];
            SValue.toCharArray(CValue, 50);
            events.send(CValue, CNom, millis());
            request->send(200, "text/plain", "OK");
            break;
          }
        }
      } else if (String(p->name().c_str()) == "inputbox") {
        Action = String(p->value().c_str()).toInt();

        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {

          if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(p->value().c_str())) {
            String SNom = String(p->value().c_str());
            char CNom[50];
            SNom.toCharArray(CNom, 50);
            p = request->getParam(2);
            SPIFFS_Config_Actions["actions"][i]["value"] = String(p->value().c_str());
            String SValue = String(p->value().c_str());
            char CValue[50];
            SValue.toCharArray(CValue, 50);
            events.send(CValue, CNom, millis());
            request->send(200, "text/plain", "OK");
            break;
          }
        }
      } else if (String(p->name().c_str()) == "color") {
        Action = String(p->value().c_str()).toInt();

        String ID = String(p->value().c_str());
        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {
          if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == ID) {
            String SNom = String(p->value().c_str());
            p = request->getParam(2);
            SPIFFS_Config_Actions["actions"][i]["r"] = String(p->value().c_str());
            int R = (String(p->value().c_str())).toInt();
            p = request->getParam(3);
            SPIFFS_Config_Actions["actions"][i]["g"] = String(p->value().c_str());
            int G = (String(p->value().c_str())).toInt();
            p = request->getParam(4);
            SPIFFS_Config_Actions["actions"][i]["b"] = String(p->value().c_str());
            int B = (String(p->value().c_str())).toInt();

            char CNom[50];
            SNom.toCharArray(CNom, 50);
            long r = 0;
            r = (long)R;
            long g = 0;
            g = (long)G;
            long b = 0;
            b = (long)B;

            String SValue = "#000000";
            char CValue[7];
            sprintf(CValue, "#%02x%02x%02x", r, g, b);

            events.send(CValue, CNom, millis());
            request->send(200, "text/plain", "OK");
            break;
          }
        }
      } else if (String(p->name().c_str()) == "range") {
        Action = String(p->value().c_str()).toInt();

        String ID = String(p->value().c_str());
        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {
          if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == ID) {
            String SNom = String(p->value().c_str());
            p = request->getParam(2);
            SPIFFS_Config_Actions["actions"][i]["value"] = String(p->value().c_str());

            char CNom[50];
            SNom.toCharArray(CNom, 50);
            char CValue[50];
            String SValue = String(p->value().c_str());
            SValue.toCharArray(CValue, 50);
            events.send(CValue, CNom, millis());
            request->send(200, "text/plain", SValue);
            break;
          }
        }
      } else if (String(p->name().c_str()) == "list") {
        String Nom_Liste = String(p->value().c_str());
        for (int k = 0; k < NB_Listes; k++) {
          if (Listes[k] == Nom_Liste) {
            p = request->getParam(2);
            Listes_Value[k] = String(p->value().c_str());

            char CNom[50];
            Nom_Liste.toCharArray(CNom, 50);
            char CValue[50];
            String SValue = String(p->value().c_str());
            SValue.toCharArray(CValue, 50);
            events.send(CNom, CValue, millis());
            Action = String(p->value().c_str()).toInt();

            JsonArray Actions = SPIFFS_Config_Actions["actions"];
            for (int j = 0; j < Actions.size(); j++) {
              if (Nom_Liste == SPIFFS_Config_Actions["actions"][j]["nomliste"].as<String>()) {
                SPIFFS_Config_Actions["actions"][j]["value"] = SValue;
              }
            }


            request->send(200, "text/plain", SValue);
            break;
          }
        }
      } else if (String(p->name().c_str()) == "listvalue") {
        String Nom_Liste = String(p->value().c_str());
        for (int k = 0; k < NB_Listes; k++) {
          if (Listes[k] == Nom_Liste) {
            p = request->getParam(2);
            String SValue = String(p->value().c_str());

            JsonArray Actions = SPIFFS_Config_Actions["actions"];
            for (int j = 0; j < Actions.size(); j++) {

              if (Nom_Liste == SPIFFS_Config_Actions["actions"][j]["nomliste"].as<String>() && SValue == SPIFFS_Config_Actions["actions"][j]["nom"].as<String>()) {


                SValue = SPIFFS_Config_Actions["actions"][j]["id"].as<String>();
                Listes_Value[k] = SValue;
                char CNom[50];
                Nom_Liste.toCharArray(CNom, 50);
                char CValue[50];

                SValue.toCharArray(CValue, 50);
                events.send(CNom, CValue, millis());
                Action = SValue.toInt();

                for (int l = 0; l < Actions.size(); l++) {
                  if (Nom_Liste == SPIFFS_Config_Actions["actions"][l]["nomliste"].as<String>()) {
                    SPIFFS_Config_Actions["actions"][l]["value"] = SPIFFS_Config_Actions["actions"][j]["nom"].as<String>();
                  }
                }
                request->send(200, "text/plain", SValue);
                break;
              }
              if (j == Actions.size() - 1) {
                request->send(200, "text/plain", "Erreur");
              }
            }
          }
        }
      } else if (String(p->name().c_str()) == "param") {
        SPIFFS_ADD_Param = String(p->value().c_str());
        p = request->getParam(2);
        SPIFFS_ADD_Value = String(p->value().c_str());
        SPIFFS_UpdateParam();
        request->send(200, "text/plain", "Paramètre mis à jour");
      }
    }
  });

  server.on("/updatenr", HTTP_GET, [](AsyncWebServerRequest* request) {
    Resend = false;
    ActionGet = true;
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {

      AsyncWebParameter* p = request->getParam(1);

      if (String(p->name().c_str()) == "button") {
        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {
          if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "button") {
            if (String(p->value().c_str()) == SPIFFS_Config_Actions["actions"][i]["id"].as<String>()) {
              Action = String(p->value().c_str()).toInt();
              request->send(200, "text/plain", String(Action));
              break;
            }
          }
        }
      } else if (String(p->name().c_str()) == "httpaction") {
        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {
          if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "httpaction") {
            if (String(p->value().c_str()) == SPIFFS_Config_Actions["actions"][i]["id"].as<String>()) {
              Action = String(p->value().c_str()).toInt();

              request->send(200, "text/plain", String(Action));
              break;
            }
          }
        }
      } else if (String(p->name().c_str()) == "toogle" || String(p->name().c_str()) == "toggle") {
        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {
          if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "toggle") {
            if (String(p->value().c_str()) == SPIFFS_Config_Actions["actions"][i]["id0"].as<String>() || String(p->value().c_str()) == SPIFFS_Config_Actions["actions"][i]["id1"].as<String>()) {
              Action = String(p->value().c_str()).toInt();
              request->send(200, "text/plain", String(Action));
              break;
            }
          }
        }
      } else if (String(p->name().c_str()) == "info") {
        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {

          if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(p->value().c_str())) {
            Action = String(p->value().c_str()).toInt();

            String SNom = String(p->value().c_str());
            char CNom[50];
            SNom.toCharArray(CNom, 50);
            p = request->getParam(2);
            SPIFFS_Config_Actions["actions"][i]["value"] = String(p->value().c_str());
            String SValue = String(p->value().c_str());
            char CValue[50];
            SValue.toCharArray(CValue, 50);
            events.send(CValue, CNom, millis());
            request->send(200, "text/plain", "OK");
            break;
          }
        }
      } else if (String(p->name().c_str()) == "infofa") {
        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {

          if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(p->value().c_str())) {
            Action = String(p->value().c_str()).toInt();

            String SNom = String(p->value().c_str());
            char CNom[50];
            SNom.toCharArray(CNom, 50);
            p = request->getParam(2);
            SPIFFS_Config_Actions["actions"][i]["value"] = String(p->value().c_str());
            String SValue = String(p->value().c_str());
            char CValue[50];
            SValue.toCharArray(CValue, 50);
            events.send(CValue, CNom, millis());
            request->send(200, "text/plain", "OK");
            break;
          }
        }
      } else if (String(p->name().c_str()) == "inputbox") {
        Action = String(p->value().c_str()).toInt();

        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {

          if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(p->value().c_str())) {
            String SNom = String(p->value().c_str());
            char CNom[50];
            SNom.toCharArray(CNom, 50);
            p = request->getParam(2);
            SPIFFS_Config_Actions["actions"][i]["value"] = String(p->value().c_str());
            String SValue = String(p->value().c_str());
            char CValue[50];
            SValue.toCharArray(CValue, 50);
            events.send(CValue, CNom, millis());
            request->send(200, "text/plain", "OK");
            break;
          }
        }
      } else if (String(p->name().c_str()) == "color") {
        Action = String(p->value().c_str()).toInt();

        String ID = String(p->value().c_str());
        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {
          if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == ID) {
            String SNom = String(p->value().c_str());
            p = request->getParam(2);
            SPIFFS_Config_Actions["actions"][i]["r"] = String(p->value().c_str());
            int R = (String(p->value().c_str())).toInt();
            p = request->getParam(3);
            SPIFFS_Config_Actions["actions"][i]["g"] = String(p->value().c_str());
            int G = (String(p->value().c_str())).toInt();
            p = request->getParam(4);
            SPIFFS_Config_Actions["actions"][i]["b"] = String(p->value().c_str());
            int B = (String(p->value().c_str())).toInt();

            char CNom[50];
            SNom.toCharArray(CNom, 50);
            long r = 0;
            r = (long)R;
            long g = 0;
            g = (long)G;
            long b = 0;
            b = (long)B;

            String SValue = "#000000";
            char CValue[7];
            sprintf(CValue, "#%02x%02x%02x", r, g, b);

            events.send(CValue, CNom, millis());
            request->send(200, "text/plain", "OK");
            break;
          }
        }
      } else if (String(p->name().c_str()) == "range") {
        Action = String(p->value().c_str()).toInt();

        String ID = String(p->value().c_str());
        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {
          if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == ID) {
            String SNom = String(p->value().c_str());
            p = request->getParam(2);
            SPIFFS_Config_Actions["actions"][i]["value"] = String(p->value().c_str());

            char CNom[50];
            SNom.toCharArray(CNom, 50);
            char CValue[50];
            String SValue = String(p->value().c_str());
            SValue.toCharArray(CValue, 50);
            events.send(CValue, CNom, millis());
            request->send(200, "text/plain", SValue);
            break;
          }
        }
      } else if (String(p->name().c_str()) == "list") {
        String Nom_Liste = String(p->value().c_str());
        for (int k = 0; k < NB_Listes; k++) {
          if (Listes[k] == Nom_Liste) {
            p = request->getParam(2);
            Listes_Value[k] = String(p->value().c_str());

            char CNom[50];
            Nom_Liste.toCharArray(CNom, 50);
            char CValue[50];
            String SValue = String(p->value().c_str());
            SValue.toCharArray(CValue, 50);
            events.send(CNom, CValue, millis());
            Action = String(p->value().c_str()).toInt();

            JsonArray Actions = SPIFFS_Config_Actions["actions"];
            for (int j = 0; j < Actions.size(); j++) {
              if (Nom_Liste == SPIFFS_Config_Actions["actions"][j]["nomliste"].as<String>()) {
                SPIFFS_Config_Actions["actions"][j]["value"] = SValue;
              }
            }


            request->send(200, "text/plain", SValue);
            break;
          }
        }
      } else if (String(p->name().c_str()) == "listvalue") {
        String Nom_Liste = String(p->value().c_str());
        for (int k = 0; k < NB_Listes; k++) {
          if (Listes[k] == Nom_Liste) {
            p = request->getParam(2);
            String SValue = String(p->value().c_str());

            JsonArray Actions = SPIFFS_Config_Actions["actions"];
            for (int j = 0; j < Actions.size(); j++) {

              if (Nom_Liste == SPIFFS_Config_Actions["actions"][j]["nomliste"].as<String>() && SValue == SPIFFS_Config_Actions["actions"][j]["nom"].as<String>()) {


                SValue = SPIFFS_Config_Actions["actions"][j]["id"].as<String>();
                Listes_Value[k] = SValue;
                char CNom[50];
                Nom_Liste.toCharArray(CNom, 50);
                char CValue[50];

                SValue.toCharArray(CValue, 50);
                events.send(CNom, CValue, millis());
                Action = SValue.toInt();

                for (int l = 0; l < Actions.size(); l++) {
                  if (Nom_Liste == SPIFFS_Config_Actions["actions"][l]["nomliste"].as<String>()) {
                    SPIFFS_Config_Actions["actions"][l]["value"] = SPIFFS_Config_Actions["actions"][j]["nom"].as<String>();
                  }
                }
                request->send(200, "text/plain", SValue);
                break;
              }
              if (j == Actions.size() - 1) {
                request->send(200, "text/plain", "Erreur");
              }
            }
          }
        }
      } else if (String(p->name().c_str()) == "param") {
        SPIFFS_ADD_Param = String(p->value().c_str());
        p = request->getParam(2);
        SPIFFS_ADD_Value = String(p->value().c_str());
        SPIFFS_UpdateParam();
        request->send(200, "text/plain", "Paramètre mis à jour");
      }
    }
  });


  server.on("/save", HTTP_POST, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "config") {

      if (String(p->value().c_str()) == "params") {

        int params = request->params();
        int emplacement = 0;
        NB_List_Param = 0;
        NB_List_lvgl = 0;

        JsonArray Json_Array = mira_Json_LVGL["lvgl"];
        bool lvgl = false;
        for (int i = 0; i < params; i++) {
          lvgl = false;
          AsyncWebParameter* p = request->getParam(i);
          if (p->isPost()) {
            for (int j = 0; j < Json_Array.size(); j++) {
              String nom_url = mira_Json_LVGL["lvgl"][j]["name"].as<String>();
              if (String(p->name().c_str()) == nom_url) lvgl = true;
            }
            if (!lvgl) {
              JsonArray Params = SPIFFS_Config_Params["params"];
              for (int j = 0; j < Params.size(); j++) {
                if (SPIFFS_Config_Params["params"][j]["param"].as<String>() == p->name().c_str()) {
                  if (SPIFFS_Config_Params["params"][j]["value"].as<String>() != p->value().c_str()) {
                    SPIFFS_Config_Params["params"][j]["value"] = p->value().c_str();
                    NB_List_Param++;
                  }
                }
              }
            }
          }
        }


        lvgl = false;
        for (int i = 0; i < params; i++) {
          AsyncWebParameter* p = request->getParam(i);
          if (p->isPost()) {
            for (int j = 0; j < Json_Array.size(); j++) {
              String nom_url = mira_Json_LVGL["lvgl"][j]["name"].as<String>();
              if (String(p->name().c_str()) == nom_url) {
                if (mira_Json_LVGL["lvgl"][j]["url"] != p->value().c_str()) {
                  mira_Json_LVGL["lvgl"][j]["url"] = p->value();
                  NB_List_lvgl++;
                }
              }
            }
          }
        }

        if (NB_List_Param > 0) SPIFFS_SaveParam_List();
        if (NB_List_lvgl > 0) SaveListLVGL();
        request->send_P(200, "text/html", Page_Index, RetourVariable);

      } else if (String(p->value().c_str()) == "AP") {

        int params = request->params();
        for (int i = 0; i < params; i++) {
          AsyncWebParameter* p = request->getParam(i);
          if (p->isPost()) {

            if (p->name() == "pass") Uncrypt_Pass = p->value().c_str();
            if (p->name() == "ip") SPIFFS_Config_Reseau["ap"][0]["ip"] = p->value();
            if (p->name() == "actif") SPIFFS_Config_Reseau["ap"][0]["actif"] = p->value();
          }
        }
        if (SPIFFS_EnregistrementAP()) {
          TITRE = "Redémarrage de l'apparail.";
          MESSAGE = "";
          request->send_P(200, "text/html", Page_Message, RetourVariable);
          delay(1000);
          ESP.restart();
        } else {
          request->send(200, "text/plain", "Erreur d'écriture de la configuration...");
        }

      } else if (String(p->value().c_str()) == "wifi") {

        int params = request->params();
        for (int i = 0; i < params; i++) {
          AsyncWebParameter* p = request->getParam(i);
          if (p->isPost()) {
            if (p->name() == "ssid") SPIFFS_SSID = p->value().c_str();
            if (p->name() == "pass") SPIFFS_Pass = p->value().c_str();
            if (p->name() == "ip") SPIFFS_IP = p->value().c_str();
          }
        }
        if (SPIFFS_EnregistrementReseau()) {
          if (ModeAP == false) {
            request->send_P(200, "text/html", Page_Index, RetourVariable);

          } else {
            request->send_P(200, "text/html", Page_Enregistrement, RetourVariable);
            delay(1000);
            ESP.restart();
          }

        } else {
          request->send(200, "text/plain", "Erreur d'écriture de la configuration...");
        }
      }

    } else if (String(p->name().c_str()) == "update") {

      if (String(p->value().c_str()) == "wifi") {
        int params = request->params();
        for (int i = 0; i < params; i++) {
          AsyncWebParameter* p = request->getParam(i);
          if (p->isPost()) {
            SPIFFS_ID = IDNetwork;

            if (p->name() == "ssid") SPIFFS_SSID = p->value().c_str();
            if (p->name() == "pass") SPIFFS_Pass = p->value().c_str();
            if (p->name() == "ip") SPIFFS_IP = p->value().c_str();
          }
        }
        if (SPIFFS_UpdateReseau()) {
          request->send_P(200, "text/html", Page_ReseauxEnreg, RetourVariable);
        } else {
          TITRE = "Erreur!";
          MESSAGE = "Erreur d'écriture de la configuration...";
          request->send_P(200, "text/html", Page_Message, RetourVariable);
        }
      }
    }
  });




  server.on("/updatemodule", HTTP_GET, [](AsyncWebServerRequest* request) {
    char CPass[50];
    Uncrypt_Pass.toCharArray(CPass, 50);
    if (!request->authenticate(Ident_ID, CPass)) return request->requestAuthentication();

    if (Action != ACTION_UPDATE) Action = ACTION_UPDATE;
    //server.end();
    //bool Result = update_module(UpdateURL);
    TITRE = "Mise à jour en cours...";
    MESSAGE = "Initialisation de la mise à jour.";
    request->send_P(200, "text/html", Page_Message, RetourVariable);
  });

  /*server.on("/updatemodule", HTTP_GET, [](AsyncWebServerRequest* request) {
    char* html = "<form method='POST' action='/doUpdate' enctype='multipart/form-data'><input type='file' name='update' accept='.bin'><input type='submit' value='Update'></form>";
    request->send(200, "text/html", html);
  });*/

  server.on(
    "/doUpdateFile", HTTP_POST,
    [](AsyncWebServerRequest* request) {},
    [](AsyncWebServerRequest* request, const String& filename, size_t index, uint8_t* data, size_t len, bool final) {
      handleDoUpdate(request, filename, index, data, len, final);
      TITRE = "Mise à jour en cours...";
      MESSAGE = "Le module redémarrera une fois la mise à jour terminée.";
      request->send_P(200, "text/html", Page_Message, RetourVariable);
    });




  server.on("/load", HTTP_GET, [](AsyncWebServerRequest* request) {
    char CPass[50];
    Uncrypt_Pass.toCharArray(CPass, 50);
    if (!request->authenticate(Ident_ID, CPass))
      return request->requestAuthentication();
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "nav") {

      if (String(p->value().c_str()) == "wifi") {
        request->send_P(200, "text/html", Page_ManageurWiFi, RetourVariable);
      } else if (String(p->value().c_str()) == "wifisr") {
        request->send_P(200, "text/html", Page_ManageurWiFiSansR, RetourVariable);
      } else if (String(p->value().c_str()) == "params") {
        request->send_P(200, "text/html", Page_Parametres, RetourVariable);
      } else if (String(p->value().c_str()) == "mqtt") {
        request->send_P(200, "text/html", Page_MQTT, RetourVariable);
      } else if (String(p->value().c_str()) == "system") {
        request->send_P(200, "text/html", Page_Sys, RetourVariable);
      } else if (String(p->value().c_str()) == "configAP") {
        request->send_P(200, "text/html", Page_ConfigAP, RetourVariable);
      } else if (String(p->value().c_str()) == "rst") {
        request->send_P(200, "text/html", Page_Donnees, RetourVariable);
      } else if (String(p->value().c_str()) == "listnetwork") {
        request->send_P(200, "text/html", Page_ReseauxEnreg, RetourVariable);
      } else if (String(p->value().c_str()) == "checkupdate") {
        String Retour;
        if (SetupModuleDone) {
          String version = SPIFFS_Uncrypt(SPIFFS_Config_Module["module"][0]["version"].as<String>());

          WiFiClientSecure secure;
          secure.setInsecure();
          HTTPClient http;
          http.setTimeout(10000);
          if (!http.begin(secure, MIRA_GITHUB_VERSION_URL)) {
            TITRE = "Mise à jour";
            Retour = "Impossible d'initialiser la connexion vers GitHub.";
          } else {
            int response = http.GET();
            if (response != HTTP_CODE_OK) {
              TITRE = "Mise à jour";
              Retour = "Impossible de vérifier les mises à jour sur GitHub (HTTP " + String(response) + ").";
            } else {
              DynamicJsonDocument doc(1024);
              DeserializationError err = deserializeJson(doc, http.getStream());
              if (err) {
                TITRE = "Mise à jour";
                Retour = "Le fichier version.json de GitHub est invalide.";
              } else {
                String project = doc["project"] | "";
                String remoteVersion = doc["version"] | "";
                String binUrl = doc["bin"] | MIRA_GITHUB_BIN_URL;
                if (project != "Mira Panel" || !remoteVersion.length()) {
                  TITRE = "Mise à jour";
                  Retour = "Les informations de mise à jour GitHub ne correspondent pas à Mira Panel.";
                } else if (miraCompareVersion(remoteVersion, version) <= 0) {
                  TITRE = "Tout est OK !";
                  Retour = "Mira Panel est à jour.<br><br>Version actuelle : <b>" + version + "</b>";
                } else {
                  UpdateURL = binUrl;
                  TITRE = "Nouvelle version disponible";
                  Retour = "<b>Version actuelle :</b> " + version + "<br><br>";
                  Retour += "<b>Nouvelle version :</b> " + remoteVersion + "<br><br>";
                  Retour += "<form method=\"GET\" action=\"/updatemodule\">";
                  Retour += "<input class=\"Bouton\" type=\"submit\" name=\"upload\" value=\"Installer la mise à jour\">";
                  Retour += "</form>";
                }
              }
            }
            http.end();
          }

          Retour += "<br><br><b><div>Mise à jour manuelle :</div></b>";
          Retour += "<form method='POST' action='/doUpdateFile' enctype='multipart/form-data'><input type='file' name='update' accept='.bin'><br><input class=\"Bouton\" type='submit' value='Installer le fichier .bin'></form>";
        } else {
          TITRE = "Mise à jour";
          Retour = "Configuration du module indisponible.<br><br>";
          Retour += "<form method='POST' action='/doUpdateFile' enctype='multipart/form-data'><input type='file' name='update' accept='.bin'><br><input class=\"Bouton\" type='submit' value='Installer le fichier .bin'></form>";
        }

        MESSAGE = Retour;
        request->send_P(200, "text/html", Page_Message, RetourVariable);

      } else if (String(p->value().c_str()) == "update") {
        p = request->getParam(1);
        if (String(p->name().c_str()) == "network") {
          IDNetwork = String(p->value().c_str());
          request->send_P(200, "text/html", Page_ModificationReseau, RetourVariable);
        }
      } else if (String(p->value().c_str()) == "id") {

        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        String Retour = "";

        for (int i = 0; i < Actions.size(); i++) {

          if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "button") {
            String Nom = SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
            String ID = SPIFFS_Config_Actions["actions"][i]["id"].as<String>();
            String Pass = Uncrypt_Pass;

            Retour += "<div class=\"FondCadre\">";
            Retour += "Nom: <b>" + Nom + "</b>";
            Retour += "<br>";
            Retour += "Type: <b>Button</b>";
            Retour += "<br>";
            Retour += "ID: <b>" + ID;
            Retour += "</b><br>";
            Retour += "<br>";
            Retour += "<a href=\"http://" + StringAdresseIP + "/update?key=" + Pass + "&button=" + ID + "\">http://" + StringAdresseIP + "/update?key=" + Pass + "&button=" + ID + "</a>";
            Retour += "<br>";
            Retour += "</div>";
            Retour += "<br>";


          } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "httpaction") {
            String Nom = SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
            String ID = SPIFFS_Config_Actions["actions"][i]["id"].as<String>();
            String Pass = Uncrypt_Pass;

            Retour += "<div class=\"FondCadre\">";
            Retour += "Nom: <b>" + Nom + "</b>";
            Retour += "<br>";
            Retour += "Type: <b>HTTP Action</b>";
            Retour += "<br>";
            Retour += "ID: <b>" + ID;
            Retour += "</b><br>";
            Retour += "<br>";
            Retour += "<a href=\"http://" + StringAdresseIP + "/update?key=" + Pass + "&httpaction=" + ID + "\">http://" + StringAdresseIP + "/update?key=" + Pass + "&httpaction=" + ID + "</a>";
            Retour += "<br>";
            Retour += "</div>";
            Retour += "<br>";


          } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "toggle") {
            String Nom = SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
            String Value0 = SPIFFS_Config_Actions["actions"][i]["value0"].as<String>();
            String Value1 = SPIFFS_Config_Actions["actions"][i]["value1"].as<String>();
            String ID0 = SPIFFS_Config_Actions["actions"][i]["id0"].as<String>();
            String ID1 = SPIFFS_Config_Actions["actions"][i]["id1"].as<String>();
            String Pass = Uncrypt_Pass;

            Retour += "<div class=\"FondCadre\">";
            Retour += "Nom: <b>" + Nom + "</b>";
            Retour += "<br>";
            Retour += "Type: <b>Toggle</b>";
            Retour += "<br>";
            Retour += "ID - " + Value0 + ": <b>" + ID0;
            Retour += "</b><br>";
            Retour += "ID - " + Value1 + ": <b>" + ID1;
            Retour += "</b><br>";
            Retour += "<br>POST ";
            Retour += Value0 + ": <a href=\"http://" + StringAdresseIP + "/update?key=" + Pass + "&toggle=" + ID0 + "\">http://" + StringAdresseIP + "/update?key=" + Pass + "&toggle=" + ID0 + "</a>";
            Retour += "<br>POST ";
            Retour += Value1 + ": <a href=\"http://" + StringAdresseIP + "/update?key=" + Pass + "&toggle=" + ID1 + "\">http://" + StringAdresseIP + "/update?key=" + Pass + "&toggle=" + ID1 + "</a>";
            Retour += "<br>";
            Retour += "GET: <a href=\"http://" + StringAdresseIP + "/get?key=" + Pass + "&toggle=" + ID0 + "\">http://" + StringAdresseIP + "/get?key=" + Pass + "&toggle=" + ID0 + "</a>";
            Retour += "<br>";
            Retour += "</div>";
            Retour += "<br>";

          } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "info") {
            String Nom = SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
            String ID = SPIFFS_Config_Actions["actions"][i]["id"].as<String>();
            String Pass = Uncrypt_Pass;

            Retour += "<div class=\"FondCadre\">";
            Retour += "Nom: <b>" + Nom + "</b>";
            Retour += "<br>";
            Retour += "Type: <b>Info</b>";
            Retour += "<br>";
            Retour += "ID: <b>" + ID;
            Retour += "</b><br>";
            Retour += "<br>POST: ";
            Retour += "<a href=\"http://" + StringAdresseIP + "/update?key=" + Pass + "&info=" + ID + "&value=Info Test\">http://" + StringAdresseIP + "/update?key=" + Pass + "&info=" + ID + "&value=Info Test</a>";
            Retour += "<br>";
            Retour += "GET: <a href=\"http://" + StringAdresseIP + "/get?key=" + Pass + "&info=" + ID + "\">http://" + StringAdresseIP + "/get?key=" + Pass + "&info=" + ID + "</a>";
            Retour += "<br>";
            Retour += "</div>";
            Retour += "<br>";

          } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "inputbox") {
            String Nom = SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
            String ID = SPIFFS_Config_Actions["actions"][i]["id"].as<String>();
            String Pass = Uncrypt_Pass;

            Retour += "<div class=\"FondCadre\">";
            Retour += "Nom: <b>" + Nom + "</b>";
            Retour += "<br>";
            Retour += "Type: <b>Input Box</b>";
            Retour += "<br>";
            Retour += "ID: <b>" + ID;
            Retour += "</b><br>";
            Retour += "<br>POST: ";
            Retour += "<a href=\"http://" + StringAdresseIP + "/update?key=" + Pass + "&inputbox=" + ID + "&value=TextBox Test\">http://" + StringAdresseIP + "/update?key=" + Pass + "&inputbox=" + ID + "&value=TextBox Test</a>";
            Retour += "<br>";
            Retour += "</div>";
            Retour += "<br>";

          } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "infofa") {
            String Nom = SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
            String ID = SPIFFS_Config_Actions["actions"][i]["id"].as<String>();
            String Pass = Uncrypt_Pass;

            Retour += "<div class=\"FondCadre\">";
            Retour += "Nom: <b>" + Nom + "</b>";
            Retour += "<br>";
            Retour += "Type: <b>Info FA</b>";
            Retour += "<br>";
            Retour += "ID: <b>" + ID;
            Retour += "</b><br>";
            Retour += "<br>POST: ";
            Retour += "<a href=\"http://" + StringAdresseIP + "/update?key=" + Pass + "&info=" + ID + "&value=fa-solid fa-thumbs-up fa-5x\">http://" + StringAdresseIP + "/update?key=" + Pass + "&infofa=" + ID + "&value=fa-solid fa-thumbs-up fa-5x</a>";
            Retour += "<br>";
            Retour += "GET: <a href=\"http://" + StringAdresseIP + "/get?key=" + Pass + "&info=" + ID + "\">http://" + StringAdresseIP + "/get?key=" + Pass + "&infofa=" + ID + "</a>";
            Retour += "<br>";
            Retour += "</div>";
            Retour += "<br>";

          } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "color") {
            String Nom = SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
            String ID = SPIFFS_Config_Actions["actions"][i]["id"].as<String>();
            String Pass = Uncrypt_Pass;

            Retour += "<div class=\"FondCadre\">";
            Retour += "Nom: <b>" + Nom + "</b>";
            Retour += "<br>";
            Retour += "Type: <b>Color</b>";
            Retour += "<br>";
            Retour += "ID: <b>" + ID;
            Retour += "</b><br>";
            Retour += "<br>POST: ";
            Retour += "<a href=\"http://" + StringAdresseIP + "/update?key=" + Pass + "&color=" + ID + "&r=255&g=0&b=0\">http://" + StringAdresseIP + "/update?key=" + Pass + "&color=" + ID + "&r=255&g=0&b=0</a>";
            Retour += "<br>";
            Retour += "</div>";
            Retour += "<br>";
          } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "range") {
            String Nom = SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
            String ID = SPIFFS_Config_Actions["actions"][i]["id"].as<String>();
            String Pass = Uncrypt_Pass;

            Retour += "<div class=\"FondCadre\">";
            Retour += "Nom: <b>" + Nom + "</b>";
            Retour += "<br>";
            Retour += "Type: <b>Range</b>";
            Retour += "<br>";
            Retour += "ID: <b>" + ID;
            Retour += "</b><br>";
            Retour += "<br>POST: ";
            Retour += "<a href=\"http://" + StringAdresseIP + "/update?key=" + Pass + "&range=" + ID + "&value=75\">http://" + StringAdresseIP + "/update?key=" + Pass + "&range=" + ID + "&value=75</a>";
            Retour += "<br>";
            Retour += "</div>";
            Retour += "<br>";
          } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "list") {
            String NomListe = SPIFFS_Config_Actions["actions"][i]["nomliste"].as<String>();
            String Nom = SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
            String ID = SPIFFS_Config_Actions["actions"][i]["id"].as<String>();
            String Pass = Uncrypt_Pass;

            Retour += "<div class=\"FondCadre\">";
            Retour += "Liste: <b>" + NomListe + "</b>";
            Retour += "<br>";
            Retour += "Nom: <b>" + Nom + "</b>";
            Retour += "<br>";
            Retour += "Type: <b>List</b>";
            Retour += "<br>";
            Retour += "ID: <b>" + ID;
            Retour += "</b><br>";
            Retour += "<br>POST: ";
            Retour += "<a href=\"http://" + StringAdresseIP + "/update?key=" + Pass + "&list=" + NomListe + "&value=" + ID + "\">http://" + StringAdresseIP + "/update?key=" + Pass + "&list=" + NomListe + "&value=" + ID + "</a>";
            Retour += "<br>POST: ";
            Retour += "<a href=\"http://" + StringAdresseIP + "/update?key=" + Pass + "&listvalue=" + NomListe + "&value=" + Nom + "\">http://" + StringAdresseIP + "/update?key=" + Pass + "&listvalue=" + NomListe + "&value=" + Nom + "</a>";
            Retour += "<br>";
            Retour += "</div>";
            Retour += "<br>";
          }
        }
        TITRE = "Requêtes HTTP";
        MESSAGE = Retour;
        request->send_P(200, "text/html", Page_Message, RetourVariable);
      } else if (String(p->value().c_str()) == "removenetwork") {

        SPIFFS_ID = IDNetwork;
        if (SPIFFS_RemoveReseau()) {
          request->send_P(200, "text/html", Page_ReseauxEnreg, RetourVariable);
        } else {
          TITRE = "Erreur!";
          MESSAGE = "Impossible de supprimer ce réseau...";
          request->send_P(200, "text/html", Page_Message, RetourVariable);
        }
      } else if (String(p->value().c_str()) == "reboot") {
        request->redirect("/");
        unsigned long dly = millis();
        while (millis() - dly < 2000) {
        }
        ESP.restart();

      } else if (String(p->value().c_str()) == "rstnetwork") {
        JsonArray Reseau = SPIFFS_Config_Reseau["reseau"];
        if (Reseau.size() == 0) {
          if (_Debug == true) Serial.println(F("Mira:  Configuration vide! Suppression inutile!"));
          request->send_P(200, "text/html", Page_Sys, RetourVariable);
        } else {
          SPIFFS_ResetReseau();
          SPIFFS_CreationConfigReseau();
          TITRE = "Paramètres réseaux supprimés!";
          MESSAGE = "";
          request->send_P(200, "text/html", Page_Message, RetourVariable);
        }
      } else if (String(p->value().c_str()) == "rstparams") {
        JsonArray Params = SPIFFS_Config_Params["params"];
        JsonArray lvgl = mira_Json_LVGL["lvgl"];
        if (Params.size() == 0 && lvgl.size()) {
          if (_Debug == true) Serial.println(F("Mira:  Configuration vide! Suppression inutile!"));
          request->redirect("/load?nav=rst");
        } else {
          SPIFFS_ResetParams();
          SPIFFS_CreationConfigParams();
          SPIFFS_Creation_lvgl();
          TITRE = "Paramètres de configuration supprimés!";
          MESSAGE = "";

          request->redirect("/");
        }
      } else if (String(p->value().c_str()) == "rstall") {
        delay(100);
        SPIFFS_Format();
        delay(100);

        request->redirect("/");
        unsigned long dly = millis();
        while (millis() - dly < 1000) {
        }
        ESP.restart();
      }
    }
  });


  server.on("/get", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {
      AsyncWebParameter* p = request->getParam(1);

      if (String(p->name().c_str()) == "toogle" || String(p->name().c_str()) == "toggle") {

        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {
          if (SPIFFS_Config_Actions["actions"][i]["id0"].as<String>() == String(p->value().c_str()) || SPIFFS_Config_Actions["actions"][i]["id1"].as<String>() == String(p->value().c_str())) {

            String Nom = SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
            String State = SPIFFS_Config_Actions["actions"][i]["state"].as<String>();
            State.replace(Nom, "");
            request->send(200, "text/plain", State);

            break;
          }
          if (i == Actions.size() - 1) {
            request->send(200, "text/plain", "Null");
            break;
          }
        }
      } else if (String(p->name().c_str()) == "info") {
        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {
          if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(p->value().c_str())) {

            request->send(200, "text/plain", SPIFFS_Config_Actions["actions"][i]["value"].as<String>());

            break;
          }
          if (i == Actions.size() - 1) {
            request->send(200, "text/plain", "Null");
            break;
          }
        }

      } else if (String(p->name().c_str()) == "infofa") {
        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        for (int i = 0; i < Actions.size(); i++) {
          if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(p->value().c_str())) {

            request->send(200, "text/plain", SPIFFS_Config_Actions["actions"][i]["value"].as<String>());

            break;
          }
          if (i == Actions.size() - 1) {
            request->send(200, "text/plain", "Null");
            break;
          }
        }

      } else if (String(p->name().c_str()) == "id") {

        JsonArray Actions = SPIFFS_Config_Actions["actions"];
        String Retour = String(NomProg) + ": Identite des commandes.";
        Retour += "\n";
        Retour += "\n";
        for (int i = 0; i < Actions.size(); i++) {

          if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "button" || SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "info") {
            Retour += "Nom: " + SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
            Retour += "\n";
            Retour += "ID: " + SPIFFS_Config_Actions["actions"][i]["id"].as<String>();
            Retour += "\n";
            Retour += "\n";
          } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "toggle") {
            Retour += "Nom: " + SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
            Retour += "\n";
            Retour += "ID " + SPIFFS_Config_Actions["actions"][i]["value0"].as<String>() + ": " + SPIFFS_Config_Actions["actions"][i]["id0"].as<String>();
            Retour += "\n";
            Retour += "ID " + SPIFFS_Config_Actions["actions"][i]["value1"].as<String>() + ": " + SPIFFS_Config_Actions["actions"][i]["id1"].as<String>();
            Retour += "\n";
            Retour += "\n";
          }
        }




        request->send(200, "text/plain", Retour);
      } else if (String(p->name().c_str()) == "param") {

        String Parametre = String(p->value().c_str());
        JsonArray Params = SPIFFS_Config_Params["params"];
        for (int i = 0; i < Params.size(); i++) {
          if (SPIFFS_Config_Params["params"][i]["param"].as<String>() == Parametre) {
            request->send(200, "text/html", SPIFFS_Config_Params["params"][i]["value"].as<String>());
            break;
          }
        }
      }
    }
  });

  server.on("/getallparams", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {

      String Retour_Json = SPIFFS_ReturnAllParams();
      request->send(200, "text/plain", Retour_Json);
    } else {
      request->send(200, "text/plain", "Clé invalide");
    }
  });




  server.on("/reboot", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {
      if (_Debug == true) Serial.println(F("Mira:  Redémarrage du module."));
      request->send(200, "text/plain", "OK");
      ESP.restart();
    } else {
      request->send(200, "text/plain", "Clé invalide");
    }
  });



  server.on("/updateparam", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {
      AsyncWebParameter* p = request->getParam(1);
      if (String(p->name().c_str()) == "param") {
        SPIFFS_ADD_Param = String(p->value().c_str());
        AsyncWebParameter* p = request->getParam(2);
        if (String(p->name().c_str()) == "value") {
          SPIFFS_ADD_Value = String(p->value().c_str());
          SPIFFS_UpdateParam();
          request->send(200, "text/plain", "OK");

        } else {
          request->send(200, "text/plain", "Paramètre invalide");
        }
      } else {
        request->send(200, "text/plain", "Paramètre invalide");
      }
    } else {
      request->send(200, "text/plain", "Clé invalide");
    }
  });

  server.on("/addparam", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {
      AsyncWebParameter* p = request->getParam(1);
      if (String(p->name().c_str()) == "param") {
        SPIFFS_ADD_Param = String(p->value().c_str());
        AsyncWebParameter* p = request->getParam(2);
        if (String(p->name().c_str()) == "value") {
          SPIFFS_ADD_Value = String(p->value().c_str());
          AsyncWebParameter* p = request->getParam(3);
          if (String(p->name().c_str()) == "type") {
            if (String(p->value().c_str()) == "text" || String(p->value().c_str()) == "hidden-text" || String(p->value().c_str()) == "toogle" || String(p->value().c_str()) == "toggle") {
              SPIFFS_ADD_Type = String(p->value().c_str());
              SPIFFS_AddParam();

              request->send(200, "text/plain", "OK");

            } else {
              request->send(200, "text/plain", "Type invalide");
            }

          } else {
            request->send(200, "text/plain", "Paramètre invalide");
          }

        } else {
          request->send(200, "text/plain", "Paramètre invalide");
        }
      } else {
        request->send(200, "text/plain", "Paramètre invalide");
      }
    } else {
      request->send(200, "text/plain", "Clé invalide");
    }
  });

  server.on("/addlistparam", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {
      AsyncWebParameter* p = request->getParam(1);
      if (String(p->name().c_str()) == "param") {
        SPIFFS_ADD_Param = String(p->value().c_str());
        AsyncWebParameter* p = request->getParam(2);
        if (String(p->name().c_str()) == "value") {
          SPIFFS_ADD_Value = String(p->value().c_str());
          AsyncWebParameter* p = request->getParam(3);
          if (String(p->name().c_str()) == "type") {
            if (String(p->value().c_str()) == "text" || String(p->value().c_str()) == "hidden-text" || String(p->value().c_str()) == "toogle" || String(p->value().c_str()) == "toggle" || String(p->value().c_str()) == "crypted-text") {
              SPIFFS_ADD_Type = String(p->value().c_str());
              SPIFFS_AddListParam();

              request->send(200, "text/plain", "OK");

            } else {
              request->send(200, "text/plain", "Type invalide");
            }

          } else {
            request->send(200, "text/plain", "Paramètre invalide");
          }

        } else {
          request->send(200, "text/plain", "Paramètre invalide");
        }
      } else {
        request->send(200, "text/plain", "Paramètre invalide");
      }
    } else {
      request->send(200, "text/plain", "Clé invalide");
    }
  });

  server.on("/removelistlvgl", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {

      RemoveListLVGL();
      request->send(200, "text/plain", "OK");

    } else {
      request->send(200, "text/plain", "Clé invalide");
    }
  });

  

  server.on("/addlistlvgl", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {

      AsyncWebParameter* p = request->getParam(1);
      if (String(p->name().c_str()) == "type") {
        LVGL_Type = String(p->value().c_str());

        AsyncWebParameter* p = request->getParam(2);
        if (String(p->name().c_str()) == "name") {
          LVGL_Name = String(p->value().c_str());

          AsyncWebParameter* p = request->getParam(3);
          if (String(p->name().c_str()) == "loc") {
            LVGL_Emplacement = String(p->value().c_str());

            AsyncWebParameter* p = request->getParam(4);
            if (String(p->name().c_str()) == "min") {
              LVGL_Min = String(p->value().c_str());

              AsyncWebParameter* p = request->getParam(5);
              if (String(p->name().c_str()) == "max") {
                LVGL_Max = String(p->value().c_str());

                AsyncWebParameter* p = request->getParam(6);
                if (String(p->name().c_str()) == "value") {
                  LVGL_Value = String(p->value().c_str());

                  AsyncWebParameter* p = request->getParam(7);
                  if (String(p->name().c_str()) == "unit") {
                    LVGL_Unit = String(p->value().c_str());
                    AddListLVGL();
                    request->send(200, "text/plain", "OK");

                  } else {
                    request->send(200, "text/plain", "Paramètre invalide6");
                  }
                } else {
                  request->send(200, "text/plain", "Paramètre invalide5");
                }
              } else {
                request->send(200, "text/plain", "Paramètre invalide4");
              }
            } else {
              request->send(200, "text/plain", "Paramètre invalide3");
            }
          } else {
            request->send(200, "text/plain", "Paramètre invalide2");
          }
        } else {
          request->send(200, "text/plain", "Paramètre invalide1");
        }
      } else {
        request->send(200, "text/plain", "Paramètre invalide0");
      }
    } else {
      request->send(200, "text/plain", "Clé invalide");
    }
  });

  server.on("/screenadd", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {

      AsyncWebParameter* p = request->getParam(1);
      if (String(p->name().c_str()) == "type") {
        LVGL_Type = String(p->value().c_str());

        AsyncWebParameter* p = request->getParam(2);
        if (String(p->name().c_str()) == "name") {
          LVGL_Name = String(p->value().c_str());

          AsyncWebParameter* p = request->getParam(3);
          if (String(p->name().c_str()) == "loc") {
            LVGL_Emplacement = String(p->value().c_str());

            AsyncWebParameter* p = request->getParam(4);
            if (String(p->name().c_str()) == "min") {
              LVGL_Min = String(p->value().c_str());

              AsyncWebParameter* p = request->getParam(5);
              if (String(p->name().c_str()) == "max") {
                LVGL_Max = String(p->value().c_str());

                AsyncWebParameter* p = request->getParam(6);
                if (String(p->name().c_str()) == "value") {
                  LVGL_Value = String(p->value().c_str());

                  AsyncWebParameter* p = request->getParam(7);
                  if (String(p->name().c_str()) == "unit") {
                    LVGL_Unit = String(p->value().c_str());
                    AddListLVGL();
                    String RetJson = "";
                    serializeJsonPretty(mira_Json_LVGL, RetJson);
                    request->send(200, "text/plain", RetJson);

                  } else {
                    request->send(200, "text/plain", "Paramètre invalide6");
                  }
                } else {
                  request->send(200, "text/plain", "Paramètre invalide5");
                }
              } else {
                request->send(200, "text/plain", "Paramètre invalide4");
              }
            } else {
              request->send(200, "text/plain", "Paramètre invalide3");
            }
          } else {
            request->send(200, "text/plain", "Paramètre invalide2");
          }
        } else {
          request->send(200, "text/plain", "Paramètre invalide1");
        }
      } else {
        request->send(200, "text/plain", "Paramètre invalide0");
      }
    } else {
      request->send(200, "text/plain", "Clé invalide");
    }
  });

  server.on("/screenformat", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {

      RemoveListLVGL();
      request->send(200, "text/plain", "Liste vidée!");

    } else {
      request->send(200, "text/plain", "Clé invalide");
    }
  });
  
  server.on("/screensave", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {
      SaveListLVGL();
      request->send(200, "text/plain", "Liste sauvegardée!");
      delay(500);
      ESP.restart();
    } else {
      request->send(200, "text/plain", "Clé invalide");
    }
  });

  server.on("/savelistlvgl", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {
      SaveListLVGL();
      request->send(200, "text/plain", "OK");
      delay(500);
      ESP.restart();
    } else {
      request->send(200, "text/plain", "Clé invalide");
    }
  });

  server.on("/createlistparam", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {
      SPIFFS_SaveParam_List();
      request->send(200, "text/plain", "OK");
    } else {
      request->send(200, "text/plain", "Clé invalide");
    }
  });

  server.on("/updatelistparam", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {
      AsyncWebParameter* p = request->getParam(1);
      if (String(p->name().c_str()) == "param") {
        SPIFFS_ADD_Param = String(p->value().c_str());
        AsyncWebParameter* p = request->getParam(2);
        if (String(p->name().c_str()) == "value") {
          SPIFFS_ADD_Value = String(p->value().c_str());

          SPIFFS_ADD_Type = String(p->value().c_str());
          SPIFFS_UpdateListParam();

          request->send(200, "text/plain", "OK");



        } else {
          request->send(200, "text/plain", "Paramètre invalide");
        }

      } else {
        request->send(200, "text/plain", "Paramètre invalide");
      }
    } else {
      request->send(200, "text/plain", "Clé invalide");
    }
  });

  server.on("/savelistparam", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {
      SPIFFS_SaveParam_List();
      request->send(200, "text/plain", "OK");
    } else {
      request->send(200, "text/plain", "Clé invalide");
    }
  });

  server.on("/getparam", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    JsonArray Actions = SPIFFS_Config_Params["params"];
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {
      p = request->getParam(1);
      for (int i = 0; i < Actions.size(); i++) {
        if (SPIFFS_Config_Params["params"][i]["param"].as<String>() == String(p->value().c_str())) {
          if (SPIFFS_Config_Params["params"][i]["type"].as<String>() == "crypted-text") {
            String Crypt = SPIFFS_Config_Params["params"][i]["value"].as<String>();
            String Decrypt = SPIFFS_Uncrypt(Crypt);

            request->send(200, "text/plain", String(Decrypt));
          } else {
            request->send(200, "text/plain", SPIFFS_Config_Params["params"][i]["value"].as<String>());
          }
          break;
        }
        if (i == Actions.size() - 1) {
          request->send(200, "text/plain", "Null");
          break;
        }
      }
    } else {
      request->send(200, "text/plain", "Clé invalide");
    }
  });

  server.on("/getmodule", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {


      request->send(200, "text/plain", SPIFFS_Config_Module["module"][0]["nom"].as<String>());
    } else {
      request->send(200, "text/plain", "Clé invalide");
    }
  });

  server.on("/testmodule", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    Serial.println(Uncrypt_Pass);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {


      request->send(200, "text/plain", "Tout est OK");
    } else {
      request->send(200, "text/plain", "Clé invalide");
    }
  });

  server.on("/setjeedomid", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {
      p = request->getParam(1);
      String id = String(p->value().c_str());
      p = request->getParam(2);
      String valuev = String(p->value().c_str());
      if (_Debug == true) Serial.print(F("Mira:  Modification du Json de l'index: "));
      if (_Debug == true) Serial.print(F("id: "));
      if (_Debug == true) Serial.print(id);
      if (_Debug == true) Serial.print(F(" Value: "));
      if (_Debug == true) Serial.println(valuev);

      SetJeedomId(id, valuev);
      //initWiFi();
      request->send(200, "text/plain", "OK");
    } else {
      request->send(200, "text/plain", "Clé invalide");
    }
  });

  server.on("/sendjeedomorderid", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {
      p = request->getParam(1);
      String id = String(p->value().c_str());

      OrderIdJeedom(id);



      //initWiFi();
      request->send(200, "text/plain", "OK");
    } else {
      request->send(200, "text/plain", "Clé invalide");
    }
  });

  server.on("/setjeedomtoggleid", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {
      p = request->getParam(1);
      String id = String(p->value().c_str());
      p = request->getParam(2);
      String value0 = String(p->value().c_str());
      p = request->getParam(3);
      String value1 = String(p->value().c_str());
      if (_Debug == true) Serial.print(F("Mira:  Modification du Json de l'index: "));
      if (_Debug == true) Serial.print(F("id: "));
      if (_Debug == true) Serial.print(id);
      if (_Debug == true) Serial.print(F(" Value 0: "));
      if (_Debug == true) Serial.print(value0);
      if (_Debug == true) Serial.print(F(" / Value 1: "));
      if (_Debug == true) Serial.println(value1);

      SetJeedomToggleId(id, value0, value1);
      //initWiFi();
      request->send(200, "text/plain", "OK");
    } else {
      request->send(200, "text/plain", "Clé invalide");
    }
  });

  server.on("/getindex", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {
      String Retour_Json = ReturnJSONIndex();
      request->send(200, "text/plain", Retour_Json);
    } else {
      request->send(200, "text/plain", "Clé invalide");
    }
  });

  server.on("/getlvgl", HTTP_GET, [](AsyncWebServerRequest* request) {
    AsyncWebParameter* p = request->getParam(0);
    if (String(p->name().c_str()) == "key" && String(p->value().c_str()) == Uncrypt_Pass) {
      String Retour_Json = ReturnJSONlvgl();
      request->send(200, "text/plain", Retour_Json);
    } else {
      request->send(200, "text/plain", "Clé invalide");
    }
  });


  events.onConnect([](AsyncEventSourceClient* client) {
    if (_Debug == true) Serial.println(F("Mira:  Client Connecté."));
    if (client->lastId()) {
      if (_Debug == true) Serial.printf("Mira:  Client reconnecté. Dernier ID: %u\n", client->lastId());
    }
    client->send("Mira:  Un salut de Mira!", NULL, millis(), 10000);
  });
  server.addHandler(&events);

  server.onNotFound([](AsyncWebServerRequest* request) {
    TITRE = "Erreur: 404";
    MESSAGE = "Oups! Cette page n'existe pas...";
    request->send_P(200, "text/html", Page_Message, RetourVariable);
  });

  server.begin();
}


MiraPanelServer::MiraPanelServer(char* NomProgramme) {
  NomProg = NomProgramme;
}

bool MiraPanelServer::ResetParams() {
  JsonArray Params = SPIFFS_Config_Params["params"];
  if (Params.size() == 0) {
    if (_Debug == true) Serial.println(F("Mira:  Configuration vide! Suppression inutile!"));
    return false;
  } else {
    SPIFFS_ResetParams();
    SPIFFS_CreationConfigParams();
    SPIFFS_Creation_lvgl();
    return true;
  }
}

bool MiraPanelServer::ResetNetwork() {
  JsonArray Reseau = SPIFFS_Config_Reseau["reseau"];
  if (Reseau.size() == 0) {
    if (_Debug == true) Serial.println(F("Mira:  Configuration vide! Suppression inutile!"));
    return false;
  } else {
    SPIFFS_ResetReseau();
    SPIFFS_CreationConfigReseau();
    return true;
  }
}
void MiraPanelServer::ResetAll() {
  SPIFFS_Format();
}

void MiraPanelServer::RSTHandler() {
  if (RST_Button) {

    if (digitalRead(Bouton_RST) == LOW) {

      if (!DoOneRST) {
        if (_Debug) Serial.println(F("Mira:  Bouton reset appuyé: Reset dans 15 secondes"));
        RST_Moment_Memorise = millis();
        DoOneRST = true;
      }

      if (RST_Moment_Memorise != 0) {
        RST_Moment_Present = millis();
        if (RST_Moment_Present - RST_Moment_Memorise >= 10000 && RST_Moment_Present - RST_Moment_Memorise < 15000) {
          if (_Debug) Serial.println(F("Mira:  Bouton reset appuyé: Reset dans 5 secondes"));

          if (Led_RST > 0) {
            digitalWrite(Led_RST, HIGH);
          }
        }
        if (RST_Moment_Present - RST_Moment_Memorise >= 15000) {
          if (Led_RST > 0) {
            digitalWrite(Led_RST, LOW);
          }
          if (_Debug) Serial.println(F("Mira:  Reset Total du module"));
          delay(1000);
          if (Led_RST > 0) {
            digitalWrite(Led_RST, HIGH);
          }

          SPIFFS_Format(true);
          if (Led_RST > 0) {
            digitalWrite(Led_RST, LOW);
          }

          DoOneRST = false;
          RST_Moment_Memorise = 0;
          RST_Moment_Present = 0;
        }
      }

    } else {

      if (DoOneRST) {
        if (Led_RST > 0) {
          digitalWrite(Led_RST, LOW);
        }
        if (_Debug) Serial.println(F("Mira: Annulation du reset."));
        DoOneRST = false;
        RST_Moment_Memorise = 0;
        RST_Moment_Present = 0;
      }
    }
  } else {
  }
}



int currentLength = 0;
int initLength = 0;
int prec = 0;
int memprec = 0;
bool MiraPanelServer::update_module(String fileName) {
  if (_Debug) Serial.println("[UPDATE] URL: " + fileName);
  if (!fileName.length()) return false;

  HTTPClient http;
  WiFiClient plainClient;
  WiFiClientSecure secureClient;
  secureClient.setInsecure();
  bool begun = fileName.startsWith("https://") ? http.begin(secureClient, fileName) : http.begin(plainClient, fileName);
  if (!begun) {
    if (_Debug) Serial.println("[UPDATE] Impossible d'initialiser HTTP");
    return false;
  }
  http.setTimeout(15000);
  int resp = http.GET();
  if (_Debug) Serial.printf("[UPDATE] HTTP %d\n", resp);
  if (resp != HTTP_CODE_OK) {
    http.end();
    return false;
  }

  int fileSizeSigned = http.getSize();
  if (fileSizeSigned <= 0) {
    if (_Debug) Serial.println("[UPDATE] Taille du firmware invalide");
    http.end();
    return false;
  }
  size_t fileSize = (size_t)fileSizeSigned;
  int cmd = (fileName.indexOf("spiffs") > -1) ? U_SPIFFS : U_FLASH;
  if (!Update.begin(fileSize, cmd)) {
    Update.printError(Serial);
    http.end();
    return false;
  }

  currentLength = 0;
  initLength = (int)fileSize;
  prec = 0;
  memprec = -1;

  WiFiClient* stream = http.getStreamPtr();
  uint8_t buff[1024];
  size_t remaining = fileSize;
  while (http.connected() && remaining > 0) {
    size_t available = stream->available();
    if (available) {
      int c = stream->readBytes(buff, (available > sizeof(buff)) ? sizeof(buff) : available);
      if (c <= 0) break;
      size_t written = Update.write(buff, (size_t)c);
      if (written != (size_t)c) {
        Update.printError(Serial);
        Update.abort();
        http.end();
        return false;
      }
      currentLength += c;
      remaining -= (size_t)c;
      prec = (currentLength * 100) / initLength;
      if (prec != memprec) {
        memprec = prec;
        String progress = "Progression: " + String(memprec) + " %";
        events.send(progress.c_str(), "divmessage", millis());
        if (_Debug) Serial.println("[UPDATE] " + String(memprec) + "%");
      }
    }
    delay(1);
  }

  bool ok = (remaining == 0) && Update.end(true);
  if (!ok) {
    Update.printError(Serial);
    http.end();
    return false;
  }

  events.send("Redémarrage de Mira Panel", "divmessage", millis());
  if (_Debug) Serial.println("[UPDATE] Mise à jour réussie");
  http.end();
  delay(500);
  ESP.restart();
  return true;
}


void MiraPanelServer::IndexSetEvent(int ID) {
  Resend = true;
  Action = ID;
}

String MiraPanelServer::GetJsonLvgl() {
  String Retour_Json = "";
  serializeJsonPretty(mira_Json_LVGL, Retour_Json);
  return Retour_Json;
}

void MiraPanelServer::ResetActionsForLvgl() {
  // Les IndexAdd* sont construits dynamiquement a partir de /miralvgl.json.
  // Lors d'une reprogrammation depuis Jeedom il faut repartir de l'ID 1,
  // sinon les IDs s'empilent et /updatenr ne correspond plus aux commandes Mira Panel.
  SPIFFS_Config_Actions.clear();
  SPIFFS_Config_Actions.createNestedArray("actions");
  IDAction = 1;
  Action = -1;
  Resend = true;
  // Force un nouvel appel a la commande init_cmd Jeedom au prochain tour de loop
  // pour remettre en place les IDs Jeedom de la nouvelle table.
  Init_Jeedom = false;

  NB_Listes = 0;
  ID_Memoire_Liste = 0;
  for (int i = 0; i < 99; ++i) {
    Memoire_Liste[i] = "";
    Listes[i] = "";
    Listes_Value[i] = "";
  }

  if (_Debug) Serial.println(F("Mira Panel:  Table actions LVGL remise a zero"));
}

String MiraPanelServer::HTTPGet(String URL) {
  if (URL != "") {
    HTTPClient http;
    http.begin(URL);
    http.addHeader("Content-Type", "text/plain");
    int httpResponseCode = http.GET();
    if (httpResponseCode > 0) {
      String response = http.getString();
      return response;
    } else {
      if (_Debug == true) Serial.print(F("Mira Panel:  Erreur GET HTTP: "));
      if (_Debug == true) Serial.println(httpResponseCode);
      return "Error";
    }
    http.end();
    delay(10);
  }
}

void MiraPanelServer::HTTPPost(String URL) {
  if (URL != "") {
    HTTPClient http;
    http.begin(URL);
    http.addHeader("Content-Type", "text/plain");
    int httpResponseCode = http.POST("HTTP POST Mira Panel Server Manager");
    if (httpResponseCode > 0) {

    } else {
      if (_Debug == true) Serial.print(F("Mira Panel:  Erreur POST HTTP: "));
      if (_Debug == true) Serial.println(httpResponseCode);
    }
    http.end();
    delay(10);
  }
}


String MiraPanelServer::GetKey() {
  return Uncrypt_Pass;
}

String MiraPanelServer::GetIP() {
  return SPIFFS_IP;
}




void MiraPanelServer::SetupModule(String Module, String ID_Module, String Version, String MAJ, String Type) {
  JsonArray TableMod = SPIFFS_Config_Module["module"];
  JsonObject RowMod = TableMod.createNestedObject();
  RowMod["nom"] = Module;
  RowMod["module"] = SPIFFS_Crypt(ID_Module);
  RowMod["version"] = SPIFFS_Crypt(Version);
  RowMod["url"] = SPIFFS_Crypt(MAJ);
  RowMod["type"] = SPIFFS_Crypt(Type);
  SetupModuleDone = true;
}



void MiraPanelServer::IndexAddSeg() {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  Action["nom"] = "eeSeg";
  Action["type"] = "eeSeg";
}

void MiraPanelServer::IndexAddSegWhite() {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  Action["nom"] = "eeSegw";
  Action["type"] = "eeSegw";
}

int MiraPanelServer::IndexAddButton(String Name, bool Return_Line) {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  Action["id"] = IDAction;
  IDAction++;
  Action["nom"] = Name;
  Action["type"] = "button";
  if (Return_Line) Action["return"] = "true";
  else Action["return"] = "false";


  return IDAction - 1;
}

int MiraPanelServer::IndexAddLittleButton(String Name, bool Return_Line) {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  Action["id"] = IDAction;
  IDAction++;
  Action["nom"] = Name;
  Action["type"] = "little_button";
  if (Return_Line) Action["return"] = "true";
  else Action["return"] = "false";


  return IDAction - 1;
}

int MiraPanelServer::AddHTTPAction(String Name) {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  Action["id"] = IDAction;
  IDAction++;
  Action["nom"] = Name;
  Action["type"] = "httpaction";
  return IDAction - 1;
}



void MiraPanelServer::IndexAddTitle(String Name, String Size) {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  //Action["id"] = IDAction;
  //IDAction++;
  Action["nom"] = Name;
  Action["type"] = "title";
  Action["size"] = Size;
}

void MiraPanelServer::IndexAddText(String Name, String Size) {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  //Action["id"] = IDAction;
  //IDAction++;
  Action["nom"] = Name;
  Action["type"] = "text_index";
  Action["size"] = Size;
}

int MiraPanelServer::IndexAddTooltip(String Name, String Content, bool Return_Line) {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  Action["id"] = IDAction;
  IDAction++;
  Action["nom"] = Name;
  Action["type"] = "tooltip";
  Action["content"] = Content;
  if (Return_Line) Action["return"] = "true";
  else Action["return"] = "false";

  return IDAction - 1;
}

int MiraPanelServer::IndexAddRange(String Name, int Min, int Max, int Default) {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  Action["id"] = IDAction;
  IDAction++;
  Action["nom"] = Name;
  Action["type"] = "range";
  Action["value"] = Default;
  Action["min"] = Min;
  Action["max"] = Max;
  return IDAction - 1;
}



void MiraPanelServer::IndexSetRange(int ID, int Value) {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  for (int i = 0; i < Actions.size(); i++) {
    if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(ID)) {
      SPIFFS_Config_Actions["actions"][i]["value"] = Value;
      char cID[5] = "";
      sprintf(cID, "%d", ID);

      String SValue = String(Value);
      char CValue[50];
      SValue.toCharArray(CValue, 50);
      events.send(CValue, cID, millis());
      break;
    }
  }
}

int MiraPanelServer::IndexGetRange(int ID) {
  int Val = 0;
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  for (int i = 0; i < Actions.size(); i++) {
    if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(ID) && SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "range") {
      Val = SPIFFS_Config_Actions["actions"][i]["value"].as<String>().toInt();
      return Val;
      break;
    }
  }
  return Val;
}

int MiraPanelServer::IndexAddInputBox(String Name, String Type) {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  Action["id"] = IDAction;
  IDAction++;
  Action["nom"] = Name;
  Action["type"] = "inputbox";
  Action["typebox"] = Type;
  Action["value"] = "";
  return IDAction - 1;
}

void MiraPanelServer::IndexSetInputBox(int ID, String Value) {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  for (int i = 0; i < Actions.size(); i++) {
    if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(ID)) {
      SPIFFS_Config_Actions["actions"][i]["value"] = Value;
      char cID[5] = "";
      sprintf(cID, "%d", ID);

      char CValue[50];
      Value.toCharArray(CValue, 50);
      events.send(CValue, cID, millis());
      break;
    }
  }
}

String MiraPanelServer::IndexGetInputBox(int ID) {
  String retour = "null";
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  for (int i = 0; i < Actions.size(); i++) {
    if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(ID)) {
      retour = SPIFFS_Config_Actions["actions"][i]["value"].as<String>();

      break;
    }
  }
  return retour;
}

int MiraPanelServer::IndexAddInfo(String Name, String Unit, String Size) {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  Action["id"] = IDAction;
  IDAction++;
  Action["nom"] = Name;
  Action["type"] = "info";
  Action["value"] = "";
  Action["size"] = Size;
  Action["unit"] = Unit;
  return IDAction - 1;
}

void MiraPanelServer::IndexSetInfo(int ID, String Value) {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  for (int i = 0; i < Actions.size(); i++) {
    if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(ID)) {
      Action = ID;
      SPIFFS_Config_Actions["actions"][i]["value"] = Value;
      char cID[5] = "";
      sprintf(cID, "%d", ID);

      char CValue[50];
      Value.toCharArray(CValue, 50);
      events.send(CValue, cID, millis());
      break;
    }
  }
  //if (JEEDOM_mira) JEEDOM_Moment_Memorise = millis();
}

String MiraPanelServer::IndexGetInfo(int ID) {
  String retour = "null";
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  for (int i = 0; i < Actions.size(); i++) {
    if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(ID)) {
      retour = SPIFFS_Config_Actions["actions"][i]["value"].as<String>();

      break;
    }
  }
  return retour;
}

/*int MiraPanelServer::IndexAddInfoFA(String Name, String Size) {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  Action["id"] = IDAction;
  IDAction++;
  Action["type"] = "infofa";
  Action["value"] = "";
  Action["size"] = Size;
  Action["nom"] = Name;
  return IDAction - 1;
}



void MiraPanelServer::IndexSetInfoFA(int ID, String Value) {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  for (int i = 0; i < Actions.size(); i++) {
    if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(ID)) {
      SPIFFS_Config_Actions["actions"][i]["value"] = Value;
      char cID[5] = "";
      sprintf(cID, "%d", ID);

      char CValue[50];
      Value.toCharArray(CValue, 50);
      events.send(CValue, cID, millis());
      break;
    }
   
  }
}*/

void MiraPanelServer::IndexAddHTML(String Value) {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  //Action["id"] = IDAction;
  //IDAction++;
  Action["value"] = Value;
  Action["type"] = "html";
}

void MiraPanelServer::IndexBackgroundStart() {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  //Action["id"] = IDAction;
  //IDAction++;
  Action["value"] = "<div class=\"FondCouleur\" style=\"margin-top:30px; margin-left:10px; margin-right:10px; padding-top:1px; border-radius:20px;\">";
  Action["type"] = "html";
}

void MiraPanelServer::IndexBackgroundFinish() {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  //Action["id"] = IDAction;
  //IDAction++;
  Action["value"] = "</div>";
  Action["type"] = "html";
}

void MiraPanelServer::IndexTileStart(String Width, String Height, String HTML_Color) {
  if (HTML_Color == "" || HTML_Color == "Defaut") HTML_Color = DarkColor;
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  //Action["id"] = IDAction;
  //IDAction++;
  if (Height == "" || Height == "Defaut") {
    Action["value"] = "<div class=\"tuile\" style=\" background: " + HTML_Color + "; width:" + Width + ";\">";
  } else {
    String Temp = "<div class=\"tuile\" style=\" background: " + HTML_Color + "; width:" + Width + "; height:" + Height + ";\">";
    Action["value"] = Temp;
  }
  Action["type"] = "html";
}

void MiraPanelServer::IndexTileWhiteStart(String Width, String Height, String HTML_Border_Color) {
  if (HTML_Border_Color == "" || HTML_Border_Color == "Defaut") HTML_Border_Color = DarkColor;
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  // Action["id"] = IDAction;
  //IDAction++;
  if (Height == "" || Height == "Defaut") {
    Action["value"] = "<div class=\"tuile_white\" style=\"border: 5px solid " + HTML_Border_Color + "; width:" + Width + ";\">";
  } else {

    String Temp = "<div class=\"tuile_white\" style=\"border: 5px solid " + HTML_Border_Color + "; width:" + Width + "; height:" + Height + "; \">";
    Action["value"] = Temp;
  }
  Action["type"] = "html";
}

void MiraPanelServer::IndexTileFinish() {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  //Action["id"] = IDAction;
  //IDAction++;
  Action["value"] = "</div>";
  Action["type"] = "html";
}

void MiraPanelServer::IndexContainerStart(int Width) {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  //Action["id"] = IDAction;
  //IDAction++;
  Action["value"] = "<div class=\"container\" style=\"width:" + String(Width) + "px;\">";
  Action["type"] = "html";
}

void MiraPanelServer::IndexContainerFinish() {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  //Action["id"] = IDAction;
  //IDAction++;
  Action["value"] = "</div>";
  Action["type"] = "html";
}

void MiraPanelServer::IndexTableStart() {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  //Action["id"] = IDAction;
  //IDAction++;
  Action["value"] = "<table class=\"table_container\">";
  Action["type"] = "html";
}

void MiraPanelServer::IndexTableFinish() {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  //Action["id"] = IDAction;
  //IDAction++;
  Action["value"] = "</table>";
  Action["type"] = "html";
}

void MiraPanelServer::IndexRowStart() {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  //Action["id"] = IDAction;
  //IDAction++;
  Action["value"] = "<tr>";
  Action["type"] = "html";
}

void MiraPanelServer::IndexRowFinish() {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  //Action["id"] = IDAction;
  //IDAction++;
  Action["value"] = "</tr>";
  Action["type"] = "html";
}

void MiraPanelServer::IndexCellStart(int Colspan, int Rowspan, String Align, String Width, String Height, bool Border) {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  //Action["id"] = IDAction;
  //IDAction++;
  if (Align == "") Align = "top";
  if (Border) {
    Action["value"] = "<td width=" + Width + " height=" + Height + " rowspan=\"" + String(Rowspan) + "\" colspan =\"" + String(Colspan) + "\" style=\"padding:0px; border: 1px solid " + DarkColor + "; vertical-align : " + Align + ";\">";

  } else {
    Action["value"] = "<td width=" + Width + " height=" + Height + " rowspan=\"" + String(Rowspan) + "\" colspan =\"" + String(Colspan) + "\" style=\"padding:0px; vertical-align : " + Align + ";\">";
  }
  Action["type"] = "html";
}

void MiraPanelServer::IndexCellFinish() {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  //Action["id"] = IDAction;
  //IDAction++;
  Action["value"] = "</td>";
  Action["type"] = "html";
}

int MiraPanelServer::IndexAddColor(String Name, int Default_R, int Default_G, int Default_B) {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  Action["id"] = IDAction;
  IDAction++;
  Action["nom"] = Name;
  Action["type"] = "color";
  Action["r"] = String(Default_R);
  Action["g"] = String(Default_G);
  Action["b"] = String(Default_B);
  return IDAction - 1;
}

void MiraPanelServer::IndexSetColor(int ID, int R, int G, int B) {


  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  for (int i = 0; i < Actions.size(); i++) {
    if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(ID)) {
      SPIFFS_Config_Actions["actions"][i]["r"] = String(R);
      SPIFFS_Config_Actions["actions"][i]["g"] = String(G);
      SPIFFS_Config_Actions["actions"][i]["b"] = String(B);
      String SNom = SPIFFS_Config_Actions["actions"][i]["id"].as<String>();
      char CNom[50];
      SNom.toCharArray(CNom, 50);
      long r = 0;
      r = (long)R;
      long g = 0;
      g = (long)G;
      long b = 0;
      b = (long)B;

      String SValue = "#000000";
      char CValue[7];
      sprintf(CValue, "#%02x%02x%02x", r, g, b);

      events.send(CValue, CNom, millis());

      break;
    }
  }
}





int MiraPanelServer::IndexGetColor_R(int ID) {
  int Val = 0;
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  for (int i = 0; i < Actions.size(); i++) {
    if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(ID) && SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "color") {
      Val = SPIFFS_Config_Actions["actions"][i]["r"].as<String>().toInt();
      return Val;
      break;
    }
  }
  return Val;
}

int MiraPanelServer::IndexGetColor_G(int ID) {
  int Val = 0;
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  for (int i = 0; i < Actions.size(); i++) {
    if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(ID) && SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "color") {
      Val = SPIFFS_Config_Actions["actions"][i]["g"].as<String>().toInt();
      return Val;
      break;
    }
  }
  return Val;
}

int MiraPanelServer::IndexGetColor_B(int ID) {
  int Val = 0;
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  for (int i = 0; i < Actions.size(); i++) {
    if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(ID) && SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "color") {
      Val = SPIFFS_Config_Actions["actions"][i]["b"].as<String>().toInt();
      return Val;
      break;
    }
  }
  return Val;
}



int* MiraPanelServer::IndexAddToogle(String Name, String Value_0, String Value_1, String Default) {
  if (Default == Value_0) Default = "Off";
  else Default = "On";

  Value_0 = "Off";
  Value_1 = "On";

  JsonArray Actions = SPIFFS_Config_Actions["actions"];

  static int ID[2];
  JsonObject Action = Actions.createNestedObject();
  Action["id0"] = IDAction;
  ID[0] = IDAction;
  IDAction++;
  Action["id1"] = IDAction;
  ID[1] = IDAction;
  IDAction++;
  Action["nom"] = Name;
  Action["type"] = "toggle";
  Action["value0"] = Value_0;
  Action["value1"] = Value_1;
  Action["state"] = Default;

  return ID;
}

int* MiraPanelServer::IndexAddToggle(String Name, String Value_0, String Value_1, String Default) {
  if (Default == Value_0) Default = "Off";
  else Default = "On";

  Value_0 = "Off";
  Value_1 = "On";

  JsonArray Actions = SPIFFS_Config_Actions["actions"];

  static int ID[2];
  JsonObject Action = Actions.createNestedObject();
  Action["id0"] = IDAction;
  ID[0] = IDAction;
  IDAction++;
  Action["id1"] = IDAction;
  ID[1] = IDAction;
  IDAction++;
  Action["nom"] = Name;
  Action["type"] = "toggle";
  Action["value0"] = Value_0;
  Action["value1"] = Value_1;
  Action["state"] = Default;

  return ID;
}

String MiraPanelServer::IndexGetToogle(int ID) {
  String retour = "null";
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  for (int i = 0; i < Actions.size(); i++) {
    if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(ID)) {
      retour = SPIFFS_Config_Actions["actions"][i]["state"].as<String>();

      break;
    }
  }
  return retour;
}

String MiraPanelServer::IndexGetToggle(int ID) {
  String retour = "null";
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  for (int i = 0; i < Actions.size(); i++) {
    if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(ID)) {
      retour = SPIFFS_Config_Actions["actions"][i]["state"].as<String>();

      break;
    }
  }
  return retour;
}



void MiraPanelServer::IndexSetToogle(int ID) {
  //ActionGet = false;
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  for (int i = 0; i < Actions.size(); i++) {
    if (SPIFFS_Config_Actions["actions"][i]["id0"].as<String>() == String(ID) || SPIFFS_Config_Actions["actions"][i]["id1"].as<String>() == String(ID)) {
      String Value;
      if (SPIFFS_Config_Actions["actions"][i]["id0"].as<String>() == String(ID)) {
        Value = SPIFFS_Config_Actions["actions"][i]["value0"].as<String>();
        SPIFFS_Config_Actions["actions"][i]["state"] = Value;
      } else if (SPIFFS_Config_Actions["actions"][i]["id1"].as<String>() == String(ID)) {
        Value = SPIFFS_Config_Actions["actions"][i]["value1"].as<String>();
        SPIFFS_Config_Actions["actions"][i]["state"] = Value;
      }

      char cID[5] = "";
      sprintf(cID, "%d", ID);

      char CValue[50];
      Value.toCharArray(CValue, 50);
      events.send(CValue, cID, millis());

      break;
    }
  }
}

void MiraPanelServer::IndexSetToggle(int ID) {
  //ActionGet = false;
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  for (int i = 0; i < Actions.size(); i++) {
    if (SPIFFS_Config_Actions["actions"][i]["id0"].as<String>() == String(ID) || SPIFFS_Config_Actions["actions"][i]["id1"].as<String>() == String(ID)) {
      String Value;
      if (SPIFFS_Config_Actions["actions"][i]["id0"].as<String>() == String(ID)) {
        Value = SPIFFS_Config_Actions["actions"][i]["value0"].as<String>();
        SPIFFS_Config_Actions["actions"][i]["state"] = Value;
      } else if (SPIFFS_Config_Actions["actions"][i]["id1"].as<String>() == String(ID)) {
        Value = SPIFFS_Config_Actions["actions"][i]["value1"].as<String>();
        SPIFFS_Config_Actions["actions"][i]["state"] = Value;
      }

      char cID[5] = "";
      sprintf(cID, "%d", ID);

      char CValue[50];
      Value.toCharArray(CValue, 50);
      events.send(CValue, cID, millis());

      break;
    }
  }
}


int MiraPanelServer::IndexAddList(String NameList, String Name, String Option) {
  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  JsonObject Action = Actions.createNestedObject();
  Action["id"] = IDAction;
  IDAction++;
  Action["nomliste"] = NameList;
  Action["nom"] = Name;
  Action["type"] = "list";
  Action["option"] = Option;


  bool Liste_Existante = false;
  for (int k = 0; k < NB_Listes; k++) {
    if (Listes[k] == NameList) {
      Liste_Existante = true;
      Action["value"] = Listes_Value[k];
      break;
    }
  }

  if (!Liste_Existante) {
    Listes[NB_Listes] = NameList;
    Listes_Value[NB_Listes] = IDAction - 1;

    NB_Listes++;
    Action["value"] = IDAction - 1;
  }


  return IDAction - 1;
}

void MiraPanelServer::IndexSetList(int ID) {



  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  for (int i = 0; i < Actions.size(); i++) {
    if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(ID)) {
      String Value = SPIFFS_Config_Actions["actions"][i]["id"].as<String>();
      String NomListe = SPIFFS_Config_Actions["actions"][i]["nomliste"].as<String>();
      for (int j = 0; j < Actions.size(); j++) {
        if (SPIFFS_Config_Actions["actions"][i]["nomliste"].as<String>() == SPIFFS_Config_Actions["actions"][j]["nomliste"].as<String>()) {
          SPIFFS_Config_Actions["actions"][j]["value"] = Value;
        }
      }



      String SNom = NomListe;
      char CNom[50];
      SNom.toCharArray(CNom, 50);
      char CValue[50];
      String SValue = String(ID);
      SValue.toCharArray(CValue, 50);
      events.send(CNom, CValue, millis());

      for (int k = 0; k < NB_Listes; k++) {
        if (Listes[k] == NomListe) {
          Listes_Value[k] = SValue;
        }
      }
      break;
    }
  }
}

int MiraPanelServer::IndexSetListByOption(String NameList, String Option) {



  JsonArray Actions = SPIFFS_Config_Actions["actions"];
  for (int i = 0; i < Actions.size(); i++) {
    if (SPIFFS_Config_Actions["actions"][i]["nomliste"].as<String>() == NameList && SPIFFS_Config_Actions["actions"][i]["option"].as<String>() == Option) {
      String Value = SPIFFS_Config_Actions["actions"][i]["id"].as<String>();
      String NomListe = SPIFFS_Config_Actions["actions"][i]["nomliste"].as<String>();
      String ID = SPIFFS_Config_Actions["actions"][i]["id"].as<String>();
      for (int j = 0; j < Actions.size(); j++) {
        if (SPIFFS_Config_Actions["actions"][i]["nomliste"].as<String>() == SPIFFS_Config_Actions["actions"][j]["nomliste"].as<String>()) {
          SPIFFS_Config_Actions["actions"][j]["value"] = Value;
        }
      }

      String SNom = NomListe;
      char CNom[50];
      SNom.toCharArray(CNom, 50);
      char CValue[50];
      String SValue = ID;
      SValue.toCharArray(CValue, 50);
      events.send(CNom, CValue, millis());

      for (int k = 0; k < NB_Listes; k++) {
        if (Listes[k] == NomListe) {
          Listes_Value[k] = SValue;
        }
      }
      return ID.toInt();
      break;
    }
  }
}

void MiraPanelServer::AddListParam(String Name, String Default, bool Hidden, bool Boolean) {
  SPIFFS_ADD_Param = Name;
  SPIFFS_ADD_Value = Default;
  if (Hidden) {
    SPIFFS_ADD_Type = "hidden-text";
  } else {
    if (Boolean) SPIFFS_ADD_Type = "toggle";
    else SPIFFS_ADD_Type = "text";
  }

  SPIFFS_AddListParam();
}

void MiraPanelServer::CreateListParam() {
  if (_Debug == true) Serial.println("Mira Panel:  Creation des paramètres...");
  SPIFFS_SaveParam_List();
}

void MiraPanelServer::UpdateListParam(String Name, String Value) {
  SPIFFS_ADD_Param = Name;
  SPIFFS_ADD_Value = Value;

  SPIFFS_UpdateListParam();
}

void MiraPanelServer::SaveListParam() {
  SPIFFS_SaveParam_List();
}




void MiraPanelServer::ResetButton(int PinButton, int PinLed) {
  RST_Button = true;
  Bouton_RST = PinButton;
  Led_RST = PinLed;
  pinMode(Bouton_RST, INPUT_PULLUP);
  if (PinLed > 0) {
    pinMode(Led_RST, OUTPUT);
    digitalWrite(Led_RST, LOW);
  }
}


void MiraPanelServer::AddParamText(String Name, String Default, bool Hidden) {
  SPIFFS_ADD_Param = Name;
  SPIFFS_ADD_Value = Default;
  if (Hidden) SPIFFS_ADD_Type = "hidden-text";
  else SPIFFS_ADD_Type = "text";
  SPIFFS_AddParam();
}

void MiraPanelServer::AddParamBool(String Name, bool Default) {
  SPIFFS_ADD_Param = Name;
  SPIFFS_ADD_Value = String(Default);
  SPIFFS_ADD_Type = "toggle";
  SPIFFS_AddParam();
}

String MiraPanelServer::GetParamText(String Name) {
  JsonArray Params = SPIFFS_Config_Params["params"];
  if (Params.size() > 0) {
    for (int i = 0; i < Params.size(); i++) {
      if (SPIFFS_Config_Params["params"][i]["param"].as<String>() == Name) {
        if (SPIFFS_Config_Params["params"][i]["type"].as<String>() == "crypted-text") {
          String Decrypt = SPIFFS_Uncrypt(SPIFFS_Config_Params["params"][i]["value"].as<String>());
          return Decrypt;
        } else {
          return SPIFFS_Config_Params["params"][i]["value"].as<String>();
        }

        break;
      }
      if (i == Params.size() - 1) {
        return "null";
      }
    }
  } else {
    return "null";
  }
}

bool MiraPanelServer::GetParamBool(String Name) {
  JsonArray Params = SPIFFS_Config_Params["params"];
  if (Params.size() > 0) {
    for (int i = 0; i < Params.size(); i++) {
      if (SPIFFS_Config_Params["params"][i]["param"].as<String>() == Name) {
        if (SPIFFS_Config_Params["params"][i]["value"].as<String>() == "0") {
          return false;
        } else if (SPIFFS_Config_Params["params"][i]["value"].as<String>() == "1") {
          return true;
        } else {
          return false;
        }
        break;
      }
      if (i == Params.size() - 1) {
        return false;
      }
    }
  } else {
    return false;
  }
}

void MiraPanelServer::RemoveParam(String Name) {
  SPIFFS_ADD_Param = Name;
  SPIFFS_RemoveParam();
}

void MiraPanelServer::UpdateParamText(String Name, String Value) {
  SPIFFS_ADD_Param = Name;
  SPIFFS_ADD_Value = Value;
  SPIFFS_UpdateParam();
}

void MiraPanelServer::UpdateParamBool(String Name, bool Value) {
  SPIFFS_ADD_Param = Name;
  if (Value == true) {
    SPIFFS_ADD_Value = "1";
  } else {
    SPIFFS_ADD_Value = "0";
  }

  SPIFFS_UpdateParam();
}


int MiraPanelServer::GetWiFiStatus() {
  if (ModeAP == true && ConnexionPerdue == false) {
    return 2;
  }
  if (ModeAP == false && ConnexionPerdue == false) {
    return 1;
  }
  if (ConnexionPerdue == true) {
    return 3;
  }
}

bool MiraPanelServer::IsSetupMode() {
  return ModeAP;
}


void MiraPanelServer::ScanWiFi() {
  //Scan des réseaux wifi
  if (_Debug == true) Serial.println(F("Mira:  Scan des réseaux Wi-Fi alentours"));
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  int n = WiFi.scanNetworks();
  if (n != 0) {
    for (int i = 0; i < n; i++) {
      if (i < 9) {
        ScanReseaux[i] = WiFi.SSID(i);
      }
    }
  }
}



bool MiraPanelServer::initPA() {
  if (_Debug == true) Serial.println(F("Mira:  Configuration du Point d'acces: "));

  IPAddress AP_local_ip;
  AP_local_ip.fromString(SPIFFS_Config_Reseau["ap"][0]["ip"].as<String>());
  delay(200);
  IPAddress AP_gateway(192, 168, 1, 1);
  IPAddress AP_subnet(255, 255, 255, 0);
  WiFi.mode(WIFI_AP_STA);
  delay(200);
  WiFi.softAPConfig(AP_local_ip, AP_gateway, AP_subnet);


  String SPass = Uncrypt_Pass;
  char CPass[100];
  SPass.toCharArray(CPass, 100);

  WiFi.softAP(NomProg, CPass);
  IPAddress IP = WiFi.softAPIP();
  if (_Debug == true) Serial.print(F("Mira:  Adresse IP Point d'acces: "));
  if (_Debug == true) Serial.println(IP);
  ModeAP = true;
  return true;
}

bool MiraPanelServer::initWiFi() {
  if (_Debug == true) Serial.println(F("Mira:  Initialisation du WiFi"));

  if (SPIFFS_Config_Reseau["reseau"][0]["ssid"] == "null") {
    return false;
  }
  WiFi.setTxPower(WIFI_POWER_19_5dBm);
  if (SPIFFS_IP != "Auto") {
    if (SPIFFS_IP != "" && SPIFFS_IP != "null") {
      String StringIP = SPIFFS_IP;
      IPAddress localIP;
      WiFi.mode(WIFI_STA);
      localIP.fromString(StringIP.c_str());
      if (!WiFi.config(localIP, gateway, subnet, param_dns)) {
        if (_Debug == true) Serial.println(F("Mira:  Erreur de configuration WiFi"));
        return false;
      }
    }
  }


  JsonArray reseaux = SPIFFS_Config_Reseau["reseau"];

  for (int scan = 0; scan < 10; scan++) {
    if (ScanReseaux[scan] != "") {
      for (int par = reseaux.size() - 1; par >= 0; par--) {
        String SSIDpar = SPIFFS_Config_Reseau["reseau"][par]["ssid"];
        if (SSIDpar == ScanReseaux[scan]) {
          String PASSpar = SPIFFS_Uncrypt(SPIFFS_Config_Reseau["reseau"][par]["pass"]);

          WiFi.begin(SSIDpar.c_str(), PASSpar.c_str());
          if (_Debug == true) Serial.print(F("Mira:  M2: Tentative de connexion à: "));
          if (_Debug == true) Serial.println(SSIDpar);

          if (WiFiConnect()) {
            if (_Debug == true) Serial.print(F("Mira:  M2: Connexion reussie à: "));
            if (_Debug == true) Serial.println(SSIDpar);
            if (_Debug == true) Serial.print(F("Mira:  M2: Adresse IP: "));
            if (_Debug == true) Serial.println(WiFi.localIP());
            StringAdresseIP = WiFi.localIP().toString();
            ModeAP = false;
            if (_Debug == true) Serial.print(F("Mira:  Signal: "));
            if (_Debug == true) Serial.println(WiFi.RSSI());
            return true;
          } else {
            if (_Debug == true) Serial.print(F("Mira:  M2: Connexion impossible à: "));
            if (_Debug == true) Serial.println(SSIDpar);
          }
        }
      }
    }
  }

  for (int i = reseaux.size() - 1; i >= 0; i--) {

    String SSID = SPIFFS_Config_Reseau["reseau"][i]["ssid"];
    String PASS = SPIFFS_Uncrypt(SPIFFS_Config_Reseau["reseau"][i]["pass"]);

    WiFi.begin(SSID.c_str(), PASS.c_str());
    if (_Debug == true) Serial.print(F("Mira:  Tentative de connexion à: "));
    if (_Debug == true) Serial.println(SSID);

    if (WiFiConnect()) {
      if (_Debug == true) Serial.print(F("Mira:  Connexion reussie à: "));
      if (_Debug == true) Serial.println(SSID);
      if (_Debug == true) Serial.print(F("Mira:  Adresse IP: "));
      if (_Debug == true) Serial.println(WiFi.localIP());
      StringAdresseIP = WiFi.localIP().toString();
      ModeAP = false;
      if (_Debug == true) Serial.print(F("Mira:  Signal: "));
      if (_Debug == true) Serial.println(WiFi.RSSI());
      return true;
    } else {
      if (_Debug == true) Serial.print(F("Mira:  Connexion impossible à: "));
      if (_Debug == true) Serial.println(SSID);
      if (i == 0) {
        return false;
      }
    }
  }
}

bool MiraPanelServer::ReInitWiFi() {
  if (_Debug == true) Serial.println(F("Mira:  Initialisation du WiFi"));

  String Conf = SPIFFS_Config_Reseau["reseau"][0]["ssid"];
  if (Conf == "null") {
    return false;
  }
  WiFi.setTxPower(WIFI_POWER_19_5dBm);
  if (SPIFFS_IP != "Auto") {
    if (SPIFFS_IP != "" && SPIFFS_IP != "null") {
      String StringIP = SPIFFS_IP;
      IPAddress localIP;
      localIP.fromString(StringIP.c_str());
      if (!WiFi.config(localIP, gateway, subnet, param_dns)) {
        if (_Debug == true) Serial.println(F("Mira:  Erreur de configuration WiFi"));
        return false;
      }
    }
  }


  JsonArray reseaux = SPIFFS_Config_Reseau["reseau"];

  for (int scan = 0; scan < 10; scan++) {
    if (ScanReseaux[scan] != "") {
      for (int par = reseaux.size() - 1; par >= 0; par--) {
        String SSIDpar = SPIFFS_Config_Reseau["reseau"][par]["ssid"];
        if (SSIDpar == ScanReseaux[scan]) {
          String PASSpar = SPIFFS_Uncrypt(SPIFFS_Config_Reseau["reseau"][par]["pass"]);

          WiFi.begin(SSIDpar.c_str(), PASSpar.c_str());
          if (_Debug == true) Serial.print(F("Mira:  M2: Tentative de connexion à: "));
          if (_Debug == true) Serial.println(SSIDpar);

          if (WiFiConnect()) {
            if (_Debug == true) Serial.print(F("Mira:  M2: Connexion reussie à: "));
            if (_Debug == true) Serial.println(SSIDpar);
            if (_Debug == true) Serial.print(F("Mira:  M2: Adresse IP: "));
            if (_Debug == true) Serial.println(WiFi.localIP());
            StringAdresseIP = WiFi.localIP().toString();
            ModeAP = false;
            if (_Debug == true) Serial.print(F("Mira:  Signal: "));
            if (_Debug == true) Serial.println(WiFi.RSSI());
            return true;
          } else {
            if (_Debug == true) Serial.print(F("Mira:  M2: Connexion impossible à: "));
            if (_Debug == true) Serial.println(SSIDpar);
          }
        }
      }
    }
  }

  for (int i = reseaux.size() - 1; i >= 0; i--) {

    String SSID = SPIFFS_Config_Reseau["reseau"][i]["ssid"];
    String PASS = SPIFFS_Uncrypt(SPIFFS_Config_Reseau["reseau"][i]["pass"]);

    WiFi.begin(SSID.c_str(), PASS.c_str());
    if (_Debug == true) Serial.print(F("Mira:  Tentative de connexion à: "));
    if (_Debug == true) Serial.println(SSID);

    if (WiFiConnect()) {
      if (_Debug == true) Serial.print(F("Mira:  Connexion reussie à: "));
      if (_Debug == true) Serial.println(SSID);
      if (_Debug == true) Serial.print(F("Mira:  Adresse IP: "));
      if (_Debug == true) Serial.println(WiFi.localIP());
      StringAdresseIP = WiFi.localIP().toString();
      ModeAP = false;
      if (_Debug == true) Serial.print(F("Mira:  Signal: "));
      if (_Debug == true) Serial.println(WiFi.RSSI());
      return true;
    } else {
      if (_Debug == true) Serial.print(F("Mira:  Connexion impossible à: "));
      if (_Debug == true) Serial.println(SSID);
      if (i == 0) {
        return false;
      }
    }
  }
}

bool MiraPanelServer::WiFiConnect() {
  unsigned long currentMillis = millis();
  previousMillis = currentMillis;
  while (WiFi.status() != WL_CONNECTED) {
    currentMillis = millis();
    if (currentMillis - previousMillis >= timeout) {
      return false;
    }
    delay(100);
  }
  ModeAP = false;
  return true;
}




String MiraPanelServer::RetourVariable(String var) {
  String RETOUR = "Null";

  auto GetLocalParamValue = [](const String& name) -> String {
    JsonArray Params = SPIFFS_Config_Params["params"];
    for (int i = 0; i < Params.size(); ++i) {
      if (SPIFFS_Config_Params["params"][i]["param"].as<String>() == name) {
        return SPIFFS_Config_Params["params"][i]["value"].as<String>();
      }
    }
    return "";
  };

  if (var == "MQTTACTIF") {
    String v = GetLocalParamValue("MQTT_Actif");
    return (v == "1" || v == "true") ? "1" : "0";
  }
  if (var == "MQTTCHECKED") {
    String v = GetLocalParamValue("MQTT_Actif");
    return (v == "1" || v == "true") ? "checked" : "";
  }
  if (var == "MQTTNOM") return GetLocalParamValue("MQTT_Nom");
  if (var == "MQTTSERVEUR") return GetLocalParamValue("MQTT_Serveur");
  if (var == "MQTTPORT") return GetLocalParamValue("MQTT_Port");
  if (var == "MQTTUSER") return GetLocalParamValue("MQTT_Utilisateur");
  if (var == "MQTTPASS") return GetLocalParamValue("MQTT_Mot_de_passe");
  if (var == "MQTTTABLE") {
    RETOUR = "";
    JsonArray Json_Array = mira_Json_LVGL["lvgl"];
    for (int i = 0; i < Json_Array.size(); ++i) {
      String nom = mira_Json_LVGL["lvgl"][i]["name"].as<String>();
      String type = mira_Json_LVGL["lvgl"][i]["type"].as<String>();
      if (!nom.length() && type == "datetime") nom = "Date et heure";
      RETOUR += "<tr><td>" + nom + "</td><td>" + type + "</td></tr>";
    }
    if (!RETOUR.length()) RETOUR = "<tr><td colspan='2'>Aucun widget programme</td></tr>";
    return RETOUR;
  }

  if (var == "MAJ") {
    if (SetupModuleDone)
      return RETOUR = "<button class=\"Bouton\" onclick=\"window.location.href = '/load?nav=checkupdate';\"style=\"text-decoration:none\"> Vérifier les mises à jour</button>";
    else {
      return RETOUR = "";
    }
  }
  if (var == "KEY") RETOUR = Uncrypt_Pass;

  if (var == "SSIDUPDATE") {
    JsonArray Reseaux = SPIFFS_Config_Reseau["reseau"];
    for (int i = 0; i < Reseaux.size(); i++) {
      if (SPIFFS_Config_Reseau["reseau"][i]["id"].as<String>() == IDNetwork) {
        return RETOUR = SPIFFS_Config_Reseau["reseau"][i]["ssid"].as<String>();
        break;
      }
    }
  }

  if (var == "PASSUPDATE") {
    JsonArray Reseaux = SPIFFS_Config_Reseau["reseau"];
    for (int i = 0; i < Reseaux.size(); i++) {
      if (SPIFFS_Config_Reseau["reseau"][i]["id"].as<String>() == IDNetwork) {
        return RETOUR = SPIFFS_Uncrypt(SPIFFS_Config_Reseau["reseau"][i]["pass"].as<String>());
        break;
      }
    }
  }

  if (var == "IPUPDATE") {
    JsonArray Reseaux = SPIFFS_Config_Reseau["reseau"];
    for (int i = 0; i < Reseaux.size(); i++) {
      if (SPIFFS_Config_Reseau["reseau"][i]["id"].as<String>() == IDNetwork) {
        return RETOUR = SPIFFS_Config_Reseau["reseau"][i]["ip"].as<String>();
        break;
      }
    }
  }

  if (var == "RESEAUXENREG") {
    RETOUR = "";
    JsonArray Reseaux = SPIFFS_Config_Reseau["reseau"];
    for (int i = 0; i < Reseaux.size(); i++) {
      RETOUR += "<span class=\"FondBlanc\">" + SPIFFS_Config_Reseau["reseau"][i]["id"].as<String>() + "</span><button onclick=\"window.location.href = '/load?nav=update&network=" + SPIFFS_Config_Reseau["reseau"][i]["id"].as<String>() + "';\" class=\"reseau\">" + SPIFFS_Config_Reseau["reseau"][i]["ssid"].as<String>() + "</button><br>";
    }
    return RETOUR;
  }

  if (var == "TITRE") {
    return RETOUR = TITRE;
  }

  if (var == "MESSAGE") {
    ScriptConstruct = "";
    ScriptConstruct += "<script>";
    ScriptConstruct += "if (!!window.EventSource) {";
    ScriptConstruct += "var source = new EventSource('/events');";
    ScriptConstruct += "source.addEventListener('open', function(e) {";
    ScriptConstruct += "console.log(\"Events Connected\");";
    ScriptConstruct += "}, false);";
    ScriptConstruct += "source.addEventListener('error', function(e) {";
    ScriptConstruct += "if (e.target.readyState != EventSource.OPEN) {";
    ScriptConstruct += "console.log(\"Events Disconnected\");";
    ScriptConstruct += "}";
    ScriptConstruct += "}, false);";
    ScriptConstruct += "source.addEventListener('message', function(e) {";
    ScriptConstruct += "console.log(\"message\", e.data);";
    ScriptConstruct += "}, false);";
    ScriptConstruct += "source.addEventListener('divmessage', function(e) {document.getElementById(\"divmessage\").innerHTML = e.data;}, false);";
    ScriptConstruct += "}</script>";
    RETOUR = "<div id=\"divmessage\">" + MESSAGE + "</div>";
    RETOUR += ScriptConstruct;
    return RETOUR;
  }

  if (var == "SCANRESEAUX") {
    RETOUR = "<b><label for=\"ReseauxScannes\">Réseaux scannés</label></b><br><select id=\"RS\" name=\"RS\" class=\"box\" onchange=\"Click(this.value)\" >";
    for (int j = 0; j < 10; j++) {
      if (ScanReseaux[j] != "") {
        RETOUR += " <option id=\"" + ScanReseaux[j] + "\" value=\"" + ScanReseaux[j] + "\">" + ScanReseaux[j] + "</option>";
        //RETOUR += "<button onclick=\"Click('" + ScanReseaux[j] + "')\"class=\"reseau\">" + ScanReseaux[j] + "</button><br>";
      }
    }
    RETOUR += "</select><br><br>";
    return RETOUR;
  }


  if (var == "APP") {
    RETOUR = NomProg;
    return RETOUR;
  }

  if (var == "SSID") {
    if (SPIFFS_SSID == "null") {
      RETOUR = "";
    } else {
      RETOUR = SPIFFS_SSID;
    }
    return RETOUR;
  }

  if (var == "IP") {
    if (SPIFFS_IP == "null") {
      RETOUR = "Auto";
    } else {
      RETOUR = SPIFFS_IP;
    }
    return RETOUR;
  }

  if (var == "DARKCOLOR") {
    RETOUR = DarkColor;
    return RETOUR;
  }

  if (var == "LIGHTCOLOR") {
    RETOUR = LightColor;
    return RETOUR;
  }

  if (var == "ACTIVECOLOR") {
    RETOUR = ActiveColor;
    return RETOUR;
  }

  if (var == "TEXTCOLOR") {
    RETOUR = TextColor;
    return RETOUR;
  }

  if (var == "POWERED") {
    RETOUR = Powered;
    return RETOUR;
  }

  if (var == "LITTLELOGO") {
    if (Little_Logo_URL != "") {
      RETOUR = "<div class=\"FondLittleLogo\"> <img style=\"width:" + String(Little_Logo_Width) + "px; height:" + String(Little_Logo_Height) + "px;\" src=\"" + Little_Logo_URL + "\"> </div>";
    } else {
      RETOUR = "";
    }
    return RETOUR;
  }

  if (var == "LOGO") {
    if (Logo_URL != "") {
      RETOUR = "<div class=\"FondLogo\"> <img style=\"width:" + String(Logo_Width) + "px; height:" + String(Logo_Height) + "px;\" src=\"" + Logo_URL + "\"> </div>";
    } else {
      RETOUR = "";
    }
    return RETOUR;
  }



  if (var == "PARAMS") {
    RETOUR = "";
    JsonArray Params = SPIFFS_Config_Params["params"];
    for (int i = 0; i < Params.size(); i++) {
      if (SPIFFS_Config_Params["params"][i]["type"].as<String>() == "text") {
        RETOUR += "<b><label>" + SPIFFS_Config_Params["params"][i]["param"].as<String>() + ":</label></b> <br><input class=\"box\" id=\"" + SPIFFS_Config_Params["params"][i]["param"].as<String>() + "\" name=\"" + SPIFFS_Config_Params["params"][i]["param"].as<String>() + "\" style=\"width: 900px; text-align: center;\" value=\"" + SPIFFS_Config_Params["params"][i]["value"].as<String>() + "\" type=\"text\"> <br><br>";
      } else if (SPIFFS_Config_Params["params"][i]["type"].as<String>() == "toogle" || SPIFFS_Config_Params["params"][i]["type"].as<String>() == "toggle") {

        RETOUR += "<b><div style=\"font-size: 40px;\">" + SPIFFS_Config_Params["params"][i]["param"].as<String>() + "</div></b>";

        String Nom = SPIFFS_Config_Params["params"][i]["param"].as<String>();
        String Value = SPIFFS_Config_Params["params"][i]["value"].as<String>();

        if (SPIFFS_Config_Params["params"][i]["value"].as<String>() == "0") {
          RETOUR += "<div><label class=\"label1\"><div class=\"toggle\"><input onclick=\"ClickToogle(this, '" + Nom + "')\" class=\"toggle-state\" type=\"checkbox\"><div class=\"toggle-inner\"><div class=\"indicator\"></div></div><div class=\"active-bg\"></div><div id=\"Value" + Nom + "\" class=\"textd\">Inactif</div></div></label></div><br>";
        } else {
          RETOUR += "<div><label class=\"label1\"><div class=\"toggle\"><input onclick=\"ClickToogle(this,'" + Nom + "')\" class=\"toggle-state\" type=\"checkbox\" checked><div class=\"toggle-inner\"><div class=\"indicator\"></div></div><div class=\"active-bg\"></div><div id=\"Value" + Nom + "\" class=\"textd\">Actif</div></div></label></div><br>";
        }
        RETOUR += "<input class=\"hide\" id=\"" + Nom + "\" name=\"" + Nom + "\" value=\"" + Value + "\" type=\"text\">";
      }
    }


    JsonArray Json_Array = mira_Json_LVGL["lvgl"];
    for (int i = 0; i < Json_Array.size(); i++) {
      if (mira_Json_LVGL["lvgl"][i]["type"] != "datetime" && mira_Json_LVGL["lvgl"][i]["type"] != "info")
        RETOUR += "<b><label>URL d'envoi d'état: " + mira_Json_LVGL["lvgl"][i]["name"].as<String>() + "</label></b> <br><input class=\"box\" id=\"" + mira_Json_LVGL["lvgl"][i]["name"].as<String>() + "\" name=\"" + mira_Json_LVGL["lvgl"][i]["name"].as<String>() + "\" style=\"width: 900px; text-align: center;\" value=\"" + mira_Json_LVGL["lvgl"][i]["url"].as<String>() + "\" type=\"text\"> <br><br>";
    }
    return RETOUR;
  }

  if (var == "ACTIFAP") {
    RETOUR = "";
    String Actif = SPIFFS_Config_Reseau["ap"][0]["actif"].as<String>();
    if (Actif == "0") {
      RETOUR += "<br><div><label class=\"label1\"><div class=\"toggle\"><input onclick=\"ClickToogle(this)\" class=\"toggle-state\" type=\"checkbox\"><div class=\"toggle-inner\"><div class=\"indicator\"></div></div><div class=\"active-bg\"></div><div id=\"texte\" class=\"textd\">Inactif</div></div></label></div><br>";
    } else {
      RETOUR += "<br><div><label class=\"label1\"><div class=\"toggle\"><input onclick=\"ClickToogle(this)\" class=\"toggle-state\" type=\"checkbox\" checked><div class=\"toggle-inner\"><div class=\"indicator\"></div></div><div class=\"active-bg\"></div><div id=\"texte\" class=\"textd\">Actif</div></div></label></div><br>";
    }
    RETOUR += "<input class=\"hide\" id=\"actif\" name=\"actif\" value=\"" + Actif + "\" type=\"text\">";
    return RETOUR;
  }

  if (var == "IPAP") {
    if (SPIFFS_Config_Reseau["ap"][0]["ip"].as<String>() == "null") {
      RETOUR = "";
    } else {
      RETOUR = SPIFFS_Config_Reseau["ap"][0]["ip"].as<String>();
    }
    return RETOUR;
  }

  if (var == "MDPAP") {
    if (SPIFFS_Config_Reseau["ap"][0]["passcrypt"].as<String>() == "null") {
      RETOUR = "";
    } else {
      RETOUR = Uncrypt_Pass;
    }
    return RETOUR;
  }



  if (var == "ACTIONS") {
    ScriptConstruct = "";
    ScriptConstruct += "<script>";
    ScriptConstruct += "if (!!window.EventSource) {";
    ScriptConstruct += "var source = new EventSource('/events');";
    ScriptConstruct += "source.addEventListener('open', function(e) {";
    ScriptConstruct += "console.log(\"Events Connected\");";
    ScriptConstruct += "}, false);";
    ScriptConstruct += "source.addEventListener('error', function(e) {";
    ScriptConstruct += "if (e.target.readyState != EventSource.OPEN) {";
    ScriptConstruct += "console.log(\"Events Disconnected\");";
    ScriptConstruct += "}";
    ScriptConstruct += "}, false);";
    ScriptConstruct += "source.addEventListener('message', function(e) {";
    ScriptConstruct += "console.log(\"message\", e.data);";
    ScriptConstruct += "}, false);";
    RETOUR = "";
    JsonArray Actions = SPIFFS_Config_Actions["actions"];
    for (int i = 0; i < Actions.size(); i++) {
      if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "button") {

        if (SPIFFS_Config_Actions["actions"][i]["return"].as<String>() == "true") RETOUR += "<button id=\"" + SPIFFS_Config_Actions["actions"][i]["id"].as<String>() + "\" class=\"Bouton\" onclick=\"Click(this)\" style=\"margin-left:5px;margin-right:5px;text-decoration:none\"> " + SPIFFS_Config_Actions["actions"][i]["nom"].as<String>() + " </button><br>";
        else RETOUR += "<button id=\"" + SPIFFS_Config_Actions["actions"][i]["id"].as<String>() + "\" class=\"Bouton\" onclick=\"Click(this)\" style=\"margin-left:5px;margin-right:5px;text-decoration:none\"> " + SPIFFS_Config_Actions["actions"][i]["nom"].as<String>() + " </button>";


      } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "little_button") {

        if (SPIFFS_Config_Actions["actions"][i]["return"].as<String>() == "true") RETOUR += "<button id=\"" + SPIFFS_Config_Actions["actions"][i]["id"].as<String>() + "\" class=\"LittleBouton\" onclick=\"Click(this)\" style=\"margin-left:5px;margin-right:5px;text-decoration:none\"> " + SPIFFS_Config_Actions["actions"][i]["nom"].as<String>() + " </button><br>";
        else RETOUR += "<button id=\"" + SPIFFS_Config_Actions["actions"][i]["id"].as<String>() + "\" class=\"LittleBouton\" onclick=\"Click(this)\" style=\"margin-left:5px;margin-right:5px;text-decoration:none\"> " + SPIFFS_Config_Actions["actions"][i]["nom"].as<String>() + " </button>";


      } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "html") {
        String Value = SPIFFS_Config_Actions["actions"][i]["value"].as<String>();
        RETOUR += Value;



      } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "title") {
        String Nom = SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
        String ID = SPIFFS_Config_Actions["actions"][i]["id"].as<String>();
        String Size = SPIFFS_Config_Actions["actions"][i]["size"].as<String>();
        RETOUR += "<b><div style=\"padding-top: 10px; padding-bottom: 10px; font-size: " + Size + "px;\">" + Nom + "</div></b>";
        ScriptConstruct += "source.addEventListener('" + SPIFFS_Config_Actions["actions"][i]["id"].as<String>() + "', function(e) {document.getElementById(\"" + ID + "\").innerHTML = e.data;}, false);";

      } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "text_index") {
        String Nom = SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
        String ID = SPIFFS_Config_Actions["actions"][i]["id"].as<String>();
        String Size = SPIFFS_Config_Actions["actions"][i]["size"].as<String>();
        RETOUR += "<div style=\"padding-top: 10px; padding-bottom: 10px; font-size: " + Size + "px;\">" + Nom + "</div>";
        ScriptConstruct += "source.addEventListener('" + SPIFFS_Config_Actions["actions"][i]["id"].as<String>() + "', function(e) {document.getElementById(\"" + ID + "\").innerHTML = e.data;}, false);";

      } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "tooltip") {
        String Nom = SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
        String Content = SPIFFS_Config_Actions["actions"][i]["content"].as<String>();
        String ID = SPIFFS_Config_Actions["actions"][i]["id"].as<String>();
        RETOUR += "<div class=\"picto-item\" id=\"" + ID + "\" name=\"" + ID + "\" onclick=\"Click(this)\" aria-label=\"" + Content + "\">" + Nom + "</div>";
        if (SPIFFS_Config_Actions["actions"][i]["return"].as<String>() == "true") RETOUR += "<br>";
        ScriptConstruct += "source.addEventListener('" + SPIFFS_Config_Actions["actions"][i]["id"].as<String>() + "', function(e) {document.getElementById(\"" + ID + "\").innerHTML = e.data;}, false);";

      } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "range") {
        String Nom = SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
        String ID = SPIFFS_Config_Actions["actions"][i]["id"].as<String>();
        String Min = SPIFFS_Config_Actions["actions"][i]["min"].as<String>();
        String Max = SPIFFS_Config_Actions["actions"][i]["max"].as<String>();
        String Value = SPIFFS_Config_Actions["actions"][i]["value"].as<String>();

        RETOUR += "<div style=\"margin-top: 15px; margin-bottom: 10px;\">";
        RETOUR += "<label for=\"" + ID + "\">" + Nom + ": </label>";
        RETOUR += "<b><output id=\"RV" + ID + "\">" + Value + "</output></b><br>";
        RETOUR += "<input type=\"range\" id=\"" + ID + "\" name=\"" + ID + "\" min=\"" + Min + "\" max=\"" + Max + "\" value=\"" + Value + "\" oninput=\"RV" + ID + ".value=value\" onchange=\"ValidRange(this)\"/>";
        RETOUR += "</div>";

        ScriptConstruct += "source.addEventListener('" + ID + "', function(e) {document.getElementById(\"" + ID + "\").value = e.data; document.getElementById(\"RV" + ID + "\").innerHTML = e.data; }, false);";

      } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "info") {
        String Nom = SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
        String ID = SPIFFS_Config_Actions["actions"][i]["id"].as<String>();
        String Size = SPIFFS_Config_Actions["actions"][i]["size"].as<String>();
        String Value = SPIFFS_Config_Actions["actions"][i]["value"].as<String>();
        String Unit = SPIFFS_Config_Actions["actions"][i]["unit"].as<String>();
        if (Unit == "%") Unit = "%%";
        RETOUR += "<div style=\"margin-top: 10px; font-size: " + Size + "px;\">" + Nom + ": <b><span id=\"" + ID + "\">" + Value + "</span></b><span id=\"Unit" + ID + "\"> " + Unit + "</span></div>";
        ScriptConstruct += "source.addEventListener('" + SPIFFS_Config_Actions["actions"][i]["id"].as<String>() + "', function(e) {document.getElementById(\"" + ID + "\").innerHTML = e.data;}, false);";

      } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "infofa") {
        String Nom = SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
        String ID = SPIFFS_Config_Actions["actions"][i]["id"].as<String>();
        String Size = SPIFFS_Config_Actions["actions"][i]["size"].as<String>();
        String Value = SPIFFS_Config_Actions["actions"][i]["value"].as<String>();
        RETOUR += "<div style=\" margin-top: 10px; \">" + Nom + "</div>";
        RETOUR += "<div style=\"margin-top: 10px; font-size: " + Size + "px;\" ><i id=\"" + ID + "\" class=\"" + Value + "\"></i></div>";
        ScriptConstruct += "source.addEventListener('" + SPIFFS_Config_Actions["actions"][i]["id"].as<String>() + "', function(e) {document.getElementById(\"" + ID + "\").className = e.data;}, false);";

      } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "inputbox") {
        String Nom = SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
        String ID = SPIFFS_Config_Actions["actions"][i]["id"].as<String>();
        String Value = SPIFFS_Config_Actions["actions"][i]["value"].as<String>();
        String Type = SPIFFS_Config_Actions["actions"][i]["typebox"].as<String>();
        RETOUR += "<b><label>" + Nom + "</label></b><br><input class=\"inputbox\" id=\"" + ID + "\" name=\"" + ID + "\" type=\"" + Type + "\" onBlur=\"InputBoxValidate(this)\"/><br>";
        ScriptConstruct += "source.addEventListener('" + ID + "', function(e) {document.getElementById(\"" + ID + "\").value = e.data;}, false);";

      } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "color") {
        String Nom = SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
        String ID = SPIFFS_Config_Actions["actions"][i]["id"].as<String>();
        String R = SPIFFS_Config_Actions["actions"][i]["r"].as<String>();
        String G = SPIFFS_Config_Actions["actions"][i]["g"].as<String>();
        String B = SPIFFS_Config_Actions["actions"][i]["b"].as<String>();

        RETOUR += "<div class=\"FondBlanc_Color\">" + Nom + "<br><input class=\"input_color\" id=\"" + ID + "\" type=\"color\" onchange=\"printColor(this,event)\"/></div>";
        RETOUR += "<script>var rHex = parseInt(" + R + ").toString(16).padStart(2, '0'); var gHex = parseInt(" + G + ").toString(16).padStart(2, '0');var bHex = parseInt(" + B + ").toString(16).padStart(2, '0'); document.getElementById(\"" + ID + "\").value = '#' + rHex + gHex + bHex; </script>";

        ScriptConstruct += "source.addEventListener('" + ID + "', function(e) {document.getElementById(\"" + ID + "\").value = e.data;}, false);";

      } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "eeSeg") {
        RETOUR += "<div style=\"margin-top: 30px;\" class=\"Seg\"></div>";

      } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "eeSegw") {
        RETOUR += "<div style=\"margin-top: 30px;\" class=\"Segw\"></div>";

      } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "toggle") {

        RETOUR += "<div class=\"div_toogle\"><div class=\"div_toogle_name\">" + SPIFFS_Config_Actions["actions"][i]["nom"].as<String>() + "</div>";

        String Nom = SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
        String Value0 = SPIFFS_Config_Actions["actions"][i]["value0"].as<String>();
        String Value1 = SPIFFS_Config_Actions["actions"][i]["value1"].as<String>();
        String ID0 = SPIFFS_Config_Actions["actions"][i]["id0"].as<String>();
        String ID1 = SPIFFS_Config_Actions["actions"][i]["id1"].as<String>();

        if (SPIFFS_Config_Actions["actions"][i]["state"].as<String>() == Value1) {
          RETOUR += "<label class=\"switch\">";
          RETOUR += "<input type=\"checkbox\" name=\"" + ID0 + "\" id=\"" + ID0 + "\" value=\"" + Value1 + "\" type=\"checkbox\" onclick=\"ClickToogle(this,'" + Value0 + "','" + Value1 + "','" + ID0 + "','" + ID1 + "')\" checked>";
          RETOUR += "<span class=\"slider round\"></span> </label> </div><br>";
        } else {
          RETOUR += "<label class=\"switch\">";
          RETOUR += "<input type=\"checkbox\" name=\"" + ID0 + "\" id=\"" + ID0 + "\" value=\"" + Value1 + "\" type=\"checkbox\" onclick=\"ClickToogle(this,'" + Value0 + "','" + Value1 + "','" + ID0 + "','" + ID1 + "')\">";
          RETOUR += "<span class=\"slider round\"></span> </label> </div><br>";
        }

        ScriptConstruct += "source.addEventListener('" + ID0 + "', function(e) {document.getElementById(\"" + ID0 + "\").checked = false; }, false);";
        ScriptConstruct += "source.addEventListener('" + ID1 + "', function(e) {document.getElementById(\"" + ID0 + "\").checked = true; }, false);";

      } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "list") {

        String NomList = SPIFFS_Config_Actions["actions"][i]["nomliste"].as<String>();
        String Nom = SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
        String ID = SPIFFS_Config_Actions["actions"][i]["id"].as<String>();

        bool Liste_Existante = false;
        for (int k = 0; k < ID_Memoire_Liste; k++) {
          if (Memoire_Liste[k] == NomList) {
            Liste_Existante = true;

            break;
          }
        }

        String Statut;
        for (int k = 0; k < NB_Listes; k++) {
          if (Listes[k] == NomList) {
            Statut = Listes_Value[k];
            break;
          }
        }


        if (!Liste_Existante) {
          RETOUR += "<label for=\"" + NomList + "\">" + NomList + "</label><br>";
          RETOUR += "<select class=\"box\" name=\"" + NomList + "\" id=\"" + NomList + "\" onchange=\"Liste(this)\">";
          RETOUR += "<option id=\"" + ID + "\" value=\"" + ID + "\">" + Nom + "</option>";
          ScriptConstruct += "source.addEventListener('" + ID + "', function(e) {document.getElementById(\"" + NomList + "\").value = " + ID + ";}, false);";

          for (int j = i + 1; j < Actions.size(); j++) {
            if (SPIFFS_Config_Actions["actions"][j]["type"].as<String>() == "list" && SPIFFS_Config_Actions["actions"][j]["nomliste"].as<String>() == NomList) {
              Nom = SPIFFS_Config_Actions["actions"][j]["nom"].as<String>();
              ID = SPIFFS_Config_Actions["actions"][j]["id"].as<String>();
              if (ID == Statut) {
                RETOUR += "<option id=\"" + ID + "\" value=\"" + ID + "\" selected>" + Nom + "</option>";
              } else {
                RETOUR += "<option id=\"" + ID + "\" value=\"" + ID + "\">" + Nom + "</option>";
              }

              ScriptConstruct += "source.addEventListener('" + ID + "', function(e) {document.getElementById(\"" + NomList + "\").value = " + ID + ";}, false);";
            }
          }

          Memoire_Liste[ID_Memoire_Liste] = NomList;
          ID_Memoire_Liste++;
          RETOUR += "</select><br>";
        }
      }
      if (i == Actions.size() - 1) {
        ScriptConstruct += "}</script>";
        RETOUR += ScriptConstruct;
      }
    }
  }
  ID_Memoire_Liste = 0;
  return RETOUR;
}





void MiraPanelServer::Init() {

  if (_Debug == true) Serial.println(F("\n\nMiraPanelServer:  !!!----!!!  \n\n"));
  delay(50);






  cipher->setKey(key);



  SPIFFS_Initialisation();
  if (!SPIFFS.exists("/reseau.json")) SPIFFS_CreationConfigReseau();
  if (!SPIFFS.exists("/params.json")) SPIFFS_CreationConfigParams();
  if (!SPIFFS.exists("/miralvgl.json")) SPIFFS_Creation_lvgl();
  SPIFFS_ChargementConfigurationReseau();
  SPIFFS_ChargementConfigurationParams();
  SPIFFS_ChargementConfigurationLvgl();

  JsonArray Params = SPIFFS_Config_Actions.createNestedArray("actions");
  JsonArray Module = SPIFFS_Config_Module.createNestedArray("module");

  if (_Scan == true) ScanWiFi();

  if (SPIFFS_Config_Reseau["ap"][0]["actif"].as<String>() == "0") {
    if (SPIFFS_Config_Reseau["ap"][0]["passcrypt"].as<String>() == "null") {
      SPIFFS_ResetReseau();
      SPIFFS_CreationConfigReseau();
      delay(500);
      ESP.restart();
    } else if (SPIFFS_Config_Reseau["ap"][0]["passcrypt"].as<String>() == "") {
      ModeAP = true;
      ServeurDNS();
    } else {
      if (initWiFi()) {
        ModeAP = false;
        ServeurStation();


        ArduinoOTA
          .onStart([]() {
            String type;
            if (ArduinoOTA.getCommand() == U_FLASH)
              type = "sketch";
            else
              type = "filesystem";
          })
          .onEnd([]() {

          })
          .onProgress([](unsigned int progress, unsigned int total) {

          })
          .onError([](ota_error_t error) {

          });

        ArduinoOTA.begin();


      } else {
        if (initPA()) {
          BesoinCo = true;
          ModeAP = true;
          ServeurStation();
        }
      }
    }

  } else {
    if (initPA()) {
      ModeAP = true;
      ServeurStation();
    }
  }
}


void MiraPanelServer::AsyncHTTP(String URL) {
  if (_Debug) Serial.println(F("Mira:  Envoi de la requête HTTP asyncrone"));
  int Length_URL = URL.length();
  Length_URL++;
  char Buf[Length_URL];
  URL.toCharArray(Buf, Length_URL);
  miraAsyncHTTPGet(Buf);
}

void MiraPanelServer::JeedomInit() {
  JEEDOM_mira = GetParamBool("Jeedom");
  JEEDOM_Refresh = GetParamText("Jeedom_Refresh");
  JEEDOM_Init = GetParamText("Jeedom_Init_Cmd");
  JEEDOM_Key_mira = GetParamText("Jeedom_Key_mira");
  JEEDOM_Key = GetParamText("Jeedom_Key");
  JEEDOM_IP = GetParamText("Jeedom_IP");
  if (JEEDOM_mira && JEEDOM_Init != "" && JEEDOM_Key_mira != "" && JEEDOM_IP != "" && JEEDOM_Refresh != "" && JEEDOM_Init != "null" && JEEDOM_Key_mira != "null" && JEEDOM_IP != "null" && JEEDOM_Refresh != "null") {

    if (JEEDOM_mira) {
      String URL = JEEDOM_IP + "/core/api/jeeApi.php?plugin=mira&type=event&apikey=" + JEEDOM_Key_mira + "&id=" + JEEDOM_Init;
      if (_Debug) Serial.println(F("Mira:  Envoi de l'Init Jeedom"));
      int Length_URL = URL.length();
      Length_URL++;
      char Buf[Length_URL];
      URL.toCharArray(Buf, Length_URL);
      miraAsyncHTTPGet(Buf);
    }
  }
}

void MiraPanelServer::JeedomRefresh() {
  JEEDOM_mira = GetParamBool("Jeedom");
  JEEDOM_Refresh = GetParamText("Jeedom_Refresh");
  JEEDOM_Init = GetParamText("Jeedom_Init_Cmd");
  JEEDOM_Key_mira = GetParamText("Jeedom_Key_mira");
  JEEDOM_Key = GetParamText("Jeedom_Key");
  JEEDOM_IP = GetParamText("Jeedom_IP");
  if (JEEDOM_mira && JEEDOM_Refresh != "" && JEEDOM_Key != "" && JEEDOM_IP != "" && JEEDOM_Refresh != "null" && JEEDOM_Key != "null" && JEEDOM_IP != "null") {
    String URL = JEEDOM_IP + "/core/api/jeeApi.php?plugin=mira&type=event&apikey=" + JEEDOM_Key_mira + "&id=" + JEEDOM_Refresh;
    int Length_URL = URL.length();
    Length_URL++;
    char Buf[Length_URL];
    URL.toCharArray(Buf, Length_URL);
    miraAsyncHTTPGet(Buf);
    if (_Debug) Serial.println(F("Mira:  Envoi du refresh Jeedom"));
  }
}

/*void MiraPanelServer::JeedomTimerRefresh() {
  JEEDOM_Moment_Present = millis();
  if (JEEDOM_Moment_Present - JEEDOM_Moment_Memorise > 100) {
    JeedomRefresh();
    JEEDOM_Moment_Memorise = 0;
    JEEDOM_Moment_Present = 0;
  }
}*/
void MiraPanelServer::IndexResetEvent() {
  //Action = -1;
}

int MiraPanelServer::ParamGetEvent() {
  int memoireparamEvent = paramEvent;
  paramEvent = -1;
  return memoireparamEvent;
}

int MiraPanelServer::IndexGetEvent() {
  if (DNS == true) {
    dnsServer.processNextRequest();
    RSTHandler();

  } else {


    if (millis() - MomentPrecedent_Surv > 300000) {
      MomentPrecedent_Surv = millis();
      if ((ModeAP == false || BesoinCo == true) && TentativesReco == 0) {

        if (WiFi.status() != WL_CONNECTED) {
          if (_Debug == true) Serial.println(F("Mira:  Perte de connexion WiFi..."));
          if (_Scan == true) ScanWiFi();

          if (_Debug == true) Serial.println(F("Mira:  Tentative de reconnexion..."));
          if (ReInitWiFi()) {
            TentativesReco = 0;
            ModeAP = false;
            ConnexionPerdue = false;
            BesoinCo = false;
            WiFi.mode(WIFI_STA);
            if (_Debug == true) Serial.println(F("Mira:  Connexion retrouvée!"));
          } else {
            if (initPA()) {

              if (_Debug == true) Serial.println(F("Mira:  Impossible de se reconnecter! Activation du point d'accès..."));
              ModeAP = true;
              ConnexionPerdue = true;
            }
          }
        }

      } else if (ConnexionPerdue == true) {
        TentativesReco++;
        if (_Debug == true) Serial.println("Mira:  " + String(TentativesReco));
        if (TentativesReco >= 2) {
          if (_Debug == true) Serial.println(F("Mira:  Lancement de la tentative de reconnexion..."));
          TentativesReco = 0;
          ModeAP = false;
        }
      }
    }
    ArduinoOTA.handle();

    //Jeedom mira
    if (!Init_Jeedom) {
      JEEDOM_mira = GetParamBool("Jeedom");
      if (!Init_Jeedom && JEEDOM_mira) {
        ActionGet = false;
        JeedomInit();
        Init_Jeedom = true;
        //JEEDOM_Moment_Memorise = millis();
      }

      if (Action != -1 && AUTO_REFRESH && !JEEDOM_mira) {  //envoi url Generic
        GenericCmd(Action);
      }
    } else {
      JEEDOM_mira = GetParamBool("Jeedom");
      if (Action != ACTION_UPDATE && Action != -1 && JEEDOM_mira && AUTO_REFRESH) {
        JeedomCmd(Action);
      }
      if (JEEDOM_mira) {
        SendQueud();
      }
      if (ReponseAsync != "null" && JEEDOM_mira) {
        for (int i = 0; i < 5; i++) {
          if (eQueud[i].cmd == ReponseAsync) {
            if (_Debug) Serial.print(F("Remove: "));
            if (_Debug) Serial.println(eQueud[i].cmd);
            eQueud[i].id = -1;
            eQueud[i].cmd = "";
            eQueud[i].value = "";
            eQueud[i].send = false;
            eQueud[i].test = 0;
            ReorderQueued();
          }
        }



        ReponseAsync = "null";
      }
    }
    RSTHandler();

    //MAJ
    int Memoire_Action_Event = -1;
    if (Action == ACTION_UPDATE) {
      if (!update_module(UpdateURL)) {
        if (_Debug) Serial.print(F("Mira:  Il y a eu un problème lors de la MAJ..."));
        events.send("Mise à jour impossible, le serveur a retourné une mauvaise réponse...", "divmessage", millis());
      }
      Action = -1;


    } else {
      Memoire_Action_Event = Action;
      Action = -1;
    }

    return Memoire_Action_Event;
  }
}


void MiraPanelServer::SendQueud() {
  if (eQueud[0].id != -1 && !eQueud[0].send) {

    if (eQueud[0].cmd != "" && eQueud[0].value == "") {

      String URL = JEEDOM_IP + "/core/api/jeeApi.php?plugin=mira&type=event&apikey=" + JEEDOM_Key_mira + "&id=" + eQueud[0].cmd;
      if (_Debug) Serial.print(F("Mira:  Envoi de l'action Jeedom: "));
      if (_Debug) Serial.println(eQueud[0].cmd);
      //HTTPGet(URL);
      int Length_URL = URL.length();
      Length_URL++;
      char Buf[Length_URL];
      URL.toCharArray(Buf, Length_URL);
      miraAsyncHTTPGet(Buf);




    } else if (eQueud[0].cmd != "" && eQueud[0].value != "") {
      String URL = JEEDOM_IP + "/core/api/jeeApi.php?plugin=mira&type=event&apikey=" + JEEDOM_Key_mira + "&id=" + eQueud[0].cmd + "&value=" + eQueud[0].value;
      if (_Debug) Serial.print(F("Mira:  Envoi de l'info Jeedom: "));
      if (_Debug) Serial.print(eQueud[0].cmd);
      if (_Debug) Serial.print(F(" : "));
      if (_Debug) Serial.println(eQueud[0].value);
      //HTTPGet(URL);
      int Length_URL = URL.length();
      Length_URL++;
      char Buf[Length_URL];
      URL.toCharArray(Buf, Length_URL);
      miraAsyncHTTPGet(Buf);
    }
    eQueud[0].send = true;
    eQueud[0].test = 1;
  }

  if (Queued_Moment_Memorise != 0 && millis() - Queued_Moment_Memorise > 3000) {
    if (eQueud[0].send) eQueud[0].send = false;
    if (eQueud[0].test < 3) {
      Queued_Moment_Memorise = millis();
      eQueud[0].test++;
    } else {
      Queued_Moment_Memorise = 0;
      eQueud[0].id = -1;
      eQueud[0].cmd = "";
      eQueud[0].value = "";
      eQueud[0].send = false;
      eQueud[0].test = 0;
      ReorderQueued();
    }
  }
}

void MiraPanelServer::ReorderQueued() {

  for (int i = 0; i < 5; i++) {
    bool Trouve = false;
    if (eQueud[i].id == -1) {
      for (int j = i; j < 5 && !Trouve; j++) {
        if (eQueud[j].id != -1) {
          eQueud[i].id = eQueud[j].id;
          eQueud[i].cmd = eQueud[j].cmd;
          eQueud[i].value = eQueud[j].value;
          eQueud[i].send = eQueud[j].send;
          eQueud[i].test = eQueud[j].test;
          eQueud[j].id = -1;
          eQueud[j].cmd = "";
          eQueud[j].value = "";
          eQueud[j].send = false;
          eQueud[j].test = 0;
          Trouve = true;
        }
      }
    }
    if (_Debug) Serial.println(eQueud[i].id);
  }
}


void MiraPanelServer::JeedomCmd(int ID) {
  if (Resend) {
    if (_Debug) Serial.print(F("Add: "));

    JsonArray Actions = SPIFFS_Config_Actions["actions"];
    String Jeedom_ID = "";
    String Jeedom_Value = "";
    for (int i = 0; i < Actions.size(); i++) {
      if (SPIFFS_Config_Actions["actions"][i]["id0"].as<String>() == String(ID)) {
        Jeedom_ID = SPIFFS_Config_Actions["actions"][i]["jeedom0"].as<String>();
      } else if (SPIFFS_Config_Actions["actions"][i]["id1"].as<String>() == String(ID)) {
        Jeedom_ID = SPIFFS_Config_Actions["actions"][i]["jeedom1"].as<String>();
      } else if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(ID)) {
        Jeedom_ID = SPIFFS_Config_Actions["actions"][i]["jeedom"].as<String>();
        if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "range"
            || SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "info") {
          Jeedom_Value = SPIFFS_Config_Actions["actions"][i]["value"].as<String>();
        } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "list") {
          Jeedom_Value = String(ID);
        } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "color") {
          int R = (SPIFFS_Config_Actions["actions"][i]["r"].as<String>()).toInt();
          int G = (SPIFFS_Config_Actions["actions"][i]["g"].as<String>()).toInt();
          int B = (SPIFFS_Config_Actions["actions"][i]["b"].as<String>()).toInt();
          char hexArray[6] = { 0 };
          sprintf(hexArray, "%02X%02X%02X", R, G, B);
          Jeedom_Value = "%23";
          Jeedom_Value += hexArray;
        }
      }
      if (Jeedom_ID != "") break;
    }

    if (Jeedom_ID != "") {

      for (int i = 0; i < 5; i++) {
        if (eQueud[i].id == -1) {
          eQueud[i].id = ID;
          eQueud[i].cmd = Jeedom_ID;
          eQueud[i].value = Jeedom_Value;
          eQueud[i].send = false;
          eQueud[i].test = 0;

          if (_Debug) Serial.println(eQueud[i].cmd);
          Queued_Moment_Memorise = millis();
          break;
        }
      }
    }



    /*if (Jeedom_ID != "" && Jeedom_Value == "") {

        String URL = JEEDOM_IP + "/core/api/jeeApi.php?plugin=mira&type=event&apikey=" + JEEDOM_Key_mira + "&id=" + Jeedom_ID;
        if (_Debug) Serial.print(F("Mira:  Envoi de l'action Jeedom: "));
        if (_Debug) Serial.println(Jeedom_ID);
        //HTTPGet(URL);
        int Length_URL = URL.length();
        Length_URL++;
        char Buf[Length_URL];
        URL.toCharArray(Buf, Length_URL);
        miraAsyncHTTPGet(Buf);



        //break;
      } else if (Jeedom_ID != "" && Jeedom_Value != "") {
        String URL = JEEDOM_IP + "/core/api/jeeApi.php?plugin=mira&type=event&apikey=" + JEEDOM_Key_mira + "&id=" + Jeedom_ID + "&value=" + Jeedom_Value;
        if (_Debug) Serial.print(F("Mira:  Envoi de l'info Jeedom: "));
        if (_Debug) Serial.print(Jeedom_ID);
        if (_Debug) Serial.print(F(" : "));
        if (_Debug) Serial.println(Jeedom_Value);
        //HTTPGet(URL);
        int Length_URL = URL.length();
        Length_URL++;
        char Buf[Length_URL];
        URL.toCharArray(Buf, Length_URL);
        miraAsyncHTTPGet(Buf);


        //break;
      }*/
  }
}

void MiraPanelServer::GenericCmd(int ID) {
  if (Resend) {
    JsonArray Actions = SPIFFS_Config_Actions["actions"];
    String GenericValue = "";
    String GenericName = "";
    for (int i = 0; i < Actions.size(); i++) {
      if (SPIFFS_Config_Actions["actions"][i]["id0"].as<String>() == String(ID)) {
        GenericValue = SPIFFS_Config_Actions["actions"][i]["value0"].as<String>();
        GenericName = SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
        break;
      } else if (SPIFFS_Config_Actions["actions"][i]["id1"].as<String>() == String(ID)) {
        GenericValue = SPIFFS_Config_Actions["actions"][i]["value1"].as<String>();
        GenericName = SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
        break;
      } else if (SPIFFS_Config_Actions["actions"][i]["id"].as<String>() == String(ID)) {
        GenericValue = SPIFFS_Config_Actions["actions"][i]["value"].as<String>();
        GenericName = SPIFFS_Config_Actions["actions"][i]["nom"].as<String>();
        if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "range"
            || SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "info") {
          GenericValue = SPIFFS_Config_Actions["actions"][i]["value"].as<String>();
        } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "list") {
          GenericValue = String(ID);
        } else if (SPIFFS_Config_Actions["actions"][i]["type"].as<String>() == "color") {
          int R = (SPIFFS_Config_Actions["actions"][i]["r"].as<String>()).toInt();
          int G = (SPIFFS_Config_Actions["actions"][i]["g"].as<String>()).toInt();
          int B = (SPIFFS_Config_Actions["actions"][i]["b"].as<String>()).toInt();
          char hexArray[6] = { 0 };
          sprintf(hexArray, "%02X%02X%02X", R, G, B);
          GenericValue = "%23";
          GenericValue += hexArray;
        }
        break;
      }
    }

    JsonArray Json_Array = mira_Json_LVGL["lvgl"];
    for (int i = 0; i < Json_Array.size(); i++) {
      if (mira_Json_LVGL["lvgl"][i]["name"].as<String>() == GenericName) {
        String URL = mira_Json_LVGL["lvgl"][i]["url"].as<String>();
        if (GenericValue != "") URL.replace("#value#", GenericValue);

        int Length_URL = URL.length();
        Length_URL++;
        char Buf[Length_URL];
        URL.toCharArray(Buf, Length_URL);
        miraAsyncHTTPGet(Buf);
        if (_Debug) Serial.print(F("Mira:  Envoi de l'info Generic: "));


        break;
      }
    }
  }
}
